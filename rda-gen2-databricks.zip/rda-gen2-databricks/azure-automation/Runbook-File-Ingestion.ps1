param(
  [Parameter(Mandatory=$true)]
  [ValidateSet('dev','qa','uat','prod')]
  [string]$Environment,
 
  [Parameter(Mandatory=$true)]
  [string]$Source,

  [Parameter(Mandatory=$true)]
  [string]$KeyVaultName,

  [Parameter(Mandatory=$true)]
  [string]$Adls,

  [bool]$Force = $false,

  # Paths
  
  [string]$WorkDir   = "C:\$Environment\rda-gen2-databricks\file-ingestion",
  [string]$ScriptRel = "transfer.py",
  [string]$VenvPath  = "C:\$Environment\rda-gen2-databricks\.venv",
  [string]$BasePython = "C:\Program Files\Python314\python.exe"
)

function Write-Log {
  param([string]$m)
  Write-Output ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $m)
}

# ===============================
# PATH SETUP
# ===============================
$ScriptPath = Join-Path $WorkDir $ScriptRel
$ReqPath    = Join-Path $WorkDir "requirements.txt"
$VenvPython = Join-Path $VenvPath "Scripts\python.exe"

Write-Log "Script path: $ScriptPath"
Write-Log "Venv path: $VenvPath"

# ===============================
# VIRTUAL ENVIRONMENT SETUP
# ===============================
if (!(Test-Path $VenvPython)) {
    Write-Log "Virtual environment not found or broken. Creating..."
    
    if (!(Test-Path $BasePython)) {
        throw "Base Python not found: $BasePython"
    }

    & $BasePython -m venv $VenvPath
}


if (!(Test-Path $ReqPath)) {
    throw "requirements.txt not found: $ReqPath"
}

Write-Log "Ensuring dependencies are installed..."
& $VenvPython -m pip install --upgrade pip | Out-Null
& $VenvPython -m pip install -r $ReqPath | Out-Null
Write-Log "Dependencies check complete..."

# ===============================
# BUILD ARGUMENTS
# ===============================

$ConfigDir = "adls://$Adls/rda-app/python-config/$Source"
$Args = @(
  "--env", $Environment,
  "--config-dir", $ConfigDir,
  "--secrets",
  "--kv", $KeyVaultName
)

if ($Force) {
    $Args += "--force"
}



# ===============================
# EXECUTION
# ===============================
Write-Log "Executing $ScriptRel..."

& $VenvPython $ScriptPath @Args 2>&1 | ForEach-Object {
    Write-Output $_
}


if ($LASTEXITCODE -ne 0) {
    Write-Log "$ScriptRel FAILED with exit code $LASTEXITCODE"
    throw "Python execution failed"
}

Write-Log "$ScriptRel completed successfully..."