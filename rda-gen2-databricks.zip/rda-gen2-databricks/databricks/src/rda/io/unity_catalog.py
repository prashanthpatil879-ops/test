from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from rda.utils.logger import get_logger

class UnityCatalog:

    def __init__(self, env_config, spark):
        self._spark = spark
        self._env_config = env_config
        self._logger = get_logger(self.__class__.__name__)

    def read_table(self, table_name: str) -> DataFrame:
        self._logger.info(f"Reading data from {table_name} table")
        return self.capitalize_cols(self._spark.read.table(f"{table_name}"))
    
    def read_query(self, query: str) -> DataFrame:
        self._logger.info(f"Reading data from {query}")
        df = self._spark.sql(query)
        return self.capitalize_cols(df)
    
    def read_watermark(self, table_name: str, watermark_col: str, filter: str = None):
        self._logger.info(f"Reading max watermark value from {table_name}")
        filter_query = f"WHERE {filter}" if filter else ""
        result = self.read_query(f"SELECT MAX({watermark_col}) as WATERMARK FROM {table_name} {filter_query}")
        return result.collect()[0]['WATERMARK']
    
    def read_incremental(self, table_name: str, watermark_col: str, watermark_value, filter: str = None) -> DataFrame:
        self._logger.info(f"Reading incremental data from {table_name} for watermark value: {watermark_value}")
        if watermark_value is None:
            if filter is None:
                return self.read_table(table_name)
            else:
                return self.read_query(f"SELECT * FROM {table_name} WHERE {filter}")
        else:
            if filter is None:
                return self.read_query(f"SELECT * FROM {table_name} WHERE {watermark_col} > CAST('{watermark_value}' AS TIMESTAMP)")
            else:
                return self.read_query(f"SELECT * FROM {table_name} WHERE {watermark_col} > CAST('{watermark_value}' AS TIMESTAMP) AND {filter}")
    
    def read_latest(self, table_name: str, watermark_col: str = "INGESTION_TS", filter: str = None) -> DataFrame:
        self._logger.info(f"Reading latest data from {table_name}")
        watermark_value = self.read_watermark(table_name, watermark_col, filter)
        if filter is None:
            return self.read_query(f"SELECT * FROM {table_name} WHERE {watermark_col} = CAST('{watermark_value}' AS TIMESTAMP)")
        else:
            return self.read_query(f"SELECT * FROM {table_name} WHERE {watermark_col} = CAST('{watermark_value}' AS TIMESTAMP) AND {filter}")
    
    def read_latest_dim(self, table_name: str, watermark_col: str = "INGESTION_TS", filter: str = None) -> DataFrame:
        return self.read_latest(f"{self._env_config.get('schema.semantic')}.{table_name}", watermark_col, filter="IS_ACTIVE = TRUE")
    
    def capitalize_cols(self, df: DataFrame) -> DataFrame:
        self._logger.debug("Capitalizing the columns...")
        return df.select([col(c).alias(c.upper()) for c in df.columns])
    
    def write(self, df: DataFrame, table_name: str, table_ext_path, mode="append", partition_col: str = None) -> None: 
        self._logger.info(f"writting data into the table {table_name}")
        df = self.capitalize_cols(df)
        writer = df.write.format("delta").mode(mode).option("path", table_ext_path)#.option("overwriteSchema", "true").option("mergeSchema", "true")

        if partition_col is not None and partition_col in df.columns:
            writer = writer.partitionBy(partition_col)
        
        writer.saveAsTable(f"{table_name}")
