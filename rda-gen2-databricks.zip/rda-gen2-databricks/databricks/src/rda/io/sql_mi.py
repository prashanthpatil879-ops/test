from azure.identity import ClientSecretCredential
from pyspark.sql import DataFrame
from rda.utils.logger import get_logger
from pyspark.sql import functions as F


class SqlMI:

    _TOKEN_SCOPE = "https://database.windows.net/.default"
    _JDBC_TEMPLATE = "jdbc:sqlserver://{server};database={database}"

    def __init__(self, env_config, spark):
        self._spark = spark
        self._env_config = env_config
        self._logger = get_logger(self.__class__.__name__)
        self._credential = ClientSecretCredential(
            tenant_id=self._env_config.get("secrets.tenant_id"),
            client_id=self._env_config.get("secrets.client_id"),
            client_secret=self._env_config.get("secrets.client_secret")
        )
        self._jdbc_url = self._JDBC_TEMPLATE.format(
            server=self._env_config.get("sqlmi.server"),
            database=self._env_config.get("sqlmi.database"),
            hostNameInCertificate=self._env_config.get("sqlmi.hostNameInCertificate")
        )
    
    def _get_token(self):
        token = self._credential.get_token(self._TOKEN_SCOPE)
        return token.token
    
    def _get_jdbc_options(self):
        return {
            "accessToken": self._get_token(),
            "encrypt": self._env_config.get("sqlmi.encrypt"),
            "hostNameInCertificate": self._env_config.get("sqlmi.hostNameInCertificate")
        }
    
    def _read(self, query: str) -> DataFrame:
        self._logger.info(f"Executing query: {query}")
        return (
            self._spark.read
            .format("jdbc")
            .option("url", self._jdbc_url)
            .option("dbtable", f"({query}) AS t")
            .options(**self._get_jdbc_options())
            .load()
        )

    def read_table(self, table_name: str) -> DataFrame:
        self._logger.info(f"Reading data from {table_name} table")
        return self._read(f"SELECT * FROM {table_name}")

    def read_query(self, query: str) -> DataFrame:
        self._logger.info(f"Reading data from {query}")
        return self._read(query)
    
    def read_table_or_query(self, table_or_query: str) -> DataFrame:
        self._logger.info(f"Reading data from {table_or_query}")
        if "select " in table_or_query.lower():
            return self.read_query(table_or_query)
        else:
            return self.read_table(table_or_query)
    
    def read_watermark(self, table_name: str, watermark_col: str) -> DataFrame:
        self._logger.info(f"Reading max watermark value from {table_name}")
        df = self._read(f"SELECT MAX({watermark_col}) AS watermark FROM {table_name}")
        return df.collect()[0]["watermark"]
    
    def read_incremental(self, table_name: str, watermark_col: str, watermark_value) -> DataFrame:
        self._logger.info(f"Reading incremental data from {table_name} for watermark value: {watermark_value}")
        if watermark_value is None:
            return self.read_table(table_name)
        else:
            return self._read(f"SELECT * FROM {table_name} WHERE {watermark_col} > CAST('{watermark_value}' AS DATETIME2)")
    
    def _jdbc_writer(self, df: DataFrame, table_name: str, mode: str) -> None:
        (
            df.write
            .format("jdbc")
            .option("url", self._jdbc_url)
            .option("dbtable", table_name)
            .options(**self._get_jdbc_options())
            .mode(mode)
            .save()
        )
    
    def write_fact(self, df: DataFrame, table_name: str) -> None:
        self._logger.info(f"Writing fact table {table_name}")

        self._jdbc_writer(
            df=df,
            table_name=table_name,
            mode="append"
        )

    def write_dimension_snapshot(self, df: DataFrame, table_name: str, created_by: str = "ADB") -> None:

        self._logger.info(
            f"Writing snapshot dimension {table_name}"
        )

        # Existing dimension
        current_df = self.read_table(table_name)

        # Historical rows remain untouched
        inactive_df = (
            current_df
            .filter(F.col("IS_ACTIVE") == 0)
        )

        # Close currently active rows
        closed_df = (
            current_df
            .filter(F.col("IS_ACTIVE") == 1)
            .withColumn("IS_ACTIVE", F.lit(0))
            .withColumn("END_DATE", F.current_timestamp())
        )

        # Build new active snapshot
        snapshot_df = (
            df
            .withColumn("IS_ACTIVE", F.lit(1))
            .withColumn("SYS_CREATE_DATE", F.current_timestamp())
            .withColumn("SYS_CREATE_BY", F.lit(created_by))
            .withColumn("START_DATE", F.current_timestamp())
            .withColumn(
                "END_DATE",
                F.lit(None).cast("timestamp")
            )
        )

        # Final state of dimension table
        final_df = (
            inactive_df
            .unionByName(closed_df)
            .unionByName(
                snapshot_df.select(inactive_df.columns)
            )
        )

        # Replace entire dimension
        self._jdbc_writer(
            df=final_df,
            table_name=table_name,
            mode="overwrite"
        )

    def write_dimension_incremental(self, df: DataFrame, table_name: str, key_cols: list[str], attribute_cols: list[str] = None, created_by: str = "ADB") -> None:

        self._logger.info(
            f"Writing incremental dimension {table_name}"
        )

        # Read existing dimension
        dim_df = self.read_table(table_name)

        active_df = dim_df.filter(F.col("IS_ACTIVE") == 1)
        inactive_df = dim_df.filter(F.col("IS_ACTIVE") == 0)

        # Derive business attributes automatically if not provided
        if attribute_cols is None:
            audit_cols = {
                "IS_ACTIVE",
                "SYS_CREATE_DATE",
                "SYS_CREATE_BY",
                "START_DATE",
                "END_DATE",
                "ORIGINAL_KEY"
            }

            attribute_cols = [
                c
                for c in df.columns
                if c not in key_cols
                and c.upper() not in audit_cols
            ]

        # Build compare key on incoming dataframe
        src_df = (
            df.withColumn(
                "COMPARE_KEY",
                F.concat_ws(
                    "|",
                    *[
                        F.coalesce(
                            F.col(c).cast("string"),
                            F.lit("NULL")
                        )
                        for c in attribute_cols
                    ]
                )
            )
        )

        # Build compare key on active dimension
        tgt_df = (
            active_df.withColumn(
                "COMPARE_KEY",
                F.concat_ws(
                    "|",
                    *[
                        F.coalesce(
                            F.col(c).cast("string"),
                            F.lit("NULL")
                        )
                        for c in attribute_cols
                    ]
                )
            )
        )

        # Join on business key
        join_cond = [
            F.col(f"src.{c}") == F.col(f"tgt.{c}")
            for c in key_cols
        ]

        compare_df = (
            src_df.alias("src")
            .join(
                tgt_df.alias("tgt"),
                join_cond,
                "left"
            )
        )

        first_key = key_cols[0]

        # New business keys
        new_rows_df = (
            compare_df
            .filter(F.col(f"tgt.{first_key}").isNull())
            .select("src.*")
        )

        # Existing but changed
        changed_rows_df = (
            compare_df
            .filter(
                F.col(f"tgt.{first_key}").isNotNull()
                &
                (
                    F.col("src.COMPARE_KEY")
                    !=
                    F.col("tgt.COMPARE_KEY")
                )
            )
        )

        # Keys requiring close/reopen
        changed_keys_df = (
            changed_rows_df
            .select(
                *[
                    F.col(f"src.{c}").alias(c)
                    for c in key_cols
                ]
            )
            .distinct()
        )

        # Active rows that remain unchanged
        unchanged_active_df = (
            active_df
            .join(
                changed_keys_df,
                key_cols,
                "left_anti"
            )
        )

        # Close old versions
        closed_rows_df = (
            active_df
            .join(
                changed_keys_df,
                key_cols,
                "inner"
            )
            .withColumn("IS_ACTIVE", F.lit(0))
            .withColumn("END_DATE", F.current_timestamp())
        )

        # New active versions
        insert_rows_df = (
            new_rows_df
            .unionByName(
                changed_rows_df.select("src.*")
            )
            .drop("COMPARE_KEY")
            .withColumn("IS_ACTIVE", F.lit(1))
            .withColumn("SYS_CREATE_DATE", F.current_timestamp())
            .withColumn("SYS_CREATE_BY", F.lit(created_by))
            .withColumn("START_DATE", F.current_timestamp())
            .withColumn(
                "END_DATE",
                F.lit(None).cast("timestamp")
            )
        )

        final_df = (
            inactive_df
            .unionByName(unchanged_active_df)
            .unionByName(closed_rows_df)
            .unionByName(
                insert_rows_df.select(inactive_df.columns)
            )
        )

        self._jdbc_writer(
            df=final_df,
            table_name=table_name,
            mode="overwrite"
        )