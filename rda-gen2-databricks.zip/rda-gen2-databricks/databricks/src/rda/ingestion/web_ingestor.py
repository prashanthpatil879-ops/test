import io
import re
import requests
import pandas as pd
import pyspark.sql.functions as F
from datetime import datetime
from pyspark.sql import DataFrame
from rda.io.unity_catalog import UnityCatalog
from rda.utils.logger import get_logger
from urllib.parse import unquote


class WebIngestor:

    def __init__(self, env_config, spark):
        self._logger = get_logger(self.__class__.__name__)
        self._spark = spark
        self._env_config = env_config
        self._uc = UnityCatalog(env_config, spark)

    def _get(self, url, headers=None, params=None):
        return requests.get(url, headers=headers, params=params, verify=False)

    def _post(self, url, headers=None, payload=None):
        raise NotImplementedError("POST method is not implemented")

    def _put(self, url, headers=None, payload=None):
        raise NotImplementedError("PUT method is not implemented")

    def _delete(self, url, headers=None):
        raise NotImplementedError("DELETE method is not implemented")

    def read_url(self, url: str, protocol: str = "GET", headers=None, params=None, payload=None) -> DataFrame:
        method = protocol.upper()

        if method == "GET":
            self._logger.info("Calling GET method")
            response = self._get(url, headers=headers, params=params)

        elif method == "POST":
            response = self._post(url, headers=headers, payload=payload)

        elif method == "PUT":
            response = self._put(url, headers=headers, payload=payload)

        elif method == "DELETE":
            response = self._delete(url, headers=headers)

        else:
            raise ValueError(f"Unsupported HTTP method: {method}")

        response.raise_for_status()

        pdf = pd.read_csv(io.StringIO(response.text), low_memory=False, keep_default_na=False, na_values=[])
        df = self._spark.createDataFrame(pdf)
        return df
    
    def clean_columns(self, df, dataset_cfg):

        if dataset_cfg.get("column_cleanup", {}).get("normalize_all_columns", False):
            self._logger.info("Normalizing all columns")
            cleaned_cols = [
                re.sub(r'[^a-zA-Z0-9]+', '_', col).strip('_')
                for col in df.columns
            ]
            df = df.toDF(*cleaned_cols)
        if dataset_cfg.get("column_renames", None):
            self._logger.info(f"Normalizing specific columns: {dataset_cfg.column_renames}")
            old_cols = dataset_cfg.column_renames.get("old_col_names", [])
            new_cols = dataset_cfg.column_renames.get("new_col_names", [])
            for old, new in zip(old_cols, new_cols):
                if old in df.columns:
                    df = df.withColumnRenamed(old, new)
        df = df.toDF(*[c.upper() for c in df.columns])
        return df
    
    def read(self, dataset_cfg) -> DataFrame:
        file_name = unquote(dataset_cfg.url.split("/")[-1])
        self._logger.info(f"Reading data from web - file name : {file_name}")
        raw_df = self.read_url(dataset_cfg.url, dataset_cfg.protocol , headers=None, params=None, payload=None)
        new_df = self.clean_columns(raw_df, dataset_cfg)
        return new_df

    def detect_new_data(self, new_df: DataFrame, old_df: DataFrame, dataset_cfg) -> bool:
        
        if old_df is None:
            self._logger.info("No existing table found. Proceeding with initial load...")
            return True
        
        self._logger.info("Checking for latest data...")
        old_df_clean = old_df.drop("SOURCE", "CREATED_BY", "INGESTION_TS")
        new_records_df = new_df.exceptAll(old_df_clean)
        if new_records_df.take(1):
            self._logger.info("New data detected. Proceeding with ingestion...")
            return True
        else:
            self._logger.info("No new data detected. Skipping ingestion...")
            return False

    def add_audit_columns(self, df: DataFrame) -> DataFrame:
        self._logger.info("Adding audit columns")
        df = df.withColumn("SOURCE", F.concat(F.lit("IFS Web @ "), F.current_date())) \
        .withColumn('CREATED_BY', F.lit('ADB')) \
        .withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))
        df = df.toDF(*[c.upper() for c in df.columns])
        return df

    def write(self, df: DataFrame, dataset_cfg) -> None:
        self._logger.info(f"Writting data into the {dataset_cfg.raw_table} table")
        self._uc.write(df, dataset_cfg.raw_table, dataset_cfg.raw_ext_table_loc, partition_col=dataset_cfg.get('partition_col'))