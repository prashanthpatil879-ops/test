import pandas as pd
import requests

def fetch_ifs_fx_rates(fx_rates_url):
  response = requests.get(fx_rates_url)
  return pd.DataFrame(response.text)
