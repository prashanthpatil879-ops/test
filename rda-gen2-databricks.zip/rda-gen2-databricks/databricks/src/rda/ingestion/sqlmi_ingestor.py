from datetime import datetime
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from rda.io.sql_mi import SqlMI
from rda.io.unity_catalog import UnityCatalog
from rda.utils.logger import get_logger

class SqlIngestor:

    def __init__(self, env_config, spark):
        self._logger = get_logger(self.__class__.__name__)
        self._env_config = env_config
        self._spark = spark
        self._sql_mi = SqlMI(env_config, spark)
        self._uc = UnityCatalog(env_config, spark)
    
    def read(self, dataset_cfg) -> DataFrame:
        self._logger.info(f"Reading data from {dataset_cfg.source_table} source table")
        last_watermark = self._get_last_watermark(dataset_cfg)

        if last_watermark is None:
            self._logger.info(f"No watermark found! Reading {dataset_cfg.source_table} from scratch...")
            df = self._sql_mi.read_incremental(dataset_cfg.source_table, dataset_cfg.watermark_col, None)
        else:
            source_watermark = self._sql_mi.read_watermark(dataset_cfg.source_table, dataset_cfg.watermark_col)

            if source_watermark is None:
                self._logger.info(f"Source table {dataset_cfg.source_table} contains no data.")
                return None

            if source_watermark > last_watermark:
                self._logger.info(f"Watermark found! Reading {dataset_cfg.source_table} from {last_watermark} to {source_watermark}...")
                df = self._sql_mi.read_incremental(dataset_cfg.source_table, dataset_cfg.watermark_col, last_watermark)
            else:
                self._logger.info(f"Watermark found! No new data found in {dataset_cfg.source_table}...")
                df = None

        if df is not None:
            df = df.toDF(*[c.upper() for c in df.columns])
        return df

    def _get_last_watermark(self, dataset_cfg):
        try:
            return self._uc.read_watermark(dataset_cfg.raw_table, dataset_cfg.watermark_col.upper())
        except Exception:
            self._logger.info(f"Raw table {dataset_cfg.raw_table} not found or empty! Running full load...")
            return None
    
    def add_audit_columns(self, df: DataFrame, dataset_cfg):
        self._logger.info(f"Adding audit columns to the table {dataset_cfg.raw_table}")
        min_watermark = df.agg(F.min(dataset_cfg.watermark_col.upper())).collect()[0][0]
        max_watermark = df.agg(F.max(dataset_cfg.watermark_col.upper())).collect()[0][0]

        df = df.withColumn("SOURCE", F.lit(dataset_cfg.source_table + f" | Slice: {min_watermark} to {max_watermark}")) \
        .withColumn('CREATED_BY', F.lit('ADB')) \
        .withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))
        
        df = df.toDF(*[c.upper() for c in df.columns])
        return df
    
    def write(self, df: DataFrame, dataset_cfg):
        self._logger.info(f"Ingesting data into the targert table {dataset_cfg.raw_table}")
        self._uc.write(df, dataset_cfg.raw_table, dataset_cfg.raw_ext_table_loc, partition_col=dataset_cfg.get('partition_col', None))

