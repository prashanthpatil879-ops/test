from pyspark.sql import functions as F, DataFrame, Column

def normalize_llp(df: DataFrame, llp_col: str = 'LOWEST_LEVEL_PORTFOLIO_NAME') -> DataFrame:
  return df.withColumn("LLP_TEMP", F.trim(F.regexp_replace(F.regexp_replace(F.upper(F.col(llp_col)), r"[^A-Za-z0-9_]", " "), r"\s+", " ")))


def normalize_text(col: Column) -> Column:
    return F.when(
        col.isNull(), None
    ).otherwise(
        F.trim(
            F.regexp_replace(
                F.regexp_replace(
                    F.upper(col),
                    r"[^A-Z0-9\s]", ""
                ),
                r"\s+", " "
            )
        )
    )

def normalize_text_without_space(col: Column) -> Column:
    return F.when(
        col.isNull(), None
    ).otherwise(
        F.trim(
            F.regexp_replace(
                F.regexp_replace(
                    F.upper(col),
                    r"[^A-Z0-9]", " "
                ),
                r"\s+", ""
            )
        )
    )


def pivot_measures_by_scenario(df, scenario_col, measure_cols):
    # All columns except measures + scenario
    group_cols = [c for c in df.columns if c not in measure_cols + [scenario_col]]

    # 1) Build a long format with one row per (group, measure, scenario)
    long_rows = []
    for m in measure_cols:
        long_rows.append(
            df.select(
                *group_cols,
                F.col(scenario_col).alias("SCEN"),
                F.lit(m).alias("MEASURE"),
                F.col(m).alias("VALUE")
            )
        )

    df_long = long_rows[0]
    for lr in long_rows[1:]:
        df_long = df_long.unionByName(lr)

    # 2) Create a composite pivot key: MEASURE_SCENARIO
    df_long = df_long.withColumn(
        "PIVOT_KEY",
        F.concat_ws("_", F.col("MEASURE"), F.regexp_replace(F.col("SCEN"), r"\s+", "_"))
    )

    # 3) Single pivot (Spark-safe)
    df_wide = df_long.groupBy(group_cols).pivot("PIVOT_KEY").agg(F.first("VALUE"))

    return df_wide