import re

def filter_files(files, pattern):
    temp_files = [f for f in files if re.match(pattern, f.name, re.IGNORECASE)]
    return sorted(temp_files, key=lambda f: f.modificationTime)
