import pandas as pd

sensitivitygrid_columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Currency_Code': pd.Series(dtype='str'),
    'InputType': pd.Series(dtype='str'),
    'Tenor': pd.Series(dtype='str'),
    'Neg200': pd.Series(dtype='float'),
    'Neg100': pd.Series(dtype='float'),
    'Neg50': pd.Series(dtype='float'),
    'Base': pd.Series(dtype='float'),
    'Pos50': pd.Series(dtype='float'),
    'Pos100': pd.Series(dtype='float'),
    'Pos200': pd.Series(dtype='float'),
}

interpolation_columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Currency_Code': pd.Series(dtype='str'),
    'InputType': pd.Series(dtype='str'),
    'Tenor': pd.Series(dtype='str'),
    'Total_Rate_Change_Base': pd.Series(dtype='float'),
    'Total_Rate_Change_+50bps': pd.Series(dtype='float'),
    'Total_Rate_Change_-50bps': pd.Series(dtype='float'),
    'Total_Rate_Change_+100bps': pd.Series(dtype='float'),
    'Total_Rate_Change_-100bps': pd.Series(dtype='float'),
    'Total_Rate_Change_+200bps': pd.Series(dtype='float'),
    'Total_Rate_Change_-200bps': pd.Series(dtype='float')
}

forecast_columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Currency_Code': pd.Series(dtype='str'),
    'Tax_Indicator_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Balance_Sheet_Component_Name': pd.Series(dtype='str'),
    'IFRS_Earnings_Component_Name': pd.Series(dtype='str'),
    'Scenario_Name': pd.Series(dtype='str'),
    'Amount': pd.Series(dtype='float')
}

def cubic_spline_interpolation(periodValue, rateValue, xValue):
    prdCount = len(periodValue)
    rtCount = len(rateValue)

    if prdCount != rtCount:
        return "Error: Range count is not matched."

    xn = [0] * prdCount
    yn = [0] * prdCount

    for cs in range(prdCount):
        xn[cs] = periodValue[cs]
        yn[cs] = rateValue[cs]

    n = prdCount
    u = [0] * (prdCount - 1)
    yvt = [0] * (prdCount)

    yvt[0] = 0
    u[0] = 0
    

    for i in range(1, n - 1):
        sg = (xn[i] - xn[i - 1]) / (xn[i + 1] - xn[i - 1])
        pq = sg * yvt[i - 1] + 2
        yvt[i] = (sg - 1) / pq        
        u[i] = (yn[i + 1] - yn[i]) / (xn[i + 1] - xn[i]) - (yn[i] - yn[i - 1]) / (xn[i] - xn[i - 1])
        u[i] = (6 * u[i] / (xn[i + 1] - xn[i - 1]) - sg * u[i - 1]) / pq

    qn = 0
    unr = 0
    yvt[n - 1] = (unr - qn * u[n - 2]) / (qn * yvt[n - 2] + 1)

    for k in range(n - 2, -1, -1):
        yvt[k] = yvt[k] * yvt[k + 1] + u[k]

    kl = 0
    kh = n - 1    

    while True:
        k = (kh - kl)        
        if k <= 1:
            break
        if xn[k - 1] > xValue:
            kh = k - 1
        else:
            kl = k - 1

    hn = xn[kh] - xn[kl]
    asp = (xn[kh] - xValue) / hn
    bcs = (xValue - xn[kl]) / hn
    yFinal = asp * yn[kl] + bcs * yn[kh] + ((asp ** 3 - asp) * yvt[kl] + (bcs ** 3 - bcs) * yvt[kh]) * (hn ** 2) / 6

    return yFinal

def get_sensitivity_grid(pdf_modelinputs, pdf_segmentmapping, pdf_config_modelinputs, pdf_config_sensitivitygrid):

    pdf_modelinputs_countries = pdf_modelinputs['Country_Name'].unique()

    pdf_sensitivitygrid = pd.DataFrame(columns=sensitivitygrid_columns)
    for country in pdf_modelinputs_countries:    
        for segmentmapping_row in pdf_segmentmapping.itertuples():  
            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                    (pdf_modelinputs['Country_Name'] == country)].empty):      
                TotalNeg200 = 0
                TotalNeg100 = 0
                TotalNeg50 = 0
                TotalPos50 = 0
                TotalPos100 = 0
                TotalPos200 = 0    

                for config_modelinputs_row in pdf_config_modelinputs.itertuples():        
                    pdf_sensitivitygrid_new = pd.DataFrame(columns=sensitivitygrid_columns) 

                    for sensitivitygrid_row in pdf_config_sensitivitygrid.itertuples():        
                        # print(segmentmapping_row.Lowest_Level_Portfolio_Name)
                        # print(str(sensitivitygrid_row[2]) + ' / ' + str(sensitivitygrid_row[3]) + ' / ' + str(sensitivitygrid_row[4]) + ' / ' + 
                        #       str(sensitivitygrid_row[6]) + ' / ' + str(sensitivitygrid_row[7]) + ' / ' + str(sensitivitygrid_row[8]))        
                        Neg200 = 0
                        Neg100 = 0
                        Neg50 = 0
                        Pos50 = 0
                        Pos100 = 0
                        Pos200 = 0

                        if(sensitivitygrid_row[2] != None):
                            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                        (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[2]) &
                                                        (pdf_modelinputs['Country_Name'] == country)].empty):
                                Neg200 = pdf_modelinputs.loc[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[2]) &
                                                            (pdf_modelinputs['Country_Name'] == country), 
                                                            config_modelinputs_row.ForecastingInput].values[0]
                        
                        if(sensitivitygrid_row[3] != None):
                            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                        (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[3]) &
                                                        (pdf_modelinputs['Country_Name'] == country)].empty):
                                Neg100 = pdf_modelinputs.loc[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[3]) &
                                                            (pdf_modelinputs['Country_Name'] == country), 
                                                            config_modelinputs_row.ForecastingInput].values[0]
                            
                        if(sensitivitygrid_row[4] != None):            
                            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                        (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[4]) &
                                                        (pdf_modelinputs['Country_Name'] == country)].empty):
                                Neg50 = pdf_modelinputs.loc[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[4]) &
                                                            (pdf_modelinputs['Country_Name'] == country), 
                                                            config_modelinputs_row.ForecastingInput].values[0]
                                
                        if(sensitivitygrid_row[6] != None):            
                            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                        (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[6]) &
                                                        (pdf_modelinputs['Country_Name'] == country)].empty):
                                Pos50 = pdf_modelinputs.loc[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[6]) &
                                                            (pdf_modelinputs['Country_Name'] == country), 
                                                            config_modelinputs_row.ForecastingInput].values[0]
                        
                        if(sensitivitygrid_row[7] != None):            
                            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                        (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[7]) &
                                                        (pdf_modelinputs['Country_Name'] == country)].empty):
                                Pos100 = pdf_modelinputs.loc[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[7]) &
                                                            (pdf_modelinputs['Country_Name'] == country), 
                                                            config_modelinputs_row.ForecastingInput].values[0]
                        
                        if(sensitivitygrid_row[8] != None):            
                            if(not pdf_modelinputs[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                        (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[8]) &
                                                        (pdf_modelinputs['Country_Name'] == country)].empty):
                                Pos200 = pdf_modelinputs.loc[(pdf_modelinputs['Lowest_Level_Portfolio_Name'] == segmentmapping_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_modelinputs['Scenario_Name'] == sensitivitygrid_row[8]) &
                                                            (pdf_modelinputs['Country_Name'] == country), 
                                                            config_modelinputs_row.ForecastingInput].values[0]
                                
                        # print('Total: ' + str(TotalNeg200) + ' / ' + str(TotalNeg100) + ' / ' + str(TotalNeg50)+ ' / 0 / ' + str(TotalPos50) + ' / ' + str(TotalPos100) + ' / ' + str(TotalPos200))
                        # print('Row: ' + str(Neg200) + ' / ' + str(Neg100) + ' / ' + str(Neg50)+ ' / 0 / ' + str(Pos50) + ' / ' + str(Pos100) + ' / ' + str(Pos200))
                        
                        Neg100 -= TotalNeg100
                        Neg50 -= TotalNeg50
                        Pos50 -= TotalPos50
                        Pos100 -= TotalPos100
                        # print(str(sensitivitygrid_row[0]) + ' --- ' + str(len(pdf_config_sensitivitygrid)))
                        if(sensitivitygrid_row[0] == len(pdf_config_sensitivitygrid) - 1):            
                            pdf_sensitivitygrid_new = pd.concat([pdf_sensitivitygrid_new, pd.DataFrame({'Country_Name': [country], 
                                                                                                'Lowest_Level_Portfolio_Name': [segmentmapping_row.Lowest_Level_Portfolio_Name],  
                                                                                                'Currency_Code': [segmentmapping_row.Currency_Code],
                                                                                                'InputType': [config_modelinputs_row.ForecastingInput],
                                                                                                'Tenor': [sensitivitygrid_row[1]], 
                                                                                                'Neg200': [Neg200], 
                                                                                                'Neg100': [TotalNeg100], 
                                                                                                'Neg50': [TotalNeg50], 
                                                                                                'Base': [0], 
                                                                                                'Pos50': [TotalPos50], 
                                                                                                'Pos100': [TotalPos100], 
                                                                                                'Pos200': [Pos200]})],ignore_index=True)
                            
                            NegMultiplier = 0
                            PosMultiplier = 0

                            for pdf_sensitivitygrid_new_row in reversed(list(pdf_sensitivitygrid_new.itertuples())):
                                if(pdf_sensitivitygrid_new_row.Index == len(pdf_sensitivitygrid_new) - 1):
                                    if((pdf_sensitivitygrid_new_row.Neg100 + (pdf_sensitivitygrid_new_row.Neg100 - pdf_sensitivitygrid_new_row.Neg50) *2) != 0):
                                        NegMultiplier = (pdf_sensitivitygrid_new_row.Neg200 / (pdf_sensitivitygrid_new_row.Neg100 + (pdf_sensitivitygrid_new_row.Neg100 - pdf_sensitivitygrid_new_row.Neg50) *2))
                                    if((pdf_sensitivitygrid_new_row.Pos100 + (pdf_sensitivitygrid_new_row.Pos100 - pdf_sensitivitygrid_new_row.Pos50) *2) != 0):
                                        PosMultiplier = (pdf_sensitivitygrid_new_row.Pos200 / (pdf_sensitivitygrid_new_row.Pos100 + (pdf_sensitivitygrid_new_row.Pos100 - pdf_sensitivitygrid_new_row.Pos50) *2))
                                else:
                                    
                                    pdf_sensitivitygrid_new.loc[pdf_sensitivitygrid_new_row.Index, 'Neg200'] = (pdf_sensitivitygrid_new_row.Neg100 + 
                                                                                                                (pdf_sensitivitygrid_new_row.Neg100 - pdf_sensitivitygrid_new_row.Neg50) *2) * NegMultiplier
                                    pdf_sensitivitygrid_new.loc[pdf_sensitivitygrid_new_row.Index, 'Pos200'] = (pdf_sensitivitygrid_new_row.Pos100 + 
                                                                                                                (pdf_sensitivitygrid_new_row.Pos100 -pdf_sensitivitygrid_new_row.Pos50) *2) * PosMultiplier
                                    
                            # break
                            
                        else:
                            pdf_sensitivitygrid_new = pd.concat([pdf_sensitivitygrid_new, pd.DataFrame({'Country_Name': [country], 
                                                                                                'Lowest_Level_Portfolio_Name': [segmentmapping_row.Lowest_Level_Portfolio_Name], 
                                                                                                'Currency_Code': [segmentmapping_row.Currency_Code],
                                                                                                'InputType': [config_modelinputs_row.ForecastingInput],
                                                                                                'Tenor': [sensitivitygrid_row[1]], 
                                                                                                'Neg200': [Neg200], 
                                                                                                'Neg100': [Neg100], 
                                                                                                'Neg50': [Neg50], 
                                                                                                'Base': [0], 
                                                                                                'Pos50': [Pos50], 
                                                                                                'Pos100': [Pos100], 
                                                                                                'Pos200': [Pos200]})],ignore_index=True)             

                        TotalNeg100 += Neg100
                        TotalNeg50 += Neg50
                        TotalPos50 += Pos50
                        TotalPos100 += Pos100

                    pdf_sensitivitygrid = pd.concat([pdf_sensitivitygrid, pdf_sensitivitygrid_new],ignore_index=True)

    return pdf_sensitivitygrid

def format_model_inputs(pdf_modelinputs):

    pdf_modelinput_all = pd.DataFrame()

    for col in pdf_modelinputs.columns:    
        if(col not in ('Country_Name', 'Lowest_Level_Portfolio_Name', 'Scenario_Name', 'Currency_Code', 'ForecastType')):
            pdf_modelinput_new = pd.DataFrame()
            pdf_modelinput_new['Country_Name'] = pdf_modelinputs['Country_Name']
            pdf_modelinput_new['Lowest_Level_Portfolio_Name']= pdf_modelinputs['Lowest_Level_Portfolio_Name']
            pdf_modelinput_new['Scenario_Name']= pdf_modelinputs['Scenario_Name']
            pdf_modelinput_new['Currency_Code']= pdf_modelinputs['Currency_Code']
            pdf_modelinput_new['ForecastType']= pdf_modelinputs['ForecastType']
            pdf_modelinput_new['ModelInput']= col
            pdf_modelinput_new['Amount']= pdf_modelinputs[col]
            pdf_modelinput_all = pd.concat([pdf_modelinput_all, pdf_modelinput_new], axis=0, ignore_index=True)

    return pdf_modelinput_all    

def get_interpolation(pdf_sensitivitygrid, pdf_blendingmarketinputs, periods):
    pdf_interpolation = pd.DataFrame(columns=interpolation_columns)    

    for sensitivity_row in pdf_sensitivitygrid.itertuples():
        if 'YR' in str(sensitivity_row.Tenor).upper():
            pdf_interpolation_new = pd.DataFrame(columns=interpolation_columns)
            pdf_interpolation_new['Country_Name'] = [sensitivity_row.Country_Name]        
            pdf_interpolation_new['Lowest_Level_Portfolio_Name'] = [sensitivity_row.Lowest_Level_Portfolio_Name]
            pdf_interpolation_new['Currency_Code'] = [sensitivity_row.Currency_Code]
            pdf_interpolation_new['InputType'] = sensitivity_row.InputType
            pdf_interpolation_new['Tenor'] = sensitivity_row.Tenor
        
            interpolation_rate = [sensitivity_row.Neg200, 
                                sensitivity_row.Neg100, 
                                sensitivity_row.Neg50, 
                                sensitivity_row.Base, 
                                sensitivity_row.Pos50, 
                                sensitivity_row.Pos100, 
                                sensitivity_row.Pos200]
            
            for rate_change_column in pdf_interpolation.columns:
                if 'Rate_Change' in rate_change_column:
                    tenor = int(str(sensitivity_row.Tenor).upper().replace('YR', '')) 
                    if(not pdf_blendingmarketinputs.loc[(pdf_blendingmarketinputs['Lowest_Level_Portfolio_Name'] == sensitivity_row.Lowest_Level_Portfolio_Name) &
                                                            (pdf_blendingmarketinputs['Currency_Code'] == sensitivity_row.Currency_Code) &
                                                            (pdf_blendingmarketinputs['Tenor'] == tenor), rate_change_column].empty):               
                        rate_change = pdf_blendingmarketinputs.loc[(pdf_blendingmarketinputs['Lowest_Level_Portfolio_Name'] == sensitivity_row.Lowest_Level_Portfolio_Name) &
                                                                (pdf_blendingmarketinputs['Currency_Code'] == sensitivity_row.Currency_Code) &
                                                                (pdf_blendingmarketinputs['Tenor'] == tenor), rate_change_column].values[0]
                    else:
                        rate_change = 0
                    pdf_interpolation_new[rate_change_column] = cubic_spline_interpolation(periods, interpolation_rate, rate_change)

            pdf_interpolation = pd.concat([pdf_interpolation, pdf_interpolation_new],ignore_index=True)

    pdf_interpolation_llps = pdf_interpolation[['Country_Name', 'Lowest_Level_Portfolio_Name', 'Currency_Code']].drop_duplicates()
    pdf_interpolation_summary = pd.DataFrame()
    for llps in pdf_interpolation_llps.itertuples():    
        pdf_interpolation_summary_new = pdf_interpolation[(pdf_interpolation['Country_Name'] == llps.Country_Name) &
                                        (pdf_interpolation['Lowest_Level_Portfolio_Name'] == llps.Lowest_Level_Portfolio_Name) &
                                        (pdf_interpolation['Currency_Code'] == llps.Currency_Code)] \
                                                .groupby(['Country_Name', 'Lowest_Level_Portfolio_Name', 'Currency_Code']).sum(numeric_only=True).reset_index()    
        pdf_interpolation_summary = pd.concat([pdf_interpolation_summary, pdf_interpolation_summary_new],ignore_index=True)
    
    # display(pdf_interpolation_summary)

    return pdf_interpolation_summary    

def get_forecast(pdf_interpolation, pdf_config_forecastdetails):
    pdf_forecast = pd.DataFrame(columns=forecast_columns)

    taxindicator = pdf_config_forecastdetails[2]
    bsc_name = pdf_config_forecastdetails[1]
    ifrsec_name = pdf_config_forecastdetails[3]

    for interpolation in pdf_interpolation.itertuples():
        # print(interpolation)    
        for col in pdf_interpolation.columns:
            if('Total_Rate_Change' in col and 'Base' not in col):            
                pdf_forecast_new = pd.DataFrame(columns=forecast_columns)
                pdf_forecast_new['Country_Name'] = [interpolation.Country_Name]
                pdf_forecast_new['Currency_Code'] = interpolation.Currency_Code
                pdf_forecast_new['Tax_Indicator_Name'] = taxindicator
                pdf_forecast_new['Lowest_Level_Portfolio_Name'] = interpolation.Lowest_Level_Portfolio_Name
                pdf_forecast_new['Balance_Sheet_Component_Name'] = bsc_name
                pdf_forecast_new['IFRS_Earnings_Component_Name'] = ifrsec_name
                pdf_forecast_new['Scenario_Name'] = col.replace('Total_Rate_Change_', 'RF ')
                pdf_forecast_new['Amount'] = pdf_interpolation.iloc[interpolation.Index][col] - interpolation.Total_Rate_Change_Base
                pdf_forecast = pd.concat([pdf_forecast, pdf_forecast_new], ignore_index=True)
            
    return pdf_forecast    