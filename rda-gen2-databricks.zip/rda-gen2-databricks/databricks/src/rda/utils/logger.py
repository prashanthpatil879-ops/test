import logging
import sys

def configure_logging(log_level: str) -> None:
  logging.basicConfig(
    stream=sys.stdout,
    level=getattr(logging, log_level.upper(), logging.INFO),
    format='[%(asctime)s] - %(levelname)s - %(name)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
  )
  logging.getLogger("azure").setLevel(logging.WARNING)

def get_logger(name: str) -> logging.Logger:
  return logging.getLogger(name)

def get_notebook_logger() -> logging.Logger:
  try:
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    notebook_path = ctx.notebookPath().get()
    notebook_name = notebook_path.strip("/").split('/')[-1]
  except:
    notebook_name = "Interactive Notebook"
  return logging.getLogger("notebook_name")
