from azure.identity import ClientSecretCredential
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, col, upper, regexp_replace
from datetime import datetime

def get_sql_token(tenant_id, client_id, client_secret):
    credential = ClientSecretCredential(tenant_id, client_id, client_secret)
    token = credential.get_token("https://database.windows.net/.default")
    return token.token

def get_sql_dimension(dim_name, access_token, jdbc_url, dim_list=None, name_column='', insertnew = 0):

    spark = SparkSession.builder.getOrCreate()

    query = f"(SELECT * FROM {dim_name} WHERE Is_Active = 1) as {dim_name}"

    df = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("dbtable", query) \
        .option("accessToken", access_token) \
        .option("encrypt", "true") \
        .option("hostNameInCertificate", "*.database.windows.net") \
        .load()

    if insertnew:
        
        df_current = df.select(upper(regexp_replace(col(name_column), " ", "")).alias(name_column))
        dim_list = dim_list.select(upper(regexp_replace(col(name_column), " ", "")).alias(name_column),
                                   col(name_column).alias(name_column + "_Original"))
        
        new_dims = dim_list.join(df_current, dim_list[name_column] == df_current[name_column], "left_anti")
        
        new_dims = new_dims.select(col(name_column + "_Original").alias(name_column))

        if(new_dims.count() > 0):

            new_dims = new_dims.withColumn('Is_Active', lit(True))
            new_dims = new_dims.withColumn('Sys_Create_Date', lit(datetime.now()))
            new_dims = new_dims.withColumn('Sys_Create_By', lit('ADB'))
            new_dims = new_dims.withColumn('Start_Date', lit(datetime.now()))

            new_dims.write \
                .format("jdbc") \
                .option("url", jdbc_url) \
                .option("dbtable", dim_name) \
                .option("accessToken", access_token) \
                .option("encrypt", "true") \
                .option("hostNameInCertificate", "*.database.windows.net") \
                .mode("append") \
                .save()

            df = spark.read \
                .format("jdbc") \
                .option("url", jdbc_url) \
                .option("dbtable", query) \
                .option("accessToken", access_token) \
                .option("encrypt", "true") \
                .option("hostNameInCertificate", "*.database.windows.net") \
                .load()    
    
    return df


def get_sql_query(sql_query, access_token, jdbc_url):

    spark = SparkSession.builder.getOrCreate()

    query = f"(SELECT * FROM ({sql_query}) AS vw) as query"

    df = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("dbtable", query) \
        .option("accessToken", access_token) \
        .option("encrypt", "true") \
        .option("hostNameInCertificate", "*.database.windows.net") \
        .load()
    
    return df


def save_sql_run_data(df_run, df_run_details, access_token, jdbc_url, table_prefix):

    spark = SparkSession.builder.getOrCreate()
    
    run_table_name = table_prefix + 'Fact_Run'
    run_details_table_name = ''    

    if(df_run.count()!=1): return 'df_run has no or multiple rows'        

    processname = df_run.first()['Process_Name']
    inputfilename = df_run.first()['InputFileName']
    processstartdate = str(df_run.first()['Process_Start_Date'])

    df_run.write \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("dbtable", run_table_name) \
        .option("accessToken", access_token) \
        .option("encrypt", "true") \
        .option("hostNameInCertificate", "*.database.windows.net") \
        .mode("append") \
        .save()

    run_table_name =  "(SELECT * FROM " + run_table_name + " WHERE Process_Name = '" + processname + \
                        "' AND InputFileName = '" + inputfilename + \
                        "' AND Process_Start_Date = CAST(CAST('" + processstartdate + \
                        "' as datetime2) as datetime)) AS Fact_run"

    df_run = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("dbtable", run_table_name) \
        .option("accessToken", access_token) \
        .option("encrypt", "true") \
        .option("hostNameInCertificate", "*.database.windows.net") \
        .load()

    df_run_details = df_run_details.withColumn('Run_Key', lit(df_run.first()['Run_Key']))
    print(processname)

    if processname.startswith('Consolidated Sensitivities Results'):
        run_details_table_name = table_prefix + 'Fact_Actuals'
    elif processname == 'ALM Sensitivities Forecast':
        run_details_table_name = table_prefix + 'Fact_Forecasts'
    elif processname == 'Consolidated Sensitivities Segment Mapping':
        run_details_table_name = table_prefix + 'Fact_Heirarchy_Mapping'
    elif processname == 'IR Ear RF Daily Forecasting':
        run_details_table_name = table_prefix + 'Fact_DailyForecasts'
    else:
        run_details_table_name = ''

    df_run_details.write \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("dbtable", run_details_table_name) \
        .option("accessToken", access_token) \
        .option("encrypt", "true") \
        .option("hostNameInCertificate", "*.database.windows.net") \
        .mode("append") \
        .save()