from pyspark.sql import DataFrame
from pyspark.sql import functions as F, Window
from typing import NamedTuple
from rda.engine.base_step import RDABaseStep
import rda.utils.spark_utils as su
from datetime import datetime

class StressTestLiabilityImpactInputs(NamedTuple):
    gam_sensitivity_df: DataFrame
    heirarchy_mapping_latest_df: DataFrame

class StressTestLiabilityImpact(RDABaseStep):

    def __init__(self, env_config, spark, step_config):
        super().__init__(env_config, spark, step_config)

    def read(self) -> StressTestLiabilityImpactInputs:
        inputs = self._step_config.inputs

        gam_part1_date = self._uc.read_query(f"SELECT max(Reporting_Date) as RD FROM {inputs.gam_sensitivities.table_name} WHERE Source_File like '%part 1%'").first()["RD"]
        gam_part2_date = self._uc.read_query(f"SELECT max(Reporting_Date) as RD FROM {inputs.gam_sensitivities.table_name} WHERE Source_File like '%part 2%'").first()["RD"]

        self._logger.info(f"Reading inputs for ST Liability Impact: GAM Part 1 Date: {gam_part1_date}, GAM Part 2 Date: {gam_part2_date}")

        gam_part1_df = self._uc.read_latest(inputs.gam_sensitivities.table_name, \
            filter=f"Reporting_Date='{gam_part1_date}' and Source_File like '%part 1%' and Tax_Indicator_Name='Post-Tax, Post-MI' and Balance_Sheet_Component_Name in ('Net Impact', 'Assets Summary', 'Liabilities summary') and IFRS_Earnings_Component_Name in ('P&L', 'OCI', 'Impacts absorbed by CSM') and Scenario_Name in ('CS +50bps', 'CS -50bps', 'SS +20bps', 'SS -20bps', 'Partial RF-50, all tenors up to 2yr', 'Partial RF-50, all tenors up to 5yr', 'Partial RF-50, all tenors up to 7yr', 'Partial RF-50, all tenors up to 10yr', 'Partial RF-50, all tenors up to 20yr', 'RF -50bps', 'Partial RF+50, all tenors up to 2yr', 'Partial RF+50, all tenors up to 5yr', 'Partial RF+50, all tenors up to 7yr', 'Partial RF+50, all tenors up to 10yr', 'Partial RF+50, all tenors up to 20yr', 'RF +50bps', 'Partial RF-100, all tenors up to 2yr', 'Partial RF-100, all tenors up to 5yr', 'Partial RF-100, all tenors up to 7yr', 'Partial RF-100, all tenors up to 10yr', 'Partial RF-100, all tenors up to 20yr', 'RF -100bps', 'Partial RF+100, all tenors up to 2yr', 'Partial RF+100, all tenors up to 5yr', 'Partial RF+100, all tenors up to 7yr', 'Partial RF+100, all tenors up to 10yr', 'Partial RF+100, all tenors up to 20yr', 'RF +100bps')"
        )
        gam_part2_df = self._uc.read_latest(inputs.gam_sensitivities.table_name, filter=f"Reporting_Date='{gam_part2_date}' and Source_File like '%part 2%'")

        input_dfs = StressTestLiabilityImpactInputs(
            gam_sensitivity_df = gam_part1_df.unionByName(gam_part2_df),
            heirarchy_mapping_latest_df = self._uc.read_latest(inputs.heirarchy_mapping_latest.table_name, watermark_col=inputs.heirarchy_mapping_latest.watermark_col)
        )

        self.validate_inputs(input_dfs)
        return input_dfs
    

    def step_es_fi_sensitivity(self, inputs: StressTestLiabilityImpactInputs) -> DataFrame:
        self._logger.info(f"Calculating stress test ES FI sensitivity...")
        
        es_fi_sensitivity_base_df = (
            inputs.gam_sensitivity_df.alias("gam")
            .join(
                inputs.heirarchy_mapping_latest_df.alias("h"),
                on = su.normalize_text(F.col("gam.Lowest_Level_Portfolio_Name")) == su.normalize_text(F.col("h.LOWEST_LEVEL_PORTFOLIO_NAME")),
                how = "inner"
            )
            .select("gam.*", "h.TARGET_CURRENCY_NAME")
        )

        es_mapping = {
            "CS +50bps": "CS +50bps",
            "CS -50bps": "CS -50bps",
            "SS +20bps": "SS +20bps",
            "SS -20bps": "SS -20bps",

            "Partial RF-50, all tenors up to 2yr": "RF -50bps 2yr Only",
            "Partial RF-50, all tenors up to 5yr": "RF -50bps 5yr Only",
            "Partial RF-50, all tenors up to 7yr": "RF -50bps 7yr Only",
            "Partial RF-50, all tenors up to 10yr": "RF -50bps 10yr Only",
            "Partial RF-50, all tenors up to 20yr": "RF -50bps 20yr Only",
            "RF -50bps": "RF -50bps 30yr Only",

            "Partial RF+50, all tenors up to 2yr": "RF +50bps 2yr Only",
            "Partial RF+50, all tenors up to 5yr": "RF +50bps 5yr Only",
            "Partial RF+50, all tenors up to 7yr": "RF +50bps 7yr Only",
            "Partial RF+50, all tenors up to 10yr": "RF +50bps 10yr Only",
            "Partial RF+50, all tenors up to 20yr": "RF +50bps 20yr Only",
            "RF +50bps": "RF +50bps 30yr Only",

            "Partial RF-100, all tenors up to 2yr": "RF -100bps 2yr Only",
            "Partial RF-100, all tenors up to 5yr": "RF -100bps 5yr Only",
            "Partial RF-100, all tenors up to 7yr": "RF -100bps 7yr Only",
            "Partial RF-100, all tenors up to 10yr": "RF -100bps 10yr Only",
            "Partial RF-100, all tenors up to 20yr": "RF -100bps 20yr Only",
            "RF -100bps": "RF -100bps 30yr Only",

            "Partial RF+100, all tenors up to 2yr": "RF +100bps 2yr Only",
            "Partial RF+100, all tenors up to 5yr": "RF +100bps 5yr Only",
            "Partial RF+100, all tenors up to 7yr": "RF +100bps 7yr Only",
            "Partial RF+100, all tenors up to 10yr": "RF +100bps 10yr Only",
            "Partial RF+100, all tenors up to 20yr": "RF +100bps 20yr Only",
            "RF +100bps": "RF +100bps 30yr Only",
        }

        exprs = []
        for k, v in es_mapping.items():
            exprs.extend([F.lit(k), F.lit(v)])

        mapping_expr = F.create_map(*exprs)

        es_fi_sensitivity_base_df = es_fi_sensitivity_base_df.withColumn(
            "ES_SENSITIVITY_NAME",
            mapping_expr[F.col("Scenario_Name")]
        )

        # ga_b1_derive_df = self.cache_df(ga_b1_derive_df, "ga_b1_derive_df")
        # ga_b1_derive_alda_pe_df = ga_b1_derive_df.filter( F.col("ADJUSTED_ASSET_GROUP").isin(["ALDA", "Public Equity"]) )

        # self.write(ga_b1_derive_df, self._step_config.step_asset_impact_ga.table_name, self._step_config.step_asset_impact_ga.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        # self.write(ga_b1_derive_alda_pe_df, self._step_config.step_asset_impact_pe_alda.table_name, self._step_config.step_asset_impact_pe_alda.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        
        self._logger.info("Calculating stress test ES FI sensitivity completed.")
        return es_fi_sensitivity_base_df
    