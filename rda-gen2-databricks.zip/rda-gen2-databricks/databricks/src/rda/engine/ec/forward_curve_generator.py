from pyspark.sql import DataFrame
from pyspark.sql import functions as F, Window
from pyspark.sql.types import DoubleType, StructField
import pandas as pd
from typing import NamedTuple
from rda.engine.base_step import RDABaseStep
import rda.utils.spark_utils as su
from functools import reduce


def bootstrap_df_udf(pdf: pd.DataFrame) -> pd.DataFrame:
    pdf = pdf.sort_values("TENOR_YEARS_INTV").reset_index(drop=True)

    dfs = []
    cumulative_sum = 0.0

    for _, row in pdf.iterrows():
        t = row["TENOR_YEARS_INTV"]
        y = row["LINEAR_INTERP_YIELD"]

        if t <= 30:
            y_half = y / 2
            df = (1 - (y_half * cumulative_sum)) / (1 + y_half)
            cumulative_sum += df
        else:
            df = (1 + y) ** (-t)
        dfs.append(df)

    pdf["BOOTSTRAP_DF"] = dfs
    return pdf


class ForwardCurveGeneratorInputs(NamedTuple):
    ir_bey_df: DataFrame
    ref_portfolio_code_df: DataFrame
    irr_mapping_dim_bey_row_tenor_df: DataFrame
    mapping_dim_tenors_df: DataFrame
    shock_approx_df: DataFrame


class ForwardCurveGenerator(RDABaseStep):
    
    def read(self) -> ForwardCurveGeneratorInputs:
        inputs = self._step_config.inputs
        last_quarter_end_date = self._date_ctx.asDict().get('PREVIOUSQUARTERENDDATE', None)
        forecast_date = self._date_ctx.asDict().get('FORECAST_DATE', None)
        self._logger.info(f"Reading inputs for Foward Curve Generator, Quarter End Date: {last_quarter_end_date}, Forecast Date: {forecast_date}")

        if last_quarter_end_date is None or forecast_date is None:
            raise ValueError(f"Invalid date context entry for PREVIOUSQUARTERENDDATE or FORECAST_DATE in: {self._date_ctx.asDict()}")
        elif forecast_date <= last_quarter_end_date:
            raise ValueError(f"FORECAST_DATE '{forecast_date}' is after PREVIOUSQUARTERENDDATE '{last_quarter_end_date}'...")

        ir_bey_base_df = self._uc.read_query(f"SELECT * FROM {inputs.ir_bey.table_name} WHERE upper(TABLENAME) like '%BASE%' AND to_date(CREATEDTIMESTAMP) > '{last_quarter_end_date}'")

        ir_bey_base_df = (
            ir_bey_base_df
            .withColumn("RANK", F.row_number().over(Window.partitionBy("TABLENAME", "ROW")
                .orderBy(F.desc("CREATEDTIMESTAMP"))))
            .filter(F.col("RANK") == 1)
            .drop("RANK")
        )

        input_dfs = ForwardCurveGeneratorInputs(
            ir_bey_df = ir_bey_base_df,
            ref_portfolio_code_df = self._uc.read_latest(inputs.ref_portfolio_code.table_name),
            irr_mapping_dim_bey_row_tenor_df = self._uc.read_latest(inputs.irr_mapping_dim_bey_row_tenor.table_name, watermark_col=inputs.irr_mapping_dim_bey_row_tenor.watermark_col),
            mapping_dim_tenors_df = self._uc.read_latest(inputs.mapping_dim_tenors.table_name, watermark_col=inputs.mapping_dim_tenors.watermark_col),
            shock_approx_df = self._uc.read_latest(
                inputs.shock_approx.table_name, 
                filter=f"REPORTING_DATE='{last_quarter_end_date}' AND FORECAST_DATE='{forecast_date}'"
            )
        )

        self.validate_inputs(input_dfs)
        return input_dfs
    
    def generate_bey_rates(self, inputs: ForwardCurveGeneratorInputs):
        self._logger.info("Generating BEY rates...")

        conditions = [
            (F.col("ref_port.NAME") == segment) &
            (F.col("bey.CURRENCY_CODE") == currency)
            for segment, currency in self._step_config.config.selected_segments
        ]

        ir_bey_extracted_df = (
            inputs.ir_bey_df
            .withColumn("ASR_INDICATOR", F.substring(F.col("TABLENAME"), 1, 4) )
            .withColumn("LOB_COUNTRY_CODE", F.substring(F.col("TABLENAME"), 6, 2) )
            .withColumn("RATE_TYPE", F.substring(F.col("TABLENAME"), 9, 3) )
            .withColumn("QE_FC_DATA", F.substring(F.col("TABLENAME"), 13, 4) )
            .withColumn("CURRENCY_CODE", F.substring(F.col("TABLENAME"), 18, 3) )
            .withColumn("COG_INDICATOR", F.substring(F.col("TABLENAME"), 38, 4) )
            .withColumn("RATE", F.when( F.col("COG_INDICATOR")=='_DFT', F.col("C1") * -1).otherwise(F.col("C1")) )
            .withColumn("REF_PORTFOLIO_CODE", F.substring(F.col("TABLENAME"), 21, 16) )
            .filter( (F.col("ASR_INDICATOR") == 'INTR') 
                    & (F.col("RATE_TYPE") == 'BEY') 
                    & (F.col("COG_INDICATOR").isin('_ALP', '_CRD', '_RFR', '_SWP', '_DFT'))
            )
        )

        ir_bey_enriched_df = (
            ir_bey_extracted_df.alias("bey")
            .join(
                inputs.irr_mapping_dim_bey_row_tenor_df.alias("row_tenor"),
                on = [
                    F.col("bey.ROW") == F.col("row_tenor.ROW"),
                    F.col("bey.CURRENCY_CODE") == F.col("row_tenor.CURRENCY")
                ],
                how = "inner"
            )
            .join(
                inputs.ref_portfolio_code_df.alias("ref_port"),
                on = [
                    F.col("bey.REF_PORTFOLIO_CODE") == F.col("ref_port.REFERENCEPORTFOLIOCODE")
                ],
                how = "inner"
            )
            .join(
                inputs.mapping_dim_tenors_df.alias("tenors"),
                on = F.col("row_tenor.TENOR_YEARS") == F.col("tenors.TENOR_YEARS")
            )
            .filter(
                reduce(lambda a, b: a | b, conditions)
            )
            .select(
                F.col("bey.CURRENCY_CODE"),
                F.col("bey.COG_INDICATOR"),
                F.col("bey.RATE"),
                F.col("ref_port.NAME").alias("LIABILITY_SEGMENT_NAME"),
                F.col("tenors.TENOR_MONTHS"),
                F.col("tenors.IS_URR"),
                F.col("bey.CREATEDTIMESTAMP")
            )
            .withColumn("RATE_TYPE", F.lit("Liability Discount"))
            .withColumn("CREATEDDATE", F.to_date(F.from_utc_timestamp(F.to_timestamp(F.col("CREATEDTIMESTAMP"), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"), "America/Toronto")))
        )

        ir_bey_rates_output_df = (
            ir_bey_enriched_df
            .filter(
                (~F.col("IS_URR")) |
                (F.col("IS_URR") & (F.col("COG_INDICATOR") == "_RFR"))
            )
            .groupBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "TENOR_MONTHS", "IS_URR", "RATE_TYPE")
            .agg(
                F.sum("RATE").alias("TOTAL_RATE"),
                F.first("CREATEDDATE").alias("CREATEDDATE")
            )
        )

        ir_bey_rates_output_df = self.cache_df(ir_bey_rates_output_df, "ir_bey_rates_output_df")

        self.write(ir_bey_rates_output_df, self._step_config.step_generate_bey_rates.table_name, self._step_config.step_generate_bey_rates.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("BEY rates generated")
        return ir_bey_rates_output_df
    
    def calculate_benchmark_yc(self, inputs: ForwardCurveGeneratorInputs, ir_bey_rates_output_df: DataFrame):
        self._logger.info("Calculating benchmark yield curve...")

        benchmark_yc_df = (
            ir_bey_rates_output_df.alias("bey")
            .join(
                inputs.shock_approx_df.alias("shocks"),
                on = [
                    F.col("bey.CURRENCY_CODE") == F.col("shocks.CURRENCY"),
                    F.col("bey.TENOR_MONTHS") == F.col("shocks.TENOR_MONTHS"),
                    F.col("bey.IS_URR") == F.col("shocks.IS_URR")
                ],
                how = "inner"
            )
            .withColumn("TENOR_YEARS", (F.col("bey.TENOR_MONTHS") / 12).cast("float"))
            .select("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO", F.col("bey.TENOR_MONTHS"), "TENOR_YEARS", F.col("bey.IS_URR"), "TOTAL_RATE", "SHOCKS_BPS")
        )

        benchmark_yc_df_qe = (
            benchmark_yc_df
            .filter(F.col("SCENARIO") == "QE")
        )

        benchmark_yc_df_base = (
            benchmark_yc_df_qe
            .withColumn("SCENARIO", F.lit("BASE"))
            .withColumn("SHOCKS_BPS", F.lit(0))
        )

        benchmark_yc_df_plus50bps = (
            benchmark_yc_df_qe
            .withColumn("SCENARIO", F.lit("RF +50bps"))
            .withColumn("SHOCKS_BPS", F.when(F.col("IS_URR"), F.lit(0)).otherwise(F.lit(50)) )
        )

        benchmark_yc_df_minus50bps = (
            benchmark_yc_df_qe
            .withColumn("SCENARIO", F.lit("RF -50bps"))
            .withColumn("SHOCKS_BPS", F.when(F.col("IS_URR"), F.lit(0)).otherwise(F.lit(-50)) )
        )

        benchmark_yc_df = benchmark_yc_df.union(benchmark_yc_df_base).union(benchmark_yc_df_plus50bps).union(benchmark_yc_df_minus50bps)

        benchmark_yc_df = (
            benchmark_yc_df
            .withColumn("IFRS17_YC", F.col("TOTAL_RATE") + (F.col("SHOCKS_BPS") / 10000) )
        )

        benchmark_yc_df = self.cache_df(benchmark_yc_df, "benchmark_yc_df")

        self.write(benchmark_yc_df, self._step_config.step_calculate_benchmark_yc.table_name, self._step_config.step_calculate_benchmark_yc.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("Benchmark yield curve calculated")
        return benchmark_yc_df
    
    def generate_bootstrap_curve(self, inputs: ForwardCurveGeneratorInputs, benchmark_yc_df: DataFrame):
        self._logger.info("Generating bootstarping curve...")

        tenor_intv_df = self._spark.range(1, 181).withColumn("TENOR_YEARS_INTV", F.col("id") / 2).drop("id")
        curve_key_df = benchmark_yc_df.select("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").distinct()

        curve_with_target_tenor_df = (
            curve_key_df
            .crossJoin(tenor_intv_df)
            .filter( (F.col("TENOR_YEARS_INTV") <= 30) | (F.col("TENOR_YEARS_INTV") >= 70) )
        )

        curve_with_known_yield_df = (
            curve_with_target_tenor_df.alias("tgt")
            .join(
                benchmark_yc_df.alias("src"),
                on = [
                    F.col("tgt.CURRENCY_CODE") == F.col("src.CURRENCY_CODE"),
                    F.col("tgt.LIABILITY_SEGMENT_NAME") == F.col("src.LIABILITY_SEGMENT_NAME"),
                    F.col("tgt.SCENARIO") == F.col("src.SCENARIO"),
                    F.col("tgt.TENOR_YEARS_INTV") == F.col("src.TENOR_YEARS")
                ],
                how = "left"
            )
            .select(
                F.col("tgt.CURRENCY_CODE"),
                F.col("tgt.LIABILITY_SEGMENT_NAME"),
                F.col("tgt.SCENARIO"),
                F.col("src.TENOR_YEARS"),
                F.col("src.IS_URR"),
                F.col("tgt.TENOR_YEARS_INTV"),
                F.col("src.IFRS17_YC")
            )
        )

        curve_with_known_yield_urr_df = (
            curve_with_known_yield_df.alias("tgt")
            .join(
                curve_with_known_yield_df.filter(F.col("IS_URR") == True).alias("urr"),
                on = [
                    F.col("tgt.CURRENCY_CODE") == F.col("urr.CURRENCY_CODE"),
                    F.col("tgt.LIABILITY_SEGMENT_NAME") == F.col("urr.LIABILITY_SEGMENT_NAME"),
                    F.col("tgt.SCENARIO") == F.col("urr.SCENARIO"),
                    F.col("tgt.TENOR_YEARS_INTV") >= F.col("urr.TENOR_YEARS")
                ],
                how = "left"
            )
            .select(
                F.col("tgt.CURRENCY_CODE"),
                F.col("tgt.LIABILITY_SEGMENT_NAME"),
                F.col("tgt.SCENARIO"),
                F.col("tgt.TENOR_YEARS"),
                F.col("tgt.IS_URR"),
                F.col("tgt.TENOR_YEARS_INTV"),
                F.coalesce(F.col("tgt.IFRS17_YC"), F.col("urr.IFRS17_YC")).alias("IFRS17_YC")
            )
        )

        window_prev = Window.partitionBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").orderBy("TENOR_YEARS_INTV").rowsBetween(Window.unboundedPreceding, 0)
        window_next = Window.partitionBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").orderBy("TENOR_YEARS_INTV").rowsBetween(0, Window.unboundedFollowing)

        curve_with_known_yield_coordinates_df = (
            curve_with_known_yield_urr_df
            .withColumn("PREV_KNOWN_TENOR_YEARS", F.last(F.when(F.col("IFRS17_YC").isNotNull(), F.col("TENOR_YEARS_INTV")), ignorenulls=True).over(window_prev))
            .withColumn("PREV_KNOWN_YIELD", F.last(F.col("IFRS17_YC"), ignorenulls=True).over(window_prev))
            .withColumn("NEXT_KNOWN_TENOR_YEARS", F.first(F.when(F.col("IFRS17_YC").isNotNull(), F.col("TENOR_YEARS_INTV")), ignorenulls=True).over(window_next))
            .withColumn("NEXT_KNOWN_YIELD", F.first(F.col("IFRS17_YC"), ignorenulls=True).over(window_next))
        )

        curve_log_linear_interp_df = (
            curve_with_known_yield_coordinates_df
            .withColumn(
                "LINEAR_INTERP_YIELD",
                F.when(
                    F.col("IFRS17_YC").isNotNull(),
                    F.col("IFRS17_YC")
                ).otherwise(
                    F.col("PREV_KNOWN_YIELD") + ( (F.col("NEXT_KNOWN_YIELD") - F.col("PREV_KNOWN_YIELD")) * (F.col("TENOR_YEARS_INTV") - F.col("PREV_KNOWN_TENOR_YEARS")) / (F.col("NEXT_KNOWN_TENOR_YEARS") - F.col("PREV_KNOWN_TENOR_YEARS")) )
                )
            )
        )

        out_schema = curve_log_linear_interp_df.schema
        out_schema = out_schema.add(StructField("BOOTSTRAP_DF", DoubleType()))

        curve_bootstrap_discount_factor_df = (
            curve_log_linear_interp_df
            .groupBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO")
            .applyInPandas(bootstrap_df_udf, schema=out_schema)
        )

        curve_bootstrap_discount_factor_df = curve_bootstrap_discount_factor_df.select(
            "CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO", F.col("TENOR_YEARS_INTV").alias("TENOR_YEARS"), "LINEAR_INTERP_YIELD", "BOOTSTRAP_DF"
        )

        curve_bootstrap_discount_factor_df = self.cache_df(curve_bootstrap_discount_factor_df, "curve_bootstrap_discount_factor_df")

        self.write(curve_bootstrap_discount_factor_df, self._step_config.step_bootstrap_df.table_name, self._step_config.step_bootstrap_df.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("Bootstrap discount factor completed")
        return curve_bootstrap_discount_factor_df

    def extrapolate_output_spot(self, inputs: ForwardCurveGeneratorInputs, curve_bootstrap_discount_factor_df: DataFrame):
        self._logger.info("Started the process of extrapolating to generate output spot...")

        tenor_intv_df = self._spark.range(1, 201).withColumn("TENOR_EXTERP_YEARS", F.col("id") / 2).drop("id")
        curve_key_df = curve_bootstrap_discount_factor_df.select("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").distinct()

        curve_with_target_tenor_df = (
            curve_key_df
            .crossJoin(tenor_intv_df)
        )

        curve_bootstarp_extrap_base_df = (
            curve_with_target_tenor_df.alias("tgt")
            .join(
                curve_bootstrap_discount_factor_df.alias("src"),
                on = [
                    F.col("tgt.CURRENCY_CODE") == F.col("src.CURRENCY_CODE"),
                    F.col("tgt.LIABILITY_SEGMENT_NAME") == F.col("src.LIABILITY_SEGMENT_NAME"),
                    F.col("tgt.SCENARIO") == F.col("src.SCENARIO"),
                    F.col("tgt.TENOR_EXTERP_YEARS") == F.col("src.TENOR_YEARS")
                ],
                how = "left"
            )
            .select("tgt.*", "src.TENOR_YEARS", "src.LINEAR_INTERP_YIELD", "src.BOOTSTRAP_DF")
        )

        curve_bootstarp_extrap_ranked_df = (
            curve_bootstarp_extrap_base_df
            .filter( F.col("BOOTSTRAP_DF").isNotNull() )
            .withColumn("RANK", F.row_number().over(Window.partitionBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").orderBy(F.col("TENOR_EXTERP_YEARS").desc())))
            .filter(F.col("RANK") <= 2)
        )

        curve_extrap_morethan90_df = (
            curve_bootstarp_extrap_ranked_df
            .groupBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO")
            .agg(
                F.max(F.when(F.col("RANK") == 2, F.col("TENOR_EXTERP_YEARS"))).alias("T0"),
                F.max(F.when(F.col("RANK") == 2, F.col("BOOTSTRAP_DF"))).alias("DF0"),
                F.max(F.when(F.col("RANK") == 1, F.col("TENOR_EXTERP_YEARS"))).alias("T1"),
                F.max(F.when(F.col("RANK") == 1, F.col("BOOTSTRAP_DF"))).alias("DF1")
            )
            .select("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO", "T0", "DF0", "T1", "DF1")
        )

        win_prev = Window.partitionBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").orderBy(F.col("TENOR_EXTERP_YEARS")).rowsBetween(Window.unboundedPreceding, 0)
        win_next = Window.partitionBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").orderBy(F.col("TENOR_EXTERP_YEARS")).rowsBetween(0, Window.unboundedFollowing)

        curve_bootstarp_extrap_anchors_df = (
            curve_bootstarp_extrap_base_df
            .withColumn("T0", F.last(F.when(F.col("BOOTSTRAP_DF").isNotNull(), F.col("TENOR_EXTERP_YEARS")), ignorenulls=True).over(win_prev))
            .withColumn("DF0", F.last(F.col("BOOTSTRAP_DF"), ignorenulls=True).over(win_prev))
            .withColumn("T1", F.first(F.when(F.col("BOOTSTRAP_DF").isNotNull(), F.col("TENOR_EXTERP_YEARS")), ignorenulls=True).over(win_next))
            .withColumn("DF1", F.first(F.col("BOOTSTRAP_DF"), ignorenulls=True).over(win_next))
        )

        curve_bootstarp_extrap_anchors_df = (
            curve_bootstarp_extrap_anchors_df
            .withColumn("T0", F.when(F.col("TENOR_EXTERP_YEARS") > 90, F.lit(None)).otherwise(F.col("T0")))
            .withColumn("DF0", F.when(F.col("TENOR_EXTERP_YEARS") > 90, F.lit(None)).otherwise(F.col("DF0")))
            .withColumn("T1", F.when(F.col("TENOR_EXTERP_YEARS") > 90, F.lit(None)).otherwise(F.col("T1")))
            .withColumn("DF1", F.when(F.col("TENOR_EXTERP_YEARS") > 90, F.lit(None)).otherwise(F.col("DF1")))
        )

        curve_bootstarp_extrap_all_anchors_base_df = (
            curve_bootstarp_extrap_anchors_df.alias("base")
            .join(
                curve_extrap_morethan90_df.alias("ext"),
                on = [
                    F.col("base.CURRENCY_CODE") == F.col("ext.CURRENCY_CODE"),
                    F.col("base.LIABILITY_SEGMENT_NAME") == F.col("ext.LIABILITY_SEGMENT_NAME"),
                    F.col("base.SCENARIO") == F.col("ext.SCENARIO"),
                    F.col("base.TENOR_EXTERP_YEARS") > F.col("ext.T1")
                ],
                how = "left"
            )
            .select(
                "base.CURRENCY_CODE",
                "base.LIABILITY_SEGMENT_NAME",
                "base.SCENARIO",
                "base.TENOR_YEARS",
                "base.LINEAR_INTERP_YIELD",
                "base.BOOTSTRAP_DF",
                "base.TENOR_EXTERP_YEARS",
                F.coalesce(F.col("ext.T0"), F.col("base.T0")).alias("T0"),
                F.coalesce(F.col("ext.DF0"), F.col("base.DF0")).alias("DF0"),
                F.coalesce(F.col("ext.T1"), F.col("base.T1")).alias("T1"),
                F.coalesce(F.col("ext.DF1"), F.col("base.DF1")).alias("DF1")
            )
        )

        curve_extrap_intrap_discount_factor = (
            curve_bootstarp_extrap_all_anchors_base_df
            .withColumn(
                "BOOTSTRAP_DF",
                F.when(
                    F.col("BOOTSTRAP_DF").isNotNull(),
                    F.col("BOOTSTRAP_DF")
                ).otherwise(
                    F.col("DF0") * ( (F.col("DF1") / F.col("DF0")) ** ( (F.col("TENOR_EXTERP_YEARS") - F.col("T0")) / (F.col("T1") - F.col("T0")) ) )
                )
            )
            .withColumn(
                "OUTPUT_SPOT",
                (F.col("BOOTSTRAP_DF") ** (-1 / F.col("TENOR_EXTERP_YEARS"))) - 1
            )
            .drop("T0", "DF0", "T1", "DF1")
        )

        curve_extrap_intrap_discount_factor = self.cache_df(curve_extrap_intrap_discount_factor, "curve_extrap_intrap_discount_factor")

        self.write(curve_extrap_intrap_discount_factor, self._step_config.step_extrapolate_spot.table_name, self._step_config.step_extrapolate_spot.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("Extrapolation to output spot grading completed")
        return curve_extrap_intrap_discount_factor

    def generate_output(self, inputs, curve_extrap_intrap_discount_factor):
        self._logger.info("Generating forward curve outputs...")

        tenor_intv_df = self._spark.range(1, 9).withColumn("id", F.col("id")/4).union(self._spark.range(3, 101)).toDF("TENOR_INTR_YEARS")
        curve_key_df = curve_extrap_intrap_discount_factor.select("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").distinct()

        curve_with_target_tenor_df = (
            curve_key_df
            .crossJoin(tenor_intv_df)
        )

        curve_output_base_df = (
            curve_with_target_tenor_df.alias("tgt")
            .join(
                curve_extrap_intrap_discount_factor.alias("src"),
                on = [
                    F.col("tgt.CURRENCY_CODE") == F.col("src.CURRENCY_CODE"),
                    F.col("tgt.LIABILITY_SEGMENT_NAME") == F.col("src.LIABILITY_SEGMENT_NAME"),
                    F.col("tgt.SCENARIO") == F.col("src.SCENARIO"),
                    F.col("tgt.TENOR_INTR_YEARS") == F.col("src.TENOR_EXTERP_YEARS")
                ],
                how = "left"
            )
            .select("tgt.*", "src.OUTPUT_SPOT")
        )

        curve_window = Window.partitionBy("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO").orderBy("TENOR_INTR_YEARS")

        curve_output_base_all_anchors_df = (
            curve_output_base_df
            .withColumn("PREV_SPOT", F.lag("OUTPUT_SPOT", 1).over(curve_window))
            .withColumn("NEXT_SPOT", F.lead("OUTPUT_SPOT", 1).over(curve_window))
        )

        curve_output_base_all_anchors_df = (
            curve_output_base_all_anchors_df
            .withColumn(
                "ULTIMATE_SPOT",
                F.when(
                    F.col("OUTPUT_SPOT").isNotNull(),
                    F.col("OUTPUT_SPOT")
                ).otherwise(
                    F.when(
                        ( (F.col("PREV_SPOT").isNull()) & (F.col("NEXT_SPOT").isNotNull()) ),
                        F.col("NEXT_SPOT")
                    ).otherwise(
                        (F.col("PREV_SPOT") + F.col("NEXT_SPOT")) / 2
                    )
                )
            )
            .drop("PREV_SPOT", "NEXT_SPOT")
        )

        curve_output_base_fwd_rates = (
            curve_output_base_all_anchors_df
            .withColumn("PREV_TENOR", F.lag("TENOR_INTR_YEARS", 1).over(curve_window)).fillna(0)
            .withColumn("PREV_ULTIMATE_SPOT", F.lag("ULTIMATE_SPOT", 1).over(curve_window)).fillna(0)
            .withColumn(
                "FWD_RATE",
                (
                    (
                        ( 1 + F.col("ULTIMATE_SPOT")) ** F.col("TENOR_INTR_YEARS")
                    )
                    /
                    (
                        ( 1 + F.col("PREV_ULTIMATE_SPOT")) ** F.col("PREV_TENOR")
                    )
                ) - 1
            )
            .select("CURRENCY_CODE", "LIABILITY_SEGMENT_NAME", "SCENARIO", "TENOR_INTR_YEARS", "ULTIMATE_SPOT", "FWD_RATE")
        )

        self.write(curve_output_base_fwd_rates, self._step_config.output.table_name, self._step_config.output.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("Fwd Curve output generation completed")
        return curve_output_base_fwd_rates