from pyspark.sql import DataFrame
from pyspark.sql import functions as F, Window
from typing import NamedTuple
from rda.engine.base_step import RDABaseStep
import rda.utils.spark_utils as su

class ShockApproxInputs(NamedTuple):
    alm_curve_rf_qe_rates_df: DataFrame
    alm_curve_rf_fc_rates_df: DataFrame
    rf_ec_final_shocks_df: DataFrame
    ec_lower_bound_df: DataFrame
    mapping_dim_tenors_df: DataFrame

class ShockApprox(RDABaseStep):

    def read(self) -> ShockApproxInputs:
        inputs = self._step_config.inputs
        last_quarter_end_date = self._date_ctx.asDict().get('PREVIOUSQUARTERENDDATE', None)
        forecast_date = self._date_ctx.asDict().get('FORECAST_DATE', None)
        self._logger.info(f"Reading inputs for Shock Approximation, Quarter End Date: {last_quarter_end_date}, Forecast Date: {forecast_date}")

        if last_quarter_end_date is None or forecast_date is None:
            raise ValueError(f"Invalid date context entry for PREVIOUSQUARTERENDDATE or FORECAST_DATE in: {self._date_ctx.asDict()}")
        elif forecast_date <= last_quarter_end_date:
            raise ValueError(f"FORECAST_DATE '{forecast_date}' is after PREVIOUSQUARTERENDDATE '{last_quarter_end_date}'...")

        input_dfs = ShockApproxInputs(
            alm_curve_rf_qe_rates_df = self._uc.read_latest(
                inputs.alm_curve_rf_rates.table_name,
                filter=f"RATE_SRC_CD = 'RiskFree_Rates' AND to_date(CURVE_INSTANCE_DT)='{last_quarter_end_date}' AND REGEXP_LIKE(CURVE_NAME_DESC, '^Treasury_[A-Z]+$')",
                watermark_col=inputs.alm_curve_rf_rates.watermark_col
            ),
            alm_curve_rf_fc_rates_df = self._uc.read_latest(
                inputs.alm_curve_rf_rates.table_name,
                filter=f"RATE_SRC_CD = 'RiskFree_Rates' AND to_date(CURVE_INSTANCE_DT)='{forecast_date}' AND REGEXP_LIKE(CURVE_NAME_DESC, '^Treasury_[A-Z]+$')",
                watermark_col=inputs.alm_curve_rf_rates.watermark_col
            ),
            rf_ec_final_shocks_df = self._uc.read_latest(
                inputs.rf_ec_final_shocks.table_name,
                filter=f"to_date(EFFECTIVE_DATE)='{last_quarter_end_date}' AND trim(SCENARIO)='A'",
                watermark_col=inputs.rf_ec_final_shocks.watermark_col
            ),
            ec_lower_bound_df = self._uc.read_latest(
                inputs.ec_lower_bound.table_name,
                watermark_col=inputs.ec_lower_bound.watermark_col
            ),
            mapping_dim_tenors_df = self._uc.read_latest(inputs.mapping_dim_tenors.table_name, watermark_col=inputs.mapping_dim_tenors.watermark_col)
        )

        self.validate_inputs(input_dfs)
        return input_dfs
    
    def calculate_ratios(self, inputs: ShockApproxInputs) -> DataFrame:
        self._logger.info("Shock Approximation: Step 1 - Calculating ratios...")
        
        alm_curve_rf_qe_rates_base_df = (
            inputs.alm_curve_rf_qe_rates_df
            .select(
                F.col("CURVE_INSTANCE_DT").alias("CURVEINSTANCEDATE"),
                F.col("INSTRUMENT_CURRENCY_CD").alias("INSTRUMENTCURRENCY"),
                F.col("TENOR_NM").alias("TENORNAME"),
                F.col("RATE_MID_RT").alias("RATEMID")
            )
            .distinct()
        )

        alm_curve_rf_fc_rates_base_df = (
            inputs.alm_curve_rf_fc_rates_df
            .select(
                F.col("CURVE_INSTANCE_DT").alias("CURVEINSTANCEDATE"),
                F.col("INSTRUMENT_CURRENCY_CD").alias("INSTRUMENTCURRENCY"),
                F.col("TENOR_NM").alias("TENORNAME"),
                F.col("RATE_MID_RT").alias("RATEMID")
            )
            .distinct()
        )

        alm_rates_combined_base_df = (
            alm_curve_rf_qe_rates_base_df.alias("qe")
            .join(
                alm_curve_rf_fc_rates_base_df.alias("fc"),
                on=[
                    F.col("qe.INSTRUMENTCURRENCY") == F.col("fc.INSTRUMENTCURRENCY"),
                    F.col("qe.TENORNAME") == F.col("fc.TENORNAME")
                ],
                how="inner"
            )
            .join(
                inputs.mapping_dim_tenors_df.alias("tenors"),
                F.upper(F.col("qe.TENORNAME")) == F.upper(F.col("tenors.TENOR_CODE")),
                how="inner"
            )
            .select(
                F.col("qe.INSTRUMENTCURRENCY").alias("CURRENCY"),
                F.col("tenors.TENOR_MONTHS").alias("TENOR_MONTHS"),
                F.col("tenors.IS_URR").alias("IS_URR"),
                F.col("qe.CURVEINSTANCEDATE").alias("QE_DATE"),
                F.col("qe.RATEMID").alias("QE_RATE"),
                F.col("fc.CURVEINSTANCEDATE").alias("FC_DATE"),
                F.col("fc.RATEMID").alias("FC_RATE")
            )
            .withColumn("QE_DATE", F.col("QE_DATE").cast("date"))
            .withColumn("FC_DATE", F.col("FC_DATE").cast("date"))
        )

        ec_lower_bound_base_df = (
            inputs.ec_lower_bound_df.alias("l")
            .join(
                inputs.mapping_dim_tenors_df.alias("tenors"),
                F.col("l.TENOR") == F.col("tenors.TENOR_YEARS"),
                how="inner"
            )
            .select(
                F.col("l.CURRENCY").alias("CURRENCY"),
                F.col("tenors.TENOR_MONTHS").alias("TENOR_MONTHS"),
                F.col("l.LOWER_BOUND")
            )
        )

        alm_rates_with_lowerbound_df = (
            alm_rates_combined_base_df.alias("rates")
            .join(
                ec_lower_bound_base_df.alias("l"),
                on=[
                    F.col("rates.CURRENCY") == F.col("l.CURRENCY"),
                    F.col("rates.TENOR_MONTHS") == F.col("l.TENOR_MONTHS")
                ],
                how="inner"
            )
            .select(
                F.col("rates.*"),
                F.col("l.LOWER_BOUND")
            )
        )

        ratios_df = (
            alm_rates_with_lowerbound_df
            .withColumn(
                "RATIOS",
                F.when(
                    (F.col("QE_RATE") - F.col("LOWER_BOUND")) != 0,
                    F.sqrt(
                        F.abs(
                            (F.col("FC_RATE") - F.col("LOWER_BOUND")) /
                            (F.col("QE_RATE") - F.col("LOWER_BOUND"))
                        )
                    )
                ).otherwise(0)
            )
            .distinct()
        )

        ratios_df = self.cache_df(ratios_df, "ratios_df")

        self._logger.info("Shock Approximation: Step 1 - Calculating ratios - Complete.")
        return ratios_df
    
    def calculate_shocks(self, inputs: ShockApproxInputs, ratios_df: DataFrame) -> DataFrame:
        self._logger.info("Shock Approximation: Step 2 - Calculating shocks...")
        rf_ec_final_shocks_base_df = (
            inputs.rf_ec_final_shocks_df.alias("s")
            .join(
                inputs.mapping_dim_tenors_df.alias("t"),
                F.col("s.TENOR") == F.col("t.TENOR_YEARS"),
                how="inner"
            )
            .select(
                F.col("s.CURRENCY"),
                F.col("t.TENOR_MONTHS"),
                F.col("t.IS_URR"),
                F.col("s.SHOCKS").alias("QE_SHOCKS")
            )
            .withColumn("QE_SHOCKS_BPS", F.col("QE_SHOCKS") * 100 )
        )

        final_shocks_df = (
            ratios_df.alias("r")
            .join(
                rf_ec_final_shocks_base_df.alias("s"),
                on=[
                    F.upper(F.col("r.CURRENCY")) == F.upper(F.col("s.CURRENCY")),
                    F.col("r.TENOR_MONTHS") == F.col("s.TENOR_MONTHS")
                ],
                how="rightouter"
            )
            .select(
                F.upper(F.col("s.CURRENCY")).alias("CURRENCY"),
                F.col("s.TENOR_MONTHS"),
                F.col("s.IS_URR"),
                F.col("r.QE_DATE"),
                F.col("r.QE_RATE"),
                F.col("r.FC_DATE"),
                F.col("r.FC_RATE"),
                F.col("r.LOWER_BOUND"),
                F.col("r.RATIOS"),
                F.col("s.QE_SHOCKS_BPS")
            )
            .filter(
                (F.col("QE_DATE").isNotNull()) |
                (F.col("QE_DATE").isNull() & F.col("IS_URR") == True)
            )
            .withColumn(
                "FC_SHOCKS_BPS", 
                F.when(
                    F.col("IS_URR") == True,
                    F.col("QE_SHOCKS_BPS")
                ).otherwise(
                    F.col("QE_SHOCKS_BPS") * F.col("RATIOS")
                )
            )
            .distinct()
        )

        final_shocks_df = self.cache_df(final_shocks_df, "final_shocks_df")

        shock_row = (
            final_shocks_df
            .filter(
                F.col("QE_DATE").isNotNull() & F.col("FC_DATE").isNotNull()
            ).first()
        )

        final_shocks_df = (
            final_shocks_df
            .withColumn(
                "QE_DATE",
                F.coalesce(F.col("QE_DATE"), F.lit(shock_row["QE_DATE"]))
            )
            .withColumn(
                "FC_DATE",
                F.coalesce(F.col("FC_DATE"), F.lit(shock_row["FC_DATE"]))
            )
        )

        forecast_date_rate_out_df = (
            final_shocks_df
            .select("CURRENCY", "TENOR_MONTHS", "IS_URR", "FC_DATE", "FC_RATE")
            .distinct()
        )
        forecast_date_rate_out_df = forecast_date_rate_out_df.dropDuplicates(["CURRENCY", "TENOR_MONTHS", "IS_URR", "FC_DATE"])

        ratios_out_df = (
            final_shocks_df
            .select( "CURRENCY", "TENOR_MONTHS", "IS_URR", "QE_DATE", "QE_RATE", "FC_DATE", "FC_RATE", "LOWER_BOUND", "RATIOS", "QE_SHOCKS_BPS", "FC_SHOCKS_BPS")
            .distinct()
        )
        ratios_out_df = ratios_out_df.dropDuplicates(["CURRENCY", "TENOR_MONTHS", "IS_URR", "QE_DATE", "FC_DATE"])

        final_shocks_qe_df = (
            final_shocks_df
            .withColumn("SCENARIO", F.lit("QE"))
            .select("CURRENCY", "TENOR_MONTHS", "IS_URR", "SCENARIO", F.col("QE_DATE").alias("SHOCK_DATE"), F.col("QE_SHOCKS_BPS").alias("SHOCKS_BPS"))
        )

        final_shocks_fc_df = (
            final_shocks_df
            .withColumn("SCENARIO", F.lit("FC"))
            .select("CURRENCY", "TENOR_MONTHS", "IS_URR", "SCENARIO", F.col("FC_DATE").alias("SHOCK_DATE"), F.col("FC_SHOCKS_BPS").alias("SHOCKS_BPS"))
        )

        combined_qe_fc_df = final_shocks_qe_df.union(final_shocks_fc_df).distinct()
        combined_qe_fc_df = combined_qe_fc_df.dropDuplicates(["CURRENCY", "TENOR_MONTHS", "IS_URR", "SCENARIO", "SHOCK_DATE"])
        
        #self.write(forecast_date_rate_out_df, self._step_config.step_forecast_date_rates.table_name, self._step_config.step_forecast_date_rates.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        #self.write(ratios_out_df, self._step_config.step_ratios.table_name, self._step_config.step_ratios.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        #self.write(combined_qe_fc_df, self._step_config.output.table_name, self._step_config.output.ext_table_loc, mode=RDABaseStep.spark_write_mode)

        self._logger.info("Shock Approximation: Step 2 - Calculating shocks complete.")
        return combined_qe_fc_df
