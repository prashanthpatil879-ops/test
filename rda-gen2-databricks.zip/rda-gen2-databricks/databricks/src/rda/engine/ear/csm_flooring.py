from pyspark.sql import DataFrame
from pyspark.sql import functions as F, Window
from typing import NamedTuple
from rda.engine.base_step import RDABaseStep
import rda.utils.spark_utils as su


class CSMFlooringInputs(NamedTuple):
    rf_ear_shocks_df: DataFrame
    gam_sensitivities_df: DataFrame
    gam_sensitivities_without_scenario_df: DataFrame
    llp_to_target_currency_df: DataFrame
    heirarchy_mapping_latest_df: DataFrame


class CSMFlooring(RDABaseStep):

    def read(self) -> CSMFlooringInputs:
        inputs = self._step_config.inputs
        last_quarter_end_date = self._date_ctx.asDict().get('PREVIOUSQUARTERENDDATE', None)
        self._logger.info(f"Reading inputs for CSM Flooring, Quarter End Date: {last_quarter_end_date}")

        if last_quarter_end_date is None:
            raise ValueError(f"Invalid date context entry for PREVIOUSQUARTERENDDATE in: {self._date_ctx.asDict()}")

        input_dfs = CSMFlooringInputs(
            rf_ear_shocks_df = self._uc.read_latest(inputs.rf_ear_shocks.table_name,
                                                    filter=f"to_date(EFFECTIVE_DATE)='{last_quarter_end_date}'",
                                                    watermark_col=inputs.rf_ear_shocks.watermark_col),
            gam_sensitivities_df = self._uc.read_latest(inputs.gam_sensitivities.table_name,
                                                    filter=f"to_date(REPORTING_DATE)='{last_quarter_end_date}' \
                                                    and SCENARIO_NAME in ('RF +50bps', 'RF -50bps') \
                                                    and SOURCE_FILE like '%part 1%'",
                                                    watermark_col=inputs.gam_sensitivities.watermark_col),
            gam_sensitivities_without_scenario_df = self._uc.read_latest(inputs.gam_sensitivities_without_scenario.table_name,
                                                    filter=f"to_date(REPORTING_DATE)='{last_quarter_end_date}' \
                                                    and SOURCE_FILE like '%part 1%'",
                                                    watermark_col=inputs.gam_sensitivities_without_scenario.watermark_col),
            llp_to_target_currency_df = self._uc.read_latest(inputs.llp_to_target_currency.table_name, watermark_col=inputs.llp_to_target_currency.watermark_col),
            heirarchy_mapping_latest_df = self._uc.read_latest(inputs.heirarchy_mapping_latest.table_name, watermark_col=inputs.heirarchy_mapping_latest.watermark_col)
        )

        self.validate_inputs(input_dfs)
        return input_dfs

    def calculate_avg_shocks(self, inputs: CSMFlooringInputs) -> DataFrame:
        self._logger.info("CSM Flooring - Calculating Average Shocks...")
        window = Window.partitionBy("CURRENCY", "SCENARIO").orderBy(F.col("TENOR").desc())
        ranked_df = inputs.rf_ear_shocks_df.withColumn("rank", F.row_number().over(window))

        picked_tenors_df = (
            ranked_df
            .filter(
                (F.col("rank") >= 2) &
                (F.col("rank") < 2 + int(self._step_config.config.tenors_from_last) )
            )
            .drop("rank")
        )

        avg_shocks_df = (
            picked_tenors_df
            .groupBy("CURRENCY", "SCENARIO")
            .agg({"SHOCKS": "avg"})
            .withColumnRenamed("avg(SHOCKS)", "AVG_SHOCKS")
            .withColumn("CURRENCY", F.upper(F.col("CURRENCY")))
        )

        avg_shocks_df = self.cache_df(avg_shocks_df, "avg_shocks_df")

        self.write(avg_shocks_df, self._step_config.step_avg_shocks.table_name, self._step_config.step_avg_shocks.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CSM Flooring - Calculating Average Shocks Completed")
        return avg_shocks_df

    def calcualte_earnings_sensitivity(self, inputs: CSMFlooringInputs) -> DataFrame:
        self._logger.info("CSM Flooring - Calculating earnings Sensitivity Started...")
        gam_sensitivities_df = inputs.gam_sensitivities_df
        gam_sensitivities_without_scenario_df = inputs.gam_sensitivities_without_scenario_df

        gam_sensitivities_without_scenario_base_df = (
            gam_sensitivities_without_scenario_df
            .filter(
                ( (F.col("BALANCE_SHEET_COMPONENT_NAME") == "Gross of Reinsurance (VFA)") & (F.col("IFRS_EARNINGS_COMPONENT_NAME") == "CSM" ) ) |
                ( (F.col("BALANCE_SHEET_COMPONENT_NAME") == "Gross of Reinsurance (VFA)") & (F.col("IFRS_EARNINGS_COMPONENT_NAME") == "LC" ) )
            )
            .withColumn("IFRS_EARNINGS_COMPONENT_NAME_TEMP", F.concat(F.col("BALANCE_SHEET_COMPONENT_NAME"), F.lit("_"), F.col("IFRS_EARNINGS_COMPONENT_NAME")) )
            .select("LOWEST_LEVEL_PORTFOLIO_NAME", "IFRS_EARNINGS_COMPONENT_NAME_TEMP", "AMOUNT")
        )

        # Step 1 - Calculate CSM ROOM
        self._logger.info("CSM Flooring - Calculating CSM Room Started...")
        csm_room_df = (
            su.pivot_measures_by_scenario(gam_sensitivities_without_scenario_base_df, "IFRS_EARNINGS_COMPONENT_NAME_TEMP", ["AMOUNT"])
            .withColumnRenamed("AMOUNT_Gross_of_Reinsurance_(VFA)_CSM", "CSM")
            .withColumnRenamed("AMOUNT_Gross_of_Reinsurance_(VFA)_LC", "LC")
            .withColumn("CSM_ROOM", F.col("CSM") - F.col("LC"))
            .fillna(0)
        )

        gam_sensitivities_base_df = (
            gam_sensitivities_df
            .filter(
                ( (F.col("BALANCE_SHEET_COMPONENT_NAME") == "Liabilities Summary") & (F.col("IFRS_EARNINGS_COMPONENT_NAME") == "Impacts absorbed by CSM" ) ) |
                ( (F.col("BALANCE_SHEET_COMPONENT_NAME") == "Reinsurance (GMM/PAA)") & (F.col("IFRS_EARNINGS_COMPONENT_NAME") == "Total" ) ) |
                ( (F.col("BALANCE_SHEET_COMPONENT_NAME") == "Risk Mitigation") & (F.col("IFRS_EARNINGS_COMPONENT_NAME") == "P&L") )
            )
            .withColumn("IFRS_EARNINGS_COMPONENT_NAME_TEMP", F.concat(F.col("BALANCE_SHEET_COMPONENT_NAME"), F.lit("_"), F.col("IFRS_EARNINGS_COMPONENT_NAME")) )
            .select("COUNTRY_NAME", "LOWEST_LEVEL_PORTFOLIO_NAME", "SCENARIO_NAME", "IFRS_EARNINGS_COMPONENT_NAME_TEMP", "AMOUNT")
        )

        csm_impact_and_reinsurance_pnl_df = (
            gam_sensitivities_base_df
            .filter(
                (F.col("IFRS_EARNINGS_COMPONENT_NAME_TEMP") == "Liabilities Summary_Impacts absorbed by CSM") |
                (F.col("IFRS_EARNINGS_COMPONENT_NAME_TEMP") == "Reinsurance (GMM/PAA)_Total")
            )
        )

        # Step 2 - Calculate CSM impact and reinsurance pnl
        self._logger.info("CSM Flooring - Calculating CSM impact and reinsurance pnl Started...")
        csm_impact_and_reinsurance_pnl_df = (
            su.pivot_measures_by_scenario(csm_impact_and_reinsurance_pnl_df, "IFRS_EARNINGS_COMPONENT_NAME_TEMP", ["AMOUNT"])
            .withColumnRenamed("AMOUNT_Liabilities_Summary_Impacts_absorbed_by_CSM", "CSM_IMPACTS_ABSORBED")
            .withColumnRenamed("AMOUNT_Reinsurance_(GMM/PAA)_Total", "REINSURANCE_IMPACT_PNL")
            .fillna(0)
        )

        csm_reinsurance_inclusion_flag_base_df = (
            gam_sensitivities_base_df
            .filter(
                (F.col("IFRS_EARNINGS_COMPONENT_NAME_TEMP") == "Risk Mitigation_P&L")
            )
        )

        # Step 3 - Calculate reinsurance inclusion flag
        self._logger.info("CSM Flooring - Calculating reinsurance inclusion flag Started...")
        csm_reinsurance_inclusion_flag_df = (
            csm_reinsurance_inclusion_flag_base_df
            .groupBy("LOWEST_LEVEL_PORTFOLIO_NAME")
            .agg(
                ( F.max(
                        F.when(
                            (F.col("AMOUNT").isNotNull()) & (F.col("AMOUNT") != 0),
                            1
                        ).otherwise(0)
                    ) == 0
                ).alias("REINSURANCE_INCLUSION_FLAG")
            )
        )
        csm_reinsurance_inclusion_flag_df = csm_reinsurance_inclusion_flag_df.withColumn("REINSURANCE_INCLUSION_FLAG", F.when(F.col("REINSURANCE_INCLUSION_FLAG") == True, 1).otherwise(0) )

        csm_impact_and_reinsurance_pnl_df = su.normalize_llp(csm_impact_and_reinsurance_pnl_df)
        csm_room_df = su.normalize_llp(csm_room_df)
        reinsurance_inclusion_flag_df = su.normalize_llp(csm_reinsurance_inclusion_flag_df)
        llp_cur_df = su.normalize_llp(inputs.llp_to_target_currency_df)

        earning_sensitivity_df = (
            csm_room_df.alias("csm_room_df")
            .join(csm_impact_and_reinsurance_pnl_df.alias("csm_impact_df"), on="LLP_TEMP", how="inner")
            .join(reinsurance_inclusion_flag_df.alias("reinsur_flag_df"), on="LLP_TEMP", how="inner")
            .join(llp_cur_df.alias("llp_cur_df"), on="LLP_TEMP", how="inner")
            .select(
                F.col("csm_impact_df.COUNTRY_NAME").alias("COUNTRY_NAME"),
                F.col("llp_cur_df.CURRENCY_ALPHA_CODE").alias("CURRENCY_CODE"),
                F.col("csm_impact_df.LOWEST_LEVEL_PORTFOLIO_NAME").alias("LOWEST_LEVEL_PORTFOLIO_NAME"),
                F.col("csm_impact_df.SCENARIO_NAME").alias("SCENARIO_NAME"),
                F.col("csm_room_df.CSM").alias("CSM"),
                F.col("csm_room_df.LC").alias("LC"),
                F.col("csm_room_df.CSM_ROOM").alias("CSM_ROOM"),
                F.col("csm_impact_df.CSM_IMPACTS_ABSORBED").alias("CSM_IMPACTS_ABSORBED"),
                F.col("csm_impact_df.REINSURANCE_IMPACT_PNL").alias("REINSURANCE_IMPACT_PNL"),
                F.col("reinsur_flag_df.REINSURANCE_INCLUSION_FLAG").alias("REINSURANCE_INCLUSION_FLAG")
            )
        )

        earning_sensitivity_df = self.cache_df(earning_sensitivity_df, "earning_sensitivity_df")

        self.write(earning_sensitivity_df, self._step_config.step_earnings_sensitivity.table_name, self._step_config.step_earnings_sensitivity.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CSM Flooring - Calculating earnings Sensitivity Completed successfully")
        return earning_sensitivity_df

    def calcualte_pnl_with_shocks(self, inputs: CSMFlooringInputs, avg_shocks_df: DataFrame, earning_sensitivity_df: DataFrame) -> DataFrame:
        self._logger.info("CSM Flooring - Calculating PNL with shocks Started...")
        earning_sensitivity_df = su.pivot_measures_by_scenario(earning_sensitivity_df, "SCENARIO_NAME", ["CSM_IMPACTS_ABSORBED", "REINSURANCE_IMPACT_PNL"])

        heirarchy_mapping_df = inputs.heirarchy_mapping_latest_df.select("LOWEST_LEVEL_PORTFOLIO_NAME", "REGION_NAME", "TAX_RATE")

        earning_sensitivity_df = su.normalize_llp(earning_sensitivity_df)
        heirarchy_mapping_df = su.normalize_llp(heirarchy_mapping_df)

        pnl_base_df = (
            earning_sensitivity_df.alias("a")
            .join(heirarchy_mapping_df.alias("h"), on="LLP_TEMP", how="inner")
            .join(
                avg_shocks_df.alias("as"),
                F.upper(F.col("a.CURRENCY_CODE")) == F.upper(F.col("as.CURRENCY")),
                how="inner"
            )
            .select(
                F.col("a.*"),
                F.col("h.TAX_RATE").alias("TAX_RATE"),
                F.col("as.AVG_SHOCKS"),
                F.col("as.SCENARIO").alias("SCENARIO_ID")
            )
        )

        pnl_base_df = pnl_base_df.withColumn("AVG_SHOCKS", F.col("AVG_SHOCKS") * 100)

        pnl_gain_loss_df = pnl_base_df.withColumn(
            "GAIN_LOSS",
            F.when(
                F.col("AVG_SHOCKS") > 0, F.col("CSM_IMPACTS_ABSORBED_RF_+50bps") * F.col("AVG_SHOCKS") / 50
                )
            .otherwise(F.col("CSM_IMPACTS_ABSORBED_RF_-50bps") * F.col("AVG_SHOCKS") / (-50))
            )

        pnl_gain_loss_pretax_df = pnl_gain_loss_df.withColumn(
            "PNL_CSM_FLOORING_PRETAX",
            F.when(
                (F.col("GAIN_LOSS") <= 0) & (F.col("CSM_ROOM") <= 0),
                F.col("GAIN_LOSS")
            ).when(
                (F.col("GAIN_LOSS") >= 0) & (F.col("CSM_ROOM") <= 0),
                F.least(F.col("GAIN_LOSS"), -F.col("CSM_ROOM"))
            ).when(
                (F.col("GAIN_LOSS") <= 0) & (F.col("CSM_ROOM") >= 0),
                F.least(F.col("GAIN_LOSS") + F.col("CSM_ROOM"), F.lit(0))
            ).otherwise(F.lit(0))
        )

        pnl_gain_loss_posttax_df = pnl_gain_loss_pretax_df.withColumn(
            "PNL_CSM_FLOORING_POSTTAX",
            F.coalesce(F.col("PNL_CSM_FLOORING_PRETAX") * (1 - F.col("TAX_RATE")), F.lit(0))
        )

        pnl_gain_loss_posttax_df_final = (
            pnl_gain_loss_posttax_df.select(
            "COUNTRY_NAME",
            "CURRENCY_CODE",
            "LOWEST_LEVEL_PORTFOLIO_NAME",
            "SCENARIO_ID",
            "AVG_SHOCKS",
            "CSM_ROOM",
            F.col("CSM_IMPACTS_ABSORBED_RF_+50bps").alias("CSM_IMPACT_RF_+50bps"),
            F.col("CSM_IMPACTS_ABSORBED_RF_-50bps").alias("CSM_IMPACT_RF_-50bps"),
            "GAIN_LOSS",
            "PNL_CSM_FLOORING_PRETAX",
            "PNL_CSM_FLOORING_POSTTAX"
        )
        )

        pnl_gain_loss_posttax_df_final = self.cache_df(pnl_gain_loss_posttax_df_final, "pnl_gain_loss_posttax_df_final")

        self.write(pnl_gain_loss_posttax_df, self._step_config.staging.table_name, self._step_config.staging.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self.write(pnl_gain_loss_posttax_df_final, self._step_config.output_csm_pnl.table_name, self._step_config.output_csm_pnl.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CSM Flooring - Calculating PNL with shocks completed successfully")
        return (pnl_gain_loss_posttax_df, pnl_gain_loss_posttax_df_final)

    def calculate_reinsurence_pnl(self, pnl_gain_loss_posttax_df):
        self._logger.info("CSM Flooring - Calculating reinsurence pnl Started...")
        reinsurence_pnl_df = pnl_gain_loss_posttax_df.withColumn(
            "REINSURANCE_PNL",
            F.when(F.col("AVG_SHOCKS")>0,
                   F.col("REINSURANCE_IMPACT_PNL_RF_+50bps")/50)
            .otherwise(F.col("REINSURANCE_IMPACT_PNL_RF_-50bps")/(-50))
        )
        reinsurence_pnl_df = reinsurence_pnl_df.withColumn(
            "REINSURANCE_PNL",
            F.col("REINSURANCE_PNL") * F.col("AVG_SHOCKS") * F.col("REINSURANCE_INCLUSION_FLAG")
        )

        reinsurence_pnl_df = (
            reinsurence_pnl_df.select(
            "COUNTRY_NAME",
            "CURRENCY_CODE",
            "LOWEST_LEVEL_PORTFOLIO_NAME",
            "SCENARIO_ID",
            "AVG_SHOCKS",
            "REINSURANCE_IMPACT_PNL_RF_+50bps",
            "REINSURANCE_IMPACT_PNL_RF_-50bps",
            "REINSURANCE_PNL"
            )
        )

        reinsurence_pnl_df = self.cache_df(reinsurence_pnl_df, "reinsurence_pnl_df")

        self.write(reinsurence_pnl_df, self._step_config.output_reinsurance_pnl.table_name, self._step_config.output_reinsurance_pnl.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        self._logger.info("CSM Flooring - Calculating reinsurence pnl Completed successfully")
        return reinsurence_pnl_df
