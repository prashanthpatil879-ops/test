from pyspark.sql import DataFrame
from pyspark.sql import functions as F, Window
from pyspark.sql.functions import col, upper, when, sum as spark_sum, length
from typing import NamedTuple
from rda.io.unity_catalog import UnityCatalog
from rda.utils.logger import get_logger
from pyspark.sql.functions import col, upper, trim, regexp_replace
import re
from datetime import datetime, date
from rda.engine.base_step import RDABaseStep

class ExclusionMappingInputs(NamedTuple):
    genfund_df: DataFrame
    tamsegment_exclusion_mapping_df: DataFrame

class ExclusionMapping(RDABaseStep):
    
    def read(self) -> ExclusionMappingInputs:
        inputs = self._step_config.inputs
        input_dfs = ExclusionMappingInputs(
            genfund_df = self._uc.read_latest(inputs.genfund.table_name, watermark_col=inputs.genfund.watermark_col),
            tamsegment_exclusion_mapping_df = self._uc.read_latest(inputs.tamsegment.table_name, watermark_col=inputs.tamsegment.watermark_col),
            )

        self.validate_inputs(input_dfs)
        return input_dfs
    
    def normalize(self, col):
        return trim(
            upper(
                regexp_replace(   
                    regexp_replace(
                        regexp_replace(
                            regexp_replace(
                                regexp_replace(
                                    upper(col),
                                    r'\s*-\s*', '-'  
                                ),
                                'POLICYHOLDER', 'PH'
                            ),
                            'GUARANTEED FUND', 'GTD FUND'
                        ),
                        'RESERVE', 'RES'
                    ),
                    'REIN', 'REINS'
                )
            )
        )
    
    def calculate_tamsegment_exclusion_mapping(self, inputs: ExclusionMappingInputs) -> DataFrame:
        genfund_df = inputs.genfund_df.select("IFRS17_PAR", "TAM_SEGMENT").filter(length(trim(col("TAM_SEGMENT"))) > 0)

        pivot_df = genfund_df.groupBy("TAM_SEGMENT").agg(
            spark_sum(when(col("IFRS17_PAR") == "SHAREHOLDER", 1).otherwise(0)).alias("SHAREHOLDER_SEGMENT_COUNT"),
            spark_sum(when(col("IFRS17_PAR") == "POLICY HOLDER", 1).otherwise(0)).alias("POLICYHOLDER_SEGMENT_COUNT")
        )

        final_df = self.apply_tamsegment_rules(pivot_df,inputs.tamsegment_exclusion_mapping_df)
        df = self.write(final_df, self._step_config.output.table_name, self._step_config.output.ext_table_loc, mode=RDABaseStep.spark_write_mode)
        return df

    def apply_tamsegment_rules(self, base_df: DataFrame, tamsegment_exclusion_mapping_df: DataFrame) -> DataFrame:

        curation_df = (
            base_df
            .withColumn(
                "SHAREHOLDER_STATUS",
                when(col("POLICYHOLDER_SEGMENT_COUNT") > col("SHAREHOLDER_SEGMENT_COUNT"), "POLICYHOLDER")
                .otherwise("SHAREHOLDER")
            )
        )

        final_df = (
            curation_df.alias("c")
            .join(tamsegment_exclusion_mapping_df.alias("t"), trim(upper(regexp_replace(col("c.TAM_SEGMENT"), r'\s*-\s*', '-'))) == self.normalize(col("t.TAM_SEGMENT")), "left")
            .withColumn(
                "EXCLUDE",
                when(col("EXCLUDE").isNotNull(), col("EXCLUDE"))
                .otherwise(
                    when(col("SHAREHOLDER_STATUS") == "SHAREHOLDER", "No")
                    .otherwise("Yes")
                )
            ).drop(col("t.TAM_SEGMENT"))
        )


        return final_df.select(
            "TAM_SEGMENT",
            "SHAREHOLDER_SEGMENT_COUNT",
            "POLICYHOLDER_SEGMENT_COUNT",
            "SHAREHOLDER_STATUS",
            "EXCLUDE"
        )