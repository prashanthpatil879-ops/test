/****** Object:  Table [dbo].[Dim_Country]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Country](
	[Country_Key] [int] IDENTITY(0,1) NOT NULL,
	[Country_Name] [nvarchar](100) NOT NULL,
	[Country_Code] [nvarchar](8) NOT NULL,
	[Region_Key] [int] NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Tax_Rate] [decimal](18, 9) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Country_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Par_Status]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Par_Status](
	[Par_Status_Key] [int] IDENTITY(0,1) NOT NULL,
	[Par_Status_Name] [nvarchar](100) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Par_Status_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Product_Type]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Product_Type](
	[Product_Type_Key] [int] IDENTITY(0,1) NOT NULL,
	[Product_Type_Name] [nvarchar](255) NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Product_Type_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Region]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Region](
	[Region_Key] [int] IDENTITY(0,1) NOT NULL,
	[Region_Name] [nvarchar](100) NOT NULL,
	[Region_Code] [nvarchar](8) NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
	[Company_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Region_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Tam_Segment]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Tam_Segment](
	[Tam_Segment_Key] [int] IDENTITY(0,1) NOT NULL,
	[Tam_Segment_Name] [nvarchar](100) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Tam_Segment_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Run]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Run](
	[Run_Key] [int] IDENTITY(0,1) NOT NULL,
	[Process_Name] [nvarchar](200) NOT NULL,
	[Date_Key] [int] NOT NULL,
	[Reporting_Date_Key] [int] NOT NULL,
	[Process_Start_Date] [datetime] NOT NULL,
	[Process_End_Date] [datetime] NOT NULL,
	[Process_Run_By] [nvarchar](100) NULL,
	[Is_Latest] [bit] NULL,
	[Is_Approved] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Sys_Last_Mod_Date] [datetime] NULL,
	[Sys_Last_Mod_By] [nvarchar](100) NULL,
	[InputFileName] [nvarchar](510) NOT NULL,
	[Is_Approved_Date] [datetime] NULL,
	[Is_Approved_By] [nvarchar](100) NULL,
 CONSTRAINT [PK__Fact_Run__B5258A4F9B1AFE72] PRIMARY KEY CLUSTERED 
(
	[Run_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vLatestRun]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vLatestRun]
AS


-- GET LATEST VERSION OF THE RUN for ALM Intraquarter Run -- 
SELECT        Process_Name, Date_Key, MAX(Run_Key) AS LatestRun, Reporting_Date_Key, Process_Name AS Process_Detail
FROM            dbo.Fact_Run
WHERE Process_Name ='ALM Sensitivities Forecast'
GROUP BY Process_Name, Reporting_Date_Key , Date_Key


UNION ALL 
-- GET LATEST VERSION OF THE RUN for GAM Part 1 and 2 --
SELECT        Process_Name, Max(Date_Key) as Date_Key, MAX(Run_Key) AS LatestRun, Reporting_Date_Key, 'GAM Sensitivities to RDA' AS Process_Detail
FROM            dbo.Fact_Run
WHERE Process_Name Like '%Consolidated Sensitivities Results%'
GROUP BY Process_Name, Reporting_Date_Key

UNION ALL 
-- GET LATEST Heirarchy (always one version of Herirarchy) 
SELECT        Process_Name, Max(Reporting_Date_Key) as Date_Key, MAX(Run_Key) AS LatestRun, Max(Reporting_Date_Key) as Reporting_Date_Key , 'GAM Segment Mapping Latest' AS Process_Detail
FROM            dbo.Fact_Run
WHERE Process_name = 'Consolidated Sensitivities Segment Mapping'
GROUP BY Process_Name

UNION ALL 
-- GET Quarterly  Heirarchy Mapping (> 1 version of Herirarchy) 
SELECT        Process_Name, Max(Date_Key) as Date_Key, MAX(Run_Key) AS LatestRun, Reporting_Date_Key as Reporting_Date_Key , 'GAM Segment Mapping Quarterly' AS Process_Detail
FROM            dbo.Fact_Run
WHERE Process_name = 'Consolidated Sensitivities Segment Mapping'
GROUP BY Process_Name, Reporting_Date_Key

GO
/****** Object:  Table [dbo].[Fact_Heirarchy_Mapping]    Script Date: 3/4/2026 6:48:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Heirarchy_Mapping](
	[Heirarchy_Mapping_Key] [int] IDENTITY(0,1) NOT NULL,
	[Run_Key] [int] NOT NULL,
	[Country_Key] [int] NOT NULL,
	[Tam_Segment_Key] [int] NOT NULL,
	[Asset_Segment_Key] [int] NOT NULL,
	[Liability_Segment_Key] [int] NOT NULL,
	[Lowest_Level_Portfolio_Key] [int] NOT NULL,
	[Product_Type_Key] [int] NULL,
	[Par_Status_Key] [int] NULL,
	[Tax_Rate] [decimal](10, 5) NULL,
	[Minority_Interest] [decimal](10, 5) NULL,
	[GMT] [decimal](10, 5) NULL,
	[MLRL_Tax] [decimal](10, 5) NULL,
 CONSTRAINT [PK__Fact_Hei__3760EB342D1124EF] PRIMARY KEY CLUSTERED 
(
	[Heirarchy_Mapping_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Lowest_Level_Portfolio]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Lowest_Level_Portfolio](
	[Lowest_Level_Portfolio_Key] [int] IDENTITY(0,1) NOT NULL,
	[Lowest_Level_Portfolio_Name] [nvarchar](255) NOT NULL,
	[Is_Active] [bit] NOT NULL,
	[Sys_Create_Date] [datetime] NOT NULL,
	[Sys_Create_By] [nvarchar](100) NOT NULL,
	[Target_Currency_Key] [int] NULL,
	[Surplus_Indicator] [bit] NOT NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
 CONSTRAINT [PK__Dim_Lowe__BA32370C1D3021B5] PRIMARY KEY CLUSTERED 
(
	[Lowest_Level_Portfolio_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vHeirarchyMappingQuarterly]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vHeirarchyMappingQuarterly]
AS
SELECT        dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Name, dbo.Dim_Tam_Segment.Tam_Segment_Name, dbo.Dim_Region.Region_Name, dbo.Dim_Country.Country_Name, dbo.vLatestRun.Reporting_Date_Key, 
                         dbo.Fact_Heirarchy_Mapping.Tax_Rate, dbo.Fact_Heirarchy_Mapping.Minority_Interest, dbo.Fact_Heirarchy_Mapping.GMT, dbo.Fact_Heirarchy_Mapping.MLRL_Tax, dbo.Dim_Region.Region_Code, 
                         dbo.Dim_Country.Country_Code, dbo.Dim_Par_Status.Par_Status_Name, dbo.Dim_Product_Type.Product_Type_Name, dbo.Fact_Heirarchy_Mapping.Lowest_Level_Portfolio_Key
FROM            dbo.Fact_Heirarchy_Mapping INNER JOIN
                         dbo.Dim_Tam_Segment ON dbo.Fact_Heirarchy_Mapping.Tam_Segment_Key = dbo.Dim_Tam_Segment.Tam_Segment_Key INNER JOIN
                         dbo.Dim_Lowest_Level_Portfolio ON dbo.Fact_Heirarchy_Mapping.Lowest_Level_Portfolio_Key = dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Key INNER JOIN
                         dbo.vLatestRun ON dbo.Fact_Heirarchy_Mapping.Run_Key = dbo.vLatestRun.LatestRun AND dbo.vLatestRun.Process_Detail = 'GAM Segment Mapping Quarterly' INNER JOIN
                         dbo.Dim_Country ON dbo.Fact_Heirarchy_Mapping.Country_Key = dbo.Dim_Country.Country_Key INNER JOIN
                         dbo.Dim_Region ON dbo.Dim_Country.Region_Key = dbo.Dim_Region.Region_Key LEFT OUTER JOIN
                         dbo.Dim_Product_Type ON dbo.Fact_Heirarchy_Mapping.Product_Type_Key = dbo.Dim_Product_Type.Product_Type_Key LEFT OUTER JOIN
                         dbo.Dim_Par_Status ON dbo.Fact_Heirarchy_Mapping.Par_Status_Key = dbo.Dim_Par_Status.Par_Status_Key
GO
/****** Object:  Table [dbo].[Fact_DailyForecasts]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_DailyForecasts](
	[DailyForecasts_Key] [int] IDENTITY(0,1) NOT NULL,
	[Run_Key] [int] NOT NULL,
	[Country_Key] [int] NOT NULL,
	[Tax_Indicator_Key] [int] NOT NULL,
	[Lowest_Level_Portfolio_Key] [int] NOT NULL,
	[Balance_Sheet_Component_Key] [int] NOT NULL,
	[IFRS_Earnings_Component_Key] [int] NOT NULL,
	[Scenario_Key] [int] NOT NULL,
	[Currency_Key] [int] NOT NULL,
	[Product_Type_Key] [int] NULL,
	[Amount] [decimal](28, 15) NOT NULL,
 CONSTRAINT [PK__Fact_Dai__DEFA8B1561F28D01] PRIMARY KEY CLUSTERED 
(
	[DailyForecasts_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Company]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Company](
	[Company_Key] [int] IDENTITY(0,1) NOT NULL,
	[Company_Name] [nvarchar](100) NULL,
	[Company_Code] [nvarchar](100) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Company_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Balance_Sheet_Component]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Balance_Sheet_Component](
	[Balance_Sheet_Component_Key] [int] IDENTITY(0,1) NOT NULL,
	[Balance_Sheet_Component_Name] [nvarchar](100) NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Balance_Sheet_Component_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Date]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Date](
	[Date_Key] [int] NOT NULL,
	[Date] [date] NOT NULL,
	[Short_Date_YMD] [varchar](10) NOT NULL,
	[Short_Date_MDY] [varchar](10) NOT NULL,
	[Short_Date_DMY] [varchar](10) NOT NULL,
	[Day_Of_Week_Num] [int] NOT NULL,
	[Day_Of_Week_Name] [varchar](10) NOT NULL,
	[Day_Of_Month_Num] [int] NOT NULL,
	[Day_Of_Year_Num] [int] NOT NULL,
	[Is_Weekday_Ind] [bit] NOT NULL,
	[Week_Of_Year_Num] [int] NOT NULL,
	[Month_Name] [varchar](15) NOT NULL,
	[Month_Num] [int] NOT NULL,
	[Is_Last_Day_Of_Month_Ind] [bit] NOT NULL,
	[Is_Last_Day_Of_Quarter_Ind] [bit] NOT NULL,
	[Quarter_Num] [int] NOT NULL,
	[Year] [int] NOT NULL,
	[Sys_Creation_Date] [datetime] NULL,
	[Is_Active] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Date_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_IFRS_Earnings_Component]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_IFRS_Earnings_Component](
	[IFRS_Earnings_Component_Key] [int] IDENTITY(0,1) NOT NULL,
	[IFRS_Earnings_Component_Name] [nvarchar](100) NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[IFRS_Earnings_Component_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Scenario]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Scenario](
	[Scenario_Key] [int] IDENTITY(0,1) NOT NULL,
	[Scenario_Name] [nvarchar](255) NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Shocks] [int] NULL,
	[Units] [nvarchar](16) NULL,
	[Scenario_Long_Name] [nvarchar](255) NULL,
	[Tenor] [int] NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Scenario_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Tax_Indicator]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Tax_Indicator](
	[Tax_Indicator_Key] [int] IDENTITY(0,1) NOT NULL,
	[Tax_Indicator_Name] [nvarchar](100) NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Tax_Indicator_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vIRRFEaRDailyForecast]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vIRRFEaRDailyForecast]
AS
SELECT   dbo.Fact_DailyForecasts.Amount, dbo.Fact_Run.Reporting_Date_Key, dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Name, dbo.Dim_Country.Country_Name, 
                         dbo.Dim_Country.Country_Code, dbo.Dim_Region.Region_Name, dbo.Dim_Region.Region_Code, dbo.Dim_Company.Company_Name, dbo.Dim_Scenario.Scenario_Name, 
                         dbo.Dim_Tax_Indicator.Tax_Indicator_Name, dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Name, 
                         dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Name, dbo.Fact_Run.Process_Name, dbo.Fact_Run.Date_Key, Dim_Date.Date, Dim_Date.Quarter_Num, Dim_Date.Year, 
                         'Q' + CAST(Dim_Date.Quarter_Num AS CHAR(1)) + ' ' + CAST(Dim_Date.Year AS CHAR(4)) AS Date_QuarterYear, Dim_Date.Is_Last_Day_Of_Quarter_Ind, 
                         Dim_Date.Is_Last_Day_Of_Month_Ind, Dim_Date.Month_Name, Dim_Date.Month_Num, Dim_Date_1.Date AS Reporting_Date, Dim_Date_1.Quarter_Num AS Reporting_Quarter_Num, 
                         Dim_Date_1.Year AS Reporting_Year, Dim_Date_1.Is_Last_Day_Of_Month_Ind AS Reporting_Is_Last_Day_Of_Month, 
                         Dim_Date_1.Is_Last_Day_Of_Quarter_Ind AS Reporting_Last_Day_Of_Quarter_Ind, Dim_Date_1.Month_Name AS Reporting_Month_Name, 
                         Dim_Date_1.Month_Num AS Reporting_Month_Num, 'Q' + CAST(Dim_Date_1.Quarter_Num AS CHAR(1)) + ' ' + CAST(Dim_Date_1.Year AS CHAR(4)) AS Reporting_QuarterYear, 
                         dbo.Fact_Run.Run_Key
FROM         dbo.Fact_DailyForecasts INNER JOIN
                         dbo.Fact_Run ON dbo.Fact_DailyForecasts.Run_Key = dbo.Fact_Run.Run_Key INNER JOIN
                         dbo.Dim_Lowest_Level_Portfolio ON dbo.Fact_DailyForecasts.Lowest_Level_Portfolio_Key = dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Key INNER JOIN
                         dbo.Dim_Country ON dbo.Dim_Country.Country_Key = dbo.Fact_DailyForecasts.Country_Key INNER JOIN
                         dbo.Dim_Region ON dbo.Dim_Country.Region_Key = dbo.Dim_Region.Region_Key INNER JOIN
                         dbo.Dim_Company ON dbo.Dim_Region.Company_Key = dbo.Dim_Company.Company_Key INNER JOIN
                         dbo.Dim_Scenario ON dbo.Fact_DailyForecasts.Scenario_Key = dbo.Dim_Scenario.Scenario_Key INNER JOIN
                         dbo.Dim_Tax_Indicator ON dbo.Fact_DailyForecasts.Tax_Indicator_Key = dbo.Dim_Tax_Indicator.Tax_Indicator_Key INNER JOIN
                         dbo.Dim_Balance_Sheet_Component ON dbo.Fact_DailyForecasts.Balance_Sheet_Component_Key = dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Key INNER JOIN
                         dbo.Dim_IFRS_Earnings_Component ON dbo.Fact_DailyForecasts.IFRS_Earnings_Component_Key = dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Key INNER JOIN
                         dbo.Dim_Date AS Dim_Date ON dbo.Fact_Run.Date_Key = Dim_Date.Date_Key INNER JOIN
                         dbo.Dim_Date AS Dim_Date_1 ON dbo.Fact_Run.Reporting_Date_Key = Dim_Date_1.Date_Key
GO
/****** Object:  View [dbo].[vHeirarchyMappingLatest]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vHeirarchyMappingLatest]
AS
SELECT        dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Name, dbo.Dim_Tam_Segment.Tam_Segment_Name, dbo.Dim_Region.Region_Name, dbo.Dim_Country.Country_Name, dbo.vLatestRun.Reporting_Date_Key, 
                         dbo.Fact_Heirarchy_Mapping.Tax_Rate, dbo.Fact_Heirarchy_Mapping.Minority_Interest, dbo.Fact_Heirarchy_Mapping.GMT, dbo.Fact_Heirarchy_Mapping.MLRL_Tax, dbo.Dim_Region.Region_Code, 
                         dbo.Dim_Country.Country_Code, dbo.Dim_Par_Status.Par_Status_Name, dbo.Dim_Product_Type.Product_Type_Name, dbo.Fact_Heirarchy_Mapping.Lowest_Level_Portfolio_Key
FROM            dbo.Fact_Heirarchy_Mapping INNER JOIN
                         dbo.Dim_Tam_Segment ON dbo.Fact_Heirarchy_Mapping.Tam_Segment_Key = dbo.Dim_Tam_Segment.Tam_Segment_Key INNER JOIN
                         dbo.Dim_Lowest_Level_Portfolio ON dbo.Fact_Heirarchy_Mapping.Lowest_Level_Portfolio_Key = dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Key INNER JOIN
                         dbo.vLatestRun ON dbo.Fact_Heirarchy_Mapping.Run_Key = dbo.vLatestRun.LatestRun AND dbo.vLatestRun.Process_Detail = 'GAM Segment Mapping Latest' INNER JOIN
                         dbo.Dim_Country ON dbo.Fact_Heirarchy_Mapping.Country_Key = dbo.Dim_Country.Country_Key INNER JOIN
                         dbo.Dim_Region ON dbo.Dim_Country.Region_Key = dbo.Dim_Region.Region_Key LEFT OUTER JOIN
                         dbo.Dim_Product_Type ON dbo.Fact_Heirarchy_Mapping.Product_Type_Key = dbo.Dim_Product_Type.Product_Type_Key LEFT OUTER JOIN
                         dbo.Dim_Par_Status ON dbo.Fact_Heirarchy_Mapping.Par_Status_Key = dbo.Dim_Par_Status.Par_Status_Key
						 
GO
/****** Object:  Table [dbo].[Fact_Forecasts]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Forecasts](
	[Forecasts_Key] [int] IDENTITY(0,1) NOT NULL,
	[Run_Key] [int] NOT NULL,
	[Country_Key] [int] NOT NULL,
	[Tax_Indicator_Key] [int] NOT NULL,
	[Lowest_Level_Portfolio_Key] [int] NOT NULL,
	[Balance_Sheet_Component_Key] [int] NOT NULL,
	[IFRS_Earnings_Component_Key] [int] NOT NULL,
	[Scenario_Key] [int] NOT NULL,
	[Currency_Key] [int] NOT NULL,
	[Product_Type_Key] [int] NULL,
	[Amount] [decimal](28, 15) NOT NULL,
 CONSTRAINT [PK__Fact_For__4E2F3CE694FF14DD] PRIMARY KEY CLUSTERED 
(
	[Forecasts_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Currency]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Currency](
	[Currency_Key] [int] IDENTITY(0,1) NOT NULL,
	[Currency_Alpha_Code] [nvarchar](10) NULL,
	[Currency_Numeric_Code] [smallint] NULL,
	[Currency_Name] [nvarchar](100) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Currency_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vIRRFEaRForecasting]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*AND dbo.vLatestQERun.Reporting_Date_Key = dbo.vHeirarchyMapping.Reporting_Date_Key*/
CREATE VIEW [dbo].[vIRRFEaRForecasting]
AS
SELECT        dbo.Fact_Forecasts.Run_Key, dbo.Fact_Forecasts.Amount, dbo.Fact_Forecasts.Lowest_Level_Portfolio_Key, dbo.vLatestRun.Process_Detail, dbo.vLatestRun.Process_Name, dbo.vLatestRun.Date_Key, 
                         dbo.vLatestRun.Reporting_Date_Key, dbo.vHeirarchyMappingLatest.Tam_Segment_Name, dbo.vHeirarchyMappingLatest.Region_Name, dbo.vHeirarchyMappingLatest.Country_Name, dbo.vHeirarchyMappingLatest.Tax_Rate, 
                         dbo.vHeirarchyMappingLatest.Minority_Interest, dbo.vHeirarchyMappingLatest.Region_Code, dbo.vHeirarchyMappingLatest.Country_Code, dbo.vHeirarchyMappingLatest.Par_Status_Name, 
                         dbo.vHeirarchyMappingLatest.Product_Type_Name, dbo.Dim_Tax_Indicator.Tax_Indicator_Name, dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Name, 
                         dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Name, dbo.Dim_Currency.Currency_Alpha_Code, dbo.Dim_Currency.Currency_Name, dbo.Dim_Scenario.Scenario_Long_Name, 
                         dbo.Dim_Scenario.Scenario_Name, dbo.vHeirarchyMappingLatest.Lowest_Level_Portfolio_Name, CONVERT(CHAR(8), DATEADD(DAY, - 1, DATEADD(QUARTER, DATEDIFF(QUARTER, 0, dbo.Dim_Date.Date) + 2, 0)), 112) 
                         AS ForecastForNextQuarter
FROM            dbo.Fact_Forecasts INNER JOIN
                         dbo.vLatestRun ON dbo.Fact_Forecasts.Run_Key = dbo.vLatestRun.LatestRun AND dbo.vLatestRun.Process_Detail = 'ALM Sensitivities Forecast' INNER JOIN
                         dbo.vHeirarchyMappingLatest ON dbo.Fact_Forecasts.Lowest_Level_Portfolio_Key = dbo.vHeirarchyMappingLatest.Lowest_Level_Portfolio_Key INNER JOIN
                         dbo.Dim_Tax_Indicator ON dbo.Fact_Forecasts.Tax_Indicator_Key = dbo.Dim_Tax_Indicator.Tax_Indicator_Key INNER JOIN
                         dbo.Dim_Balance_Sheet_Component ON dbo.Fact_Forecasts.Balance_Sheet_Component_Key = dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Key INNER JOIN
                         dbo.Dim_IFRS_Earnings_Component ON dbo.Fact_Forecasts.IFRS_Earnings_Component_Key = dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Key INNER JOIN
                         dbo.Dim_Scenario ON dbo.Fact_Forecasts.Scenario_Key = dbo.Dim_Scenario.Scenario_Key INNER JOIN
                         dbo.Dim_Currency ON dbo.Fact_Forecasts.Currency_Key = dbo.Dim_Currency.Currency_Key INNER JOIN
                         dbo.Dim_Date ON dbo.vLatestRun.Date_Key = dbo.Dim_Date.Date_Key
GO
/****** Object:  View [dbo].[vIReaRForecastingALM]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vIReaRForecastingALM]
AS
SELECT   dbo.Fact_Forecasts.Amount, dbo.Fact_Run.Reporting_Date_Key, dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Name, dbo.Dim_Country.Country_Name, 
                         dbo.Dim_Country.Country_Code, dbo.Dim_Region.Region_Name, dbo.Dim_Region.Region_Code, dbo.Dim_Company.Company_Name, dbo.Dim_Scenario.Scenario_Name, 
                         dbo.Dim_Tax_Indicator.Tax_Indicator_Name, dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Name, 
                         dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Name, dbo.Fact_Run.Process_Name, dbo.Fact_Run.Date_Key, Dim_Date.Date, Dim_Date.Quarter_Num, Dim_Date.Year, 
                         'Q' + CAST(Dim_Date.Quarter_Num AS CHAR(1)) + ' ' + CAST(Dim_Date.Year AS CHAR(4)) AS Date_QuarterYear, Dim_Date.Is_Last_Day_Of_Quarter_Ind, 
                         Dim_Date.Is_Last_Day_Of_Month_Ind, Dim_Date.Month_Name, Dim_Date.Month_Num, Dim_Date_1.Date AS Reporting_Date, Dim_Date_1.Quarter_Num AS Reporting_Quarter_Num, 
                         Dim_Date_1.Year AS Reporting_Year, Dim_Date_1.Is_Last_Day_Of_Month_Ind AS Reporting_Is_Last_Day_Of_Month, 
                         Dim_Date_1.Is_Last_Day_Of_Quarter_Ind AS Reporting_Last_Day_Of_Quarter_Ind, Dim_Date_1.Month_Name AS Reporting_Month_Name, 
                         Dim_Date_1.Month_Num AS Reporting_Month_Num, 'Q' + CAST(Dim_Date_1.Quarter_Num AS CHAR(1)) + ' ' + CAST(Dim_Date_1.Year AS CHAR(4)) AS Reporting_QuarterYear, 
                         dbo.Fact_Run.Run_Key
FROM         dbo.Fact_Forecasts INNER JOIN
                         dbo.Fact_Run ON dbo.Fact_Forecasts.Run_Key = dbo.Fact_Run.Run_Key INNER JOIN
                         dbo.Dim_Lowest_Level_Portfolio ON dbo.Fact_Forecasts.Lowest_Level_Portfolio_Key = dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Key INNER JOIN
                         dbo.Dim_Country ON dbo.Dim_Country.Country_Key = dbo.Fact_Forecasts.Country_Key INNER JOIN
                         dbo.Dim_Region ON dbo.Dim_Country.Region_Key = dbo.Dim_Region.Region_Key INNER JOIN
                         dbo.Dim_Company ON dbo.Dim_Region.Company_Key = dbo.Dim_Company.Company_Key INNER JOIN
                         dbo.Dim_Scenario ON dbo.Fact_Forecasts.Scenario_Key = dbo.Dim_Scenario.Scenario_Key INNER JOIN
                         dbo.Dim_Tax_Indicator ON dbo.Fact_Forecasts.Tax_Indicator_Key = dbo.Dim_Tax_Indicator.Tax_Indicator_Key INNER JOIN
                         dbo.Dim_Balance_Sheet_Component ON dbo.Fact_Forecasts.Balance_Sheet_Component_Key = dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Key INNER JOIN
                         dbo.Dim_IFRS_Earnings_Component ON dbo.Fact_Forecasts.IFRS_Earnings_Component_Key = dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Key INNER JOIN
                         dbo.Dim_Date AS Dim_Date ON dbo.Fact_Run.Date_Key = Dim_Date.Date_Key INNER JOIN
                         dbo.Dim_Date AS Dim_Date_1 ON dbo.Fact_Run.Reporting_Date_Key = Dim_Date_1.Date_Key
WHERE     (dbo.Fact_Run.Run_Key IN
                             (SELECT   MAX(Run_Key) AS LatestRunKey
                                FROM         dbo.Fact_Run AS Fact_Run_1
                                WHERE     (Process_Name = 'ALM Forecast') AND (Process_Name = 'ALM Forecast') AND (Is_Latest = 1)
                                GROUP BY Date_Key))
GO
/****** Object:  View [dbo].[vFactDailyForecasting]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vFactDailyForecasting]
AS
SELECT   dbo.Fact_DailyForecasts.DailyForecasts_Key, dbo.Fact_Run.Process_Name, dbo.Fact_Run.Date_Key, dbo.Fact_Run.Reporting_Date_Key, dbo.Dim_Date.Date AS Reporting_Date, 
                         'Q' + CAST(Dim_Date.Quarter_Num AS CHAR(1)) + ' ' + CAST(Dim_Date.Year AS CHAR(4)) AS Reporting_QuarterYear, dbo.Dim_Date.Quarter_Num AS Reporting_Quarter_Num, 
                         dbo.Dim_Date.Year AS Reporting_Year, Dim_Date_1.Date, Dim_Date_1.Quarter_Num, Dim_Date_1.Year, 'Q' + CAST(Dim_Date_1.Quarter_Num AS CHAR(1)) 
                         + ' ' + CAST(Dim_Date_1.Year AS CHAR(4)) AS Date_QuarterYear, dbo.Dim_Country.Country_Name, dbo.Dim_Tax_Indicator.Tax_Indicator_Name, 
                         dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Name, dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Name, 
                         dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Name, dbo.Dim_Scenario.Scenario_Name, dbo.Dim_Currency.Currency_Name, dbo.Fact_DailyForecasts.Amount, 
                         dbo.Dim_Region.Region_Name, dbo.Dim_Region.Region_Code, dbo.Dim_Company.Company_Name
FROM         dbo.Fact_DailyForecasts INNER JOIN
                         dbo.Fact_Run ON dbo.Fact_DailyForecasts.Run_Key = dbo.Fact_Run.Run_Key AND dbo.Fact_Run.Process_Name = 'Daily Forecasting' INNER JOIN
                         dbo.Dim_Date ON dbo.Fact_Run.Reporting_Date_Key = dbo.Dim_Date.Date_Key INNER JOIN
                         dbo.Dim_Date AS Dim_Date_1 ON dbo.Fact_Run.Date_Key = Dim_Date_1.Date_Key AND dbo.Fact_Run.Reporting_Date_Key = Dim_Date_1.Date_Key INNER JOIN
                         dbo.Dim_Country ON dbo.Fact_DailyForecasts.Country_Key = dbo.Dim_Country.Country_Key INNER JOIN
                         dbo.Dim_Tax_Indicator ON dbo.Fact_DailyForecasts.Tax_Indicator_Key = dbo.Dim_Tax_Indicator.Tax_Indicator_Key INNER JOIN
                         dbo.Dim_Lowest_Level_Portfolio ON dbo.Fact_DailyForecasts.Lowest_Level_Portfolio_Key = dbo.Dim_Lowest_Level_Portfolio.Lowest_Level_Portfolio_Key INNER JOIN
                         dbo.Dim_Balance_Sheet_Component ON dbo.Fact_DailyForecasts.Balance_Sheet_Component_Key = dbo.Dim_Balance_Sheet_Component.Balance_Sheet_Component_Key INNER JOIN
                         dbo.Dim_IFRS_Earnings_Component ON dbo.Fact_DailyForecasts.IFRS_Earnings_Component_Key = dbo.Dim_IFRS_Earnings_Component.IFRS_Earnings_Component_Key INNER JOIN
                         dbo.Dim_Scenario ON dbo.Fact_DailyForecasts.Scenario_Key = dbo.Dim_Scenario.Scenario_Key INNER JOIN
                         dbo.Dim_Scenario AS Dim_Scenario_1 ON dbo.Fact_DailyForecasts.Scenario_Key = Dim_Scenario_1.Scenario_Key INNER JOIN
                         dbo.Dim_Currency ON dbo.Fact_DailyForecasts.Currency_Key = dbo.Dim_Currency.Currency_Key INNER JOIN
                         dbo.Dim_Region ON dbo.Dim_Country.Region_Key = dbo.Dim_Region.Region_Key INNER JOIN
                         dbo.Dim_Company ON dbo.Dim_Region.Company_Key = dbo.Dim_Company.Company_Key
GO
/****** Object:  Table [dbo].[Dim_Asset_Segment]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Asset_Segment](
	[Asset_Segment_Key] [int] IDENTITY(0,1) NOT NULL,
	[Asset_Segment_Name] [nvarchar](100) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Asset_Segment_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Liability_Segment]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Liability_Segment](
	[Liability_Segment_Key] [int] IDENTITY(0,1) NOT NULL,
	[Liability_Segment_Name] [nvarchar](255) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
 CONSTRAINT [PK__Dim_Liab__D00C72D54DF814F4] PRIMARY KEY CLUSTERED 
(
	[Liability_Segment_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Risk_Type]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Risk_Type](
	[Risk_Type_Key] [int] IDENTITY(0,1) NOT NULL,
	[Risk_Type_Name] [nvarchar](100) NULL,
	[Risk_Type_Short_Name] [nvarchar](100) NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Risk_Type_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Sub_Risk_Type]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Sub_Risk_Type](
	[Sub_Risk_Type_Key] [int] IDENTITY(0,1) NOT NULL,
	[Sub_Risk_Type_Name] [nvarchar](100) NULL,
	[Sub_Risk_Type_Short_Name] [nvarchar](100) NULL,
	[Risk_Type_Key] [int] NOT NULL,
	[Is_Active] [bit] NULL,
	[Sys_Create_Date] [datetime] NULL,
	[Sys_Create_By] [nvarchar](100) NULL,
	[Start_Date] [datetime] NOT NULL,
	[End_Date] [datetime] NULL,
	[Original_Key] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Sub_Risk_Type_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Actuals]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Actuals](
	[Actuals_Key] [int] IDENTITY(0,1) NOT NULL,
	[Run_Key] [int] NOT NULL,
	[Country_Key] [int] NOT NULL,
	[Tax_Indicator_Key] [int] NOT NULL,
	[Lowest_Level_Portfolio_Key] [int] NOT NULL,
	[Balance_Sheet_Component_Key] [int] NOT NULL,
	[IFRS_Earnings_Component_Key] [int] NOT NULL,
	[Scenario_Key] [int] NOT NULL,
	[Par_Status_Key] [int] NULL,
	[Currency_Key] [int] NOT NULL,
	[Amount] [decimal](28, 15) NOT NULL,
 CONSTRAINT [PK__Fact_Act__FCD17BE70D6AEF70] PRIMARY KEY CLUSTERED 
(
	[Actuals_Key] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EaR_FinalShocks]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EaR_FinalShocks](
	[Currency] [char](3) NOT NULL,
	[Tenor] [float] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EaR_FinalShocks] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Tenor] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EaR_PCA_CorrStats]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EaR_PCA_CorrStats](
	[Currency] [char](3) NOT NULL,
	[Currency2] [char](3) NOT NULL,
	[PC] [smallint] NOT NULL,
	[Value] [int] NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EaR_PCA_CorrStats] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Currency2] ASC,
	[PC] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EaR_PCA_Stats]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EaR_PCA_Stats](
	[Currency] [char](3) NOT NULL,
	[Term] [nvarchar](30) NOT NULL,
	[PC] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EaR_PCA_Stats] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Term] ASC,
	[PC] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EaR_Shocks]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EaR_Shocks](
	[Currency] [char](3) NOT NULL,
	[Tenor] [float] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EaR_Shocks] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Tenor] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_FinalShocks]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_FinalShocks](
	[Currency] [char](3) NOT NULL,
	[Tenor] [float] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_FinalShocks] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Tenor] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_PCA]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_PCA](
	[Currency] [char](3) NOT NULL,
	[PC] [smallint] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_PCA] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[PC] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_PCA_CorrStats]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_PCA_CorrStats](
	[Currency] [char](3) NOT NULL,
	[Currency2] [char](3) NOT NULL,
	[PC] [smallint] NOT NULL,
	[Value] [int] NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_PCA_CorrStats] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Currency2] ASC,
	[PC] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_PCA_Resampled]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_PCA_Resampled](
	[Currency] [char](3) NOT NULL,
	[PC] [smallint] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_PCA_Resampled] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[PC] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_PCA_Stats]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_PCA_Stats](
	[Currency] [char](3) NOT NULL,
	[Term] [nvarchar](30) NOT NULL,
	[PC] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_PCA_Stats] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Term] ASC,
	[PC] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_Shocks]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_Shocks](
	[Currency] [char](3) NOT NULL,
	[Tenor] [float] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_Shocks] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Tenor] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RF_EC_Shocks_Resampled]    Script Date: 3/4/2026 6:48:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RF_EC_Shocks_Resampled](
	[Currency] [char](3) NOT NULL,
	[Tenor] [float] NOT NULL,
	[Scenario] [smallint] NOT NULL,
	[Shocks] [decimal](28, 15) NOT NULL,
	[Effective_Date] [date] NOT NULL,
	[Load_TS] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_RF_EC_Shocks_Resampled] PRIMARY KEY CLUSTERED 
(
	[Currency] ASC,
	[Tenor] ASC,
	[Scenario] ASC,
	[Effective_Date] ASC,
	[Load_TS] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Dim_Asset_Segment] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Asset_Segment] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Balance_Sheet_Component] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Balance_Sheet_Component] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Company] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Company] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Company] ADD  DEFAULT (getdate()) FOR [Start_Date]
GO
ALTER TABLE [dbo].[Dim_Country] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Country] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Currency] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Currency] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Date] ADD  DEFAULT (getdate()) FOR [Sys_Creation_Date]
GO
ALTER TABLE [dbo].[Dim_Date] ADD  CONSTRAINT [DF_Dim_Date_Is_Active]  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_IFRS_Earnings_Component] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_IFRS_Earnings_Component] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Liability_Segment] ADD  CONSTRAINT [DF__Dim_Liabi__Is_Ac__498EEC8D]  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Liability_Segment] ADD  CONSTRAINT [DF__Dim_Liabi__Sys_C__4A8310C6]  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Lowest_Level_Portfolio] ADD  CONSTRAINT [DF__Dim_Lowes__Is_Ac__4C6B5938]  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Lowest_Level_Portfolio] ADD  CONSTRAINT [DF__Dim_Lowes__Sys_C__4D5F7D71]  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Lowest_Level_Portfolio] ADD  CONSTRAINT [DF_Dim_Lowest_Level_Portfolio_Surplus_Indicator]  DEFAULT ((0)) FOR [Surplus_Indicator]
GO
ALTER TABLE [dbo].[Dim_Par_Status] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Par_Status] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Product_Type] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Product_Type] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Region] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Region] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Risk_Type] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Risk_Type] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Scenario] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Scenario] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Sub_Risk_Type] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Sub_Risk_Type] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Tam_Segment] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Tam_Segment] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Dim_Tax_Indicator] ADD  DEFAULT ((1)) FOR [Is_Active]
GO
ALTER TABLE [dbo].[Dim_Tax_Indicator] ADD  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Fact_Run] ADD  CONSTRAINT [DF__Fact_Run__Is_Lat__607251E5]  DEFAULT ((1)) FOR [Is_Latest]
GO
ALTER TABLE [dbo].[Fact_Run] ADD  CONSTRAINT [DF__Fact_Run__Is_App__6166761E]  DEFAULT ((0)) FOR [Is_Approved]
GO
ALTER TABLE [dbo].[Fact_Run] ADD  CONSTRAINT [DF__Fact_Run__Sys_Cr__625A9A57]  DEFAULT (getdate()) FOR [Sys_Create_Date]
GO
ALTER TABLE [dbo].[Fact_Run] ADD  CONSTRAINT [DF__Fact_Run__Sys_La__634EBE90]  DEFAULT (getdate()) FOR [Sys_Last_Mod_Date]
GO
ALTER TABLE [dbo].[Dim_Country]  WITH CHECK ADD FOREIGN KEY([Region_Key])
REFERENCES [dbo].[Dim_Region] ([Region_Key])
GO
ALTER TABLE [dbo].[Dim_Lowest_Level_Portfolio]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Lowest_Level_Portfolio_Dim_Currency] FOREIGN KEY([Target_Currency_Key])
REFERENCES [dbo].[Dim_Currency] ([Currency_Key])
GO
ALTER TABLE [dbo].[Dim_Lowest_Level_Portfolio] CHECK CONSTRAINT [FK_Dim_Lowest_Level_Portfolio_Dim_Currency]
GO
ALTER TABLE [dbo].[Dim_Region]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Region_Dim_Company] FOREIGN KEY([Company_Key])
REFERENCES [dbo].[Dim_Company] ([Company_Key])
GO
ALTER TABLE [dbo].[Dim_Region] CHECK CONSTRAINT [FK_Dim_Region_Dim_Company]
GO
ALTER TABLE [dbo].[Dim_Sub_Risk_Type]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Sub_Risk_Type_Dim_Risk_Type] FOREIGN KEY([Risk_Type_Key])
REFERENCES [dbo].[Dim_Risk_Type] ([Risk_Type_Key])
GO
ALTER TABLE [dbo].[Dim_Sub_Risk_Type] CHECK CONSTRAINT [FK_Dim_Sub_Risk_Type_Dim_Risk_Type]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Balan__65370702] FOREIGN KEY([Balance_Sheet_Component_Key])
REFERENCES [dbo].[Dim_Balance_Sheet_Component] ([Balance_Sheet_Component_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Balan__65370702]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Count__662B2B3B] FOREIGN KEY([Country_Key])
REFERENCES [dbo].[Dim_Country] ([Country_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Count__662B2B3B]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Curre__671F4F74] FOREIGN KEY([Currency_Key])
REFERENCES [dbo].[Dim_Currency] ([Currency_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Curre__671F4F74]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__IFRS___681373AD] FOREIGN KEY([IFRS_Earnings_Component_Key])
REFERENCES [dbo].[Dim_IFRS_Earnings_Component] ([IFRS_Earnings_Component_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__IFRS___681373AD]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Lowes__690797E6] FOREIGN KEY([Lowest_Level_Portfolio_Key])
REFERENCES [dbo].[Dim_Lowest_Level_Portfolio] ([Lowest_Level_Portfolio_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Lowes__690797E6]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Par_S__69FBBC1F] FOREIGN KEY([Par_Status_Key])
REFERENCES [dbo].[Dim_Par_Status] ([Par_Status_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Par_S__69FBBC1F]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Run_K__6AEFE058] FOREIGN KEY([Run_Key])
REFERENCES [dbo].[Fact_Run] ([Run_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Run_K__6AEFE058]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Scena__6BE40491] FOREIGN KEY([Scenario_Key])
REFERENCES [dbo].[Dim_Scenario] ([Scenario_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Scena__6BE40491]
GO
ALTER TABLE [dbo].[Fact_Actuals]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Actu__Tax_I__6CD828CA] FOREIGN KEY([Tax_Indicator_Key])
REFERENCES [dbo].[Dim_Tax_Indicator] ([Tax_Indicator_Key])
GO
ALTER TABLE [dbo].[Fact_Actuals] CHECK CONSTRAINT [FK__Fact_Actu__Tax_I__6CD828CA]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Balan__6DCC4D03] FOREIGN KEY([Balance_Sheet_Component_Key])
REFERENCES [dbo].[Dim_Balance_Sheet_Component] ([Balance_Sheet_Component_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Balan__6DCC4D03]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Count__6EC0713C] FOREIGN KEY([Country_Key])
REFERENCES [dbo].[Dim_Country] ([Country_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Count__6EC0713C]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Curre__6FB49575] FOREIGN KEY([Currency_Key])
REFERENCES [dbo].[Dim_Currency] ([Currency_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Curre__6FB49575]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__IFRS___70A8B9AE] FOREIGN KEY([IFRS_Earnings_Component_Key])
REFERENCES [dbo].[Dim_IFRS_Earnings_Component] ([IFRS_Earnings_Component_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__IFRS___70A8B9AE]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Lowes__719CDDE7] FOREIGN KEY([Lowest_Level_Portfolio_Key])
REFERENCES [dbo].[Dim_Lowest_Level_Portfolio] ([Lowest_Level_Portfolio_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Lowes__719CDDE7]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Produ__72910220] FOREIGN KEY([Product_Type_Key])
REFERENCES [dbo].[Dim_Product_Type] ([Product_Type_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Produ__72910220]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Run_K__73852659] FOREIGN KEY([Run_Key])
REFERENCES [dbo].[Fact_Run] ([Run_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Run_K__73852659]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Scena__74794A92] FOREIGN KEY([Scenario_Key])
REFERENCES [dbo].[Dim_Scenario] ([Scenario_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Scena__74794A92]
GO
ALTER TABLE [dbo].[Fact_DailyForecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Dail__Tax_I__756D6ECB] FOREIGN KEY([Tax_Indicator_Key])
REFERENCES [dbo].[Dim_Tax_Indicator] ([Tax_Indicator_Key])
GO
ALTER TABLE [dbo].[Fact_DailyForecasts] CHECK CONSTRAINT [FK__Fact_Dail__Tax_I__756D6ECB]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Balan__76619304] FOREIGN KEY([Balance_Sheet_Component_Key])
REFERENCES [dbo].[Dim_Balance_Sheet_Component] ([Balance_Sheet_Component_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Balan__76619304]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Count__7755B73D] FOREIGN KEY([Country_Key])
REFERENCES [dbo].[Dim_Country] ([Country_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Count__7755B73D]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Curre__7849DB76] FOREIGN KEY([Currency_Key])
REFERENCES [dbo].[Dim_Currency] ([Currency_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Curre__7849DB76]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__IFRS___793DFFAF] FOREIGN KEY([IFRS_Earnings_Component_Key])
REFERENCES [dbo].[Dim_IFRS_Earnings_Component] ([IFRS_Earnings_Component_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__IFRS___793DFFAF]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Lowes__7A3223E8] FOREIGN KEY([Lowest_Level_Portfolio_Key])
REFERENCES [dbo].[Dim_Lowest_Level_Portfolio] ([Lowest_Level_Portfolio_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Lowes__7A3223E8]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Produ__7B264821] FOREIGN KEY([Product_Type_Key])
REFERENCES [dbo].[Dim_Product_Type] ([Product_Type_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Produ__7B264821]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Run_K__7C1A6C5A] FOREIGN KEY([Run_Key])
REFERENCES [dbo].[Fact_Run] ([Run_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Run_K__7C1A6C5A]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Scena__7D0E9093] FOREIGN KEY([Scenario_Key])
REFERENCES [dbo].[Dim_Scenario] ([Scenario_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Scena__7D0E9093]
GO
ALTER TABLE [dbo].[Fact_Forecasts]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Fore__Tax_I__7E02B4CC] FOREIGN KEY([Tax_Indicator_Key])
REFERENCES [dbo].[Dim_Tax_Indicator] ([Tax_Indicator_Key])
GO
ALTER TABLE [dbo].[Fact_Forecasts] CHECK CONSTRAINT [FK__Fact_Fore__Tax_I__7E02B4CC]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Asset__7EF6D905] FOREIGN KEY([Asset_Segment_Key])
REFERENCES [dbo].[Dim_Asset_Segment] ([Asset_Segment_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Asset__7EF6D905]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Count__7FEAFD3E] FOREIGN KEY([Country_Key])
REFERENCES [dbo].[Dim_Country] ([Country_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Count__7FEAFD3E]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Liabi__00DF2177] FOREIGN KEY([Liability_Segment_Key])
REFERENCES [dbo].[Dim_Liability_Segment] ([Liability_Segment_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Liabi__00DF2177]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Lowes__01D345B0] FOREIGN KEY([Lowest_Level_Portfolio_Key])
REFERENCES [dbo].[Dim_Lowest_Level_Portfolio] ([Lowest_Level_Portfolio_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Lowes__01D345B0]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Par_S__02C769E9] FOREIGN KEY([Par_Status_Key])
REFERENCES [dbo].[Dim_Par_Status] ([Par_Status_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Par_S__02C769E9]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Produ__03BB8E22] FOREIGN KEY([Product_Type_Key])
REFERENCES [dbo].[Dim_Product_Type] ([Product_Type_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Produ__03BB8E22]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Run_K__04AFB25B] FOREIGN KEY([Run_Key])
REFERENCES [dbo].[Fact_Run] ([Run_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Run_K__04AFB25B]
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Heir__Tam_S__05A3D694] FOREIGN KEY([Tam_Segment_Key])
REFERENCES [dbo].[Dim_Tam_Segment] ([Tam_Segment_Key])
GO
ALTER TABLE [dbo].[Fact_Heirarchy_Mapping] CHECK CONSTRAINT [FK__Fact_Heir__Tam_S__05A3D694]
GO
ALTER TABLE [dbo].[Fact_Run]  WITH CHECK ADD  CONSTRAINT [FK__Fact_Run__Date_K__0697FACD] FOREIGN KEY([Date_Key])
REFERENCES [dbo].[Dim_Date] ([Date_Key])
GO
ALTER TABLE [dbo].[Fact_Run] CHECK CONSTRAINT [FK__Fact_Run__Date_K__0697FACD]
GO
ALTER TABLE [dbo].[Fact_Run]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Run_Dim_Date] FOREIGN KEY([Reporting_Date_Key])
REFERENCES [dbo].[Dim_Date] ([Date_Key])
GO
ALTER TABLE [dbo].[Fact_Run] CHECK CONSTRAINT [FK_Fact_Run_Dim_Date]
GO
