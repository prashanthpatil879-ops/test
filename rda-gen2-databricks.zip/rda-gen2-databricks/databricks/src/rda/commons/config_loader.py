import os 
import yaml 
import subprocess as sp 
from pathlib import Path 

class EnvConfig:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(EnvConfig, cls).__new__(cls)
            cls._instance.__dict__['_initialized'] = False
        return cls._instance

    def __init__(self, dbutils=None, env_override=None):
        if self.__dict__.get('_initialized'):
            return
        
        self.__dict__['_config'] = None
        self.__dict__['_omegaConf'] = None

        env = self._resolve_environment(__file__, env_override)
        print(f"Environment resolved: {env}...")

        config_file = Path(os.path.join(Path(__file__).resolve().parent.parent, "configs", f"{env.lower()}.yaml"))
        print(f"Loading config file: {config_file}")
        if not config_file.exists():
            raise FileNotFoundError(f"Config file not found: {config_file}")
        
        self.__dict__['_config_file'] = config_file
        self._bootstrap(dbutils)
        self.__dict__['_initialized'] = True

    def _bootstrap(self, dbutils):
        with open(self.__dict__['_config_file'], 'r') as f:
            config_raw = yaml.safe_load(f)
        
        scope = config_raw["secret_scope"]
        artifactory = config_raw["artifactory"]

        artifactory_user = dbutils.secrets.get(scope, artifactory["serviceaccount_key"])
        artifactory_token = dbutils.secrets.get(scope, artifactory["token_key"])

        requirements_file = self.__dict__['_config_file'].parent.parent.parent.parent / "requirements.txt"
        print(f"Requirements file: {requirements_file}")

        sp.check_call(["pip", "install", "-r", str(requirements_file), "--index-url", f"https://{artifactory_user}:{artifactory_token}@{artifactory['url']}", "--quiet"])

        from omegaconf import OmegaConf
        self.__dict__['_omegaConf'] = OmegaConf
        self.__dict__['_config'] = OmegaConf.load(self.__dict__['_config_file'])

        resolved = {
            key.replace("_key", "") : dbutils.secrets.get(scope, value)
            for key, value in config_raw["secrets"].items()
        }

        self.__dict__['_config'] = OmegaConf.merge(self._config, {"secrets": resolved})
    
    def get(self, key, default=None):
        omegaConf = self.__dict__.get("_omegaConf")
        config = self.__dict__.get("_config")
        if omegaConf is None or config is None:
            raise RuntimeError("Config not initialized fully yet")
        return omegaConf.select(self._config, key, default=default)
    
    def as_dict(self):
        return self.__dict__['_omegaConf'].to_container(self.__dict__['_config'], resolve=True)
    
    def __getattr__(self, key):
        return self.get(key)

    def _resolve_environment(self, file_path:str, env_override:str=None) -> str:
        env = None
        workspace = file_path.split("/")[2].lower()
        
        if workspace in ['preprod', 'pre-prod', 'uat', 'pp']:
            env = 'uat'
        elif 'prod' in workspace:
            env = 'prod'
        elif 'qa' in workspace:
            env = 'qa'
        else:
            env = 'dev'
        
        return env_override or env

