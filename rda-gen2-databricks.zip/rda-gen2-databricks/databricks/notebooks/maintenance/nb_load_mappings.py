# Databricks notebook source
# MAGIC %run ../common/nb_load_rda_package

# COMMAND ----------

config_key = "cache"

# COMMAND ----------

from rda.io.sql_mi import SqlMI
from rda.io.unity_catalog import UnityCatalog
from datetime import datetime
from pyspark.sql import functions as F

# COMMAND ----------

sqlmi = SqlMI(env_config=env_config, spark=spark)
uc = UnityCatalog(env_config=env_config, spark=spark)

# COMMAND ----------

from pyspark.sql import DataFrame
def detect_new_data(new_df: DataFrame, old_df: DataFrame) -> bool:
        
    if old_df is None:
        print("No existing table found. Proceeding with initial load...")
        return True
        
    print("Checking for latest data...")
    old_df_clean = old_df.drop("SOURCE", "CREATED_BY", "INGESTION_TS")
    new_records_df = new_df.exceptAll(old_df_clean)
    if new_records_df.take(1):
        print("New data detected. Proceeding with ingestion...")
        return True
    else:
        print("No new data detected. Skipping ingestion...")
        return False

# COMMAND ----------

def add_audit_columns(df: DataFrame, dataset_cfg):
    print(f"Adding audit columns to the table {dataset_cfg.target_table}")
    df = df.withColumn("SOURCE", F.lit('RDA2DB')) \
    .withColumn('CREATED_BY', F.lit('ADB')) \
    .withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))
        
    df = df.toDF(*[c.upper() for c in df.columns])
    return df

# COMMAND ----------

def is_refresh_day(freq, today):
    if freq == "daily":
        return True
    if freq == "monthly":
        return today.day == 1
    if freq == "quarterly":
        return today.day == 1 and today.month in (1, 4, 7, 10)
    if freq == "semi_annually":
        return today.day == 1 and today.month in (1, 7)
    if freq == "annually":
        return today.day == 1 and today.month == 1
    return False

# COMMAND ----------

for mapping_name, mapping_config in env_config.get(config_key).items():
    
    target_table = mapping_config.get("target_table")
    refresh_freq = mapping_config.get("refresh_freq")
    
    
    table_exists = spark.catalog.tableExists(target_table)
    
    
    if not table_exists:
        is_refresh_needed = True
    else:
        is_refresh_needed = is_refresh_day(refresh_freq, datetime.now())
    
    if not is_refresh_needed:
        print(f"Skipping {target_table} (not scheduled for refresh).")
        continue   
    
    
    new_df = sqlmi.read_table_or_query(
        mapping_config.source_table_or_query.replace(";", "").replace("\n", " ")
    )
    
    
    old_df = uc.read_latest(target_table) if table_exists else None
    
    
    is_new = detect_new_data(new_df, old_df)
    
    
    if not table_exists:
        final_df = add_audit_columns(new_df, mapping_config)
        uc.write(final_df, target_table, mapping_config.ext_table_loc, mode="append")
        print(f"{target_table} created and loaded.")
    
    elif is_new:
        final_df = add_audit_columns(new_df, mapping_config)
        uc.write(final_df, target_table, mapping_config.ext_table_loc, mode="append")
        print(f"{target_table} refreshed (scheduled + new data found).")
    
    else:
        print(f"{target_table} scheduled but no new data found, skipping write.")