# Databricks notebook source
# MAGIC %run ../common/nb_load_rda_package

# COMMAND ----------

from rda.io.sql_mi import SqlMI
from rda.io.unity_catalog import UnityCatalog
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql import DataFrame

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Dimesnsional tables ingestion started...")

# COMMAND ----------

default_tables = [
    'Dim_Asset_Segment',
    'Dim_Balance_Sheet_Component',
    'Dim_Company',
    'Dim_Country',
    'Dim_Currency',
    'Dim_Date',
    'Dim_Forecast_Date',
    'Dim_IFRS_Earnings_Component',
    'Dim_IR_BEY_Row_Tenor_Mapping',
    'Dim_Liability_Segment',
    'Dim_Lowest_Level_Portfolio',
    'Dim_Par_Status',
    'Dim_Product_Type',
    'Dim_Region',
    'Dim_Risk_Type',
    'Dim_Scenario',
    'Dim_Sub_Risk_Type',
    'Dim_Tam_Segment',
    'Dim_Tax_Indicator',
    'Dim_Tenors'
]

dbutils.widgets.text("dim_tables", "")

widget_value = dbutils.widgets.get("dim_tables").strip()

if widget_value:
    dim_tables_list = [table.strip() for table in widget_value.split(",")]
else:
    dim_tables_list = default_tables

logger.info(f"Source dimensional tables list to process: {dim_tables_list}")

# COMMAND ----------

target_schema = env_config.schema.semantic
external_base_path = env_config.adls.semantic
env_table_prefix = env_config.env_table_prefix
source_schema = 'dbo'

# COMMAND ----------

sqlmi = SqlMI(env_config=env_config, spark=spark)
uc = UnityCatalog(env_config=env_config, spark=spark)

# COMMAND ----------

def detect_new_data(new_df: DataFrame, old_df: DataFrame) -> bool:
        
    if old_df is None:
        return True
        
    logger.info("Checking for latest data...")
    old_df_clean = old_df.drop("AUDIT_SOURCE", "CREATED_BY", "INGESTION_TS")
    new_records_df = new_df.exceptAll(old_df_clean)
    if new_records_df.take(1):
        return True
    else:
        return False

# COMMAND ----------

def add_audit_columns(df: DataFrame, source_table, target_table):
    logger.info(f"Adding audit columns to the table {target_table}")
    df = df.withColumn("AUDIT_SOURCE", F.lit(source_table)) \
    .withColumn('CREATED_BY', F.lit('ADB')) \
    .withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))
        
    df = df.toDF(*[c.upper() for c in df.columns])
    return df
    



# COMMAND ----------

for table_name in dim_tables_list:
    source_table = f"{source_schema}.{table_name}"
    target_table = f"{target_schema}.{env_table_prefix}{table_name}"
    external_path = f"{external_base_path}/{env_table_prefix}{table_name}"

    table_exists = spark.catalog.tableExists(target_table)
    logger.info(f"Extracting data from source table {source_table} ")
    source_df = sqlmi.read_table(source_table)

    old_df = uc.read_latest(target_table) if table_exists else None
    is_new = (detect_new_data(source_df, old_df) if table_exists else True)
    if not table_exists or is_new:
        message = f"No existing table found for {target_table}. Proceeding with initial load..." if not table_exists else f"New data detected in source table {source_table}. Proceeding with ingestion..."
        logger.info(message)
        final_df = add_audit_columns(source_df, source_table, target_table)
        uc.write(final_df, target_table, external_path, mode="append")
    else:
        logger.info(f"{target_table} scheduled but no new data found, skipping ingestion.")