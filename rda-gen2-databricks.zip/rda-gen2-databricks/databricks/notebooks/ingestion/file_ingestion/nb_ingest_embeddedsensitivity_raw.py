# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import numpy as np
import re

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType, DecimalType

from rda.utils.date_utils import get_previous_quarter_end_date

# COMMAND ----------

#Read config file sheet <Sheets> to be used to identify sheets that will be processed
pdf_sheets = read_excel(env_config.get("common.config_files.embeddedsensitivity"), sheet_name='Sheets', header=0)
# display(pdf_sheets)

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.embeddedsensitivity.file_pattern")}' in '{env_config.get("ingest.file.embeddedsensitivity.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.embeddedsensitivity.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.embeddedsensitivity.file_pattern"))
files_to_process = sorted(files_to_process, key=lambda x: x.path)

print(f"Found {[file.name for file in files_to_process]} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Embedded_Pct_Type': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Pct_Amount': pd.Series(dtype='float')
}

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:

    processname = 'Embedded Sensitivity'

    # Create the empty DataFrame
    pdf_output = pd.DataFrame(columns)

    #Call the function to extract the data
    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    for sheet_row in pdf_sheets.iterrows():        
        print(f"Processing file: {f.name} sheet: {sheet_row[1]['SheetName']}")        
        try:
            pdf_source = pd.read_excel(bin_buffer, header=None, dtype=str, sheet_name=sheet_row[1]['SheetName'])
            pdf_source = pdf_source[18:]          

            pdf_source = pdf_source[~pdf_source[pdf_source.columns[sheet_row[1]['LLP']]].str.startswith('Source', na=False)]

            output_rows = pd.DataFrame(columns)
            
            output_rows['Lowest_Level_Portfolio_Name'] = pdf_source[pdf_source.columns[sheet_row[1]['LLP']]]
            output_rows['Pct_Amount'] = pdf_source[pdf_source.columns[sheet_row[1]['Pct']]]
            output_rows['Embedded_Pct_Type'] = sheet_row[1]['Embedded_Pct_Type']

            pdf_output = pd.concat([pdf_output, output_rows], ignore_index=True) 

        except ValueError as e:
            print(f"Error reading file: {f.name} sheet: {sheet_row[1]['SheetName']}, Error: {e}")
            continue
        except Exception as e:
            print(f"An error occurred: {e}")
            continue

    print(len(pdf_output))
    pdf_output['Source_File'] = f.name

    #Add the date and key columns
    datetoday = datetime.now(ZoneInfo("UTC"))
    pdf_output['Ingestion_TS'] = datetoday

    #Extract reporting date from filename
    for d in re.findall(r'\d+', f.name):
        if(len(d) == 8):
            datepart = datetime.strptime(d, '%Y%m%d')

    pdf_output['Forecast_Date'] = datepart.strftime('%Y-%m-%d')

    datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
    print(datetimestamp)

    df_run = spark.createDataFrame(data=[(processname, f.name, datetoday, None, None, None)], 
                                   schema=StructType([StructField("Process_Name", StringType(), True),
                                                StructField("Source_File", StringType(), True),
                                                StructField("Ingestion_TS", TimestampType(), True),
                                                StructField("Curation_TS", TimestampType(), True),
                                                StructField("Consumption_TS", TimestampType(), True),
                                                StructField("Consumption_Remarks", StringType(), True)]))
    
    # display(df_run)    
    # display(pdf_output)

    if(len(pdf_output) > 0): 
        spark.createDataFrame(pdf_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.embeddedsensitivity.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.embeddedsensitivity.raw_table"))

        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    ext = f.name[f.name.rindex("."):]
    gam_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.embeddedsensitivity.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{gam_archive_file}")
     