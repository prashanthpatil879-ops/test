# Databricks notebook source
# MAGIC %md
# MAGIC ### Notebook to load IQ EC forecast data to RAW from Files

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

dataset_key = "iq_ec_forecast"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.file.{dataset_key}")

# COMMAND ----------

from rda.ingestion.file_ingestor import FileIngestor
from rda.utils import date_utils as du
ingestor = FileIngestor(env_config, spark, dbutils)

# COMMAND ----------

def get_iq_forecast_value(file):
    return file.name.split(" ")[-1].replace(".xlsx", "")

# COMMAND ----------

def get_iq_forecast_value_without_year(file):
    new_file_name = get_iq_forecast_value(file)
    return new_file_name[2:]

# COMMAND ----------

def get_iq_ir_ec_values_df(pdf):
    iq_value_without_year = get_iq_forecast_value_without_year(file)
    iq_value_with_year = get_iq_forecast_value(file)
    iq_value_idx = next(iter([i for i, j in reversed(list(enumerate(pdf.columns))) if j.startswith(iq_value_without_year)]))
    forecast_date = du.parse_iq_forecast_date(iq_value_with_year)
    qe_date = du.get_previous_quarter_end_date(forecast_date)
    col_idx_needed = list(range(iq_value_idx+3, iq_value_idx+6))
    col_idx_needed.insert(0, 0)
    temp_pdf = pdf.iloc[:, col_idx_needed]
    temp_pdf.columns = ['LOWEST_LEVEL_PORTFOLIO_NAME', 'RF_EC', 'SS_EC', 'IR_EC']
    mask = temp_pdf['LOWEST_LEVEL_PORTFOLIO_NAME'].eq('Total Surplus')
    temp_pdf = temp_pdf.loc[:mask.idxmax()]
    temp_pdf = temp_pdf[(temp_pdf.iloc[:,0].notna()) & (~temp_pdf.iloc[:,0].isin(["Total US", "Total Canada", "Total Asia", "Total Surplus", "Total", "Buffer", "EC_Down_A"]))]
    temp_pdf[['RF_EC', 'SS_EC', 'IR_EC']] = temp_pdf[['RF_EC', 'SS_EC', 'IR_EC']].fillna(0)
    temp_pdf = temp_pdf.melt(id_vars='LOWEST_LEVEL_PORTFOLIO_NAME', var_name='EC_METRIC', value_name='AMOUNT')
    temp_pdf["FORECAST_DATE"] = forecast_date
    temp_pdf["REPORTING_DATE"] = qe_date
    return temp_pdf

# COMMAND ----------

files = ingestor.list_and_filter_files(dataset_cfg.landing, dataset_cfg.file_pattern)

if not files:
    dbutils.notebook.exit(f"No new files found in {dataset_cfg.landing} matching pattern '{dataset_cfg.file_pattern}'")
else:
    print(f"Found {str(files)} to process...") 

# COMMAND ----------

import pandas as pd
pdf = pd.DataFrame()

for file in files:
    for sheet in dataset_cfg.sheets.keys():
        pdf_temp = ingestor.read_excel(file, dataset_cfg.sheets.get(sheet))
        pdf_ec = get_iq_ir_ec_values_df(pdf_temp)
        if pdf.empty:
            pdf = pdf_ec
        else:
            pdf = pd.concat([pdf, pdf_ec], ignore_index=True)

    df = spark.createDataFrame(pdf)
    df = ingestor.add_audit_columns(df, file.name)
    ingestor.write(df, dataset_cfg)
    ingestor.archive(file, dataset_cfg.archive)
