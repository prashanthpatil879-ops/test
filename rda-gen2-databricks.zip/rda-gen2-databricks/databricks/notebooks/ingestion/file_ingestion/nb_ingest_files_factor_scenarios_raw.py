# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

dataset_key = "factor_scenarios"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.file.{dataset_key}")

# COMMAND ----------

import pandas as pd
from pyspark.sql.functions import round, col
from pyspark.sql.types import *
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from datetime import datetime, UTC
from rda.ingestion.file_ingestor import FileIngestor
from rda.io.unity_catalog import UnityCatalog
ingestor = FileIngestor(env_config, spark, dbutils)
uc = UnityCatalog(env_config, spark)

# COMMAND ----------

files = ingestor.list_and_filter_files(dataset_cfg.landing, dataset_cfg.file_pattern)

if not files:
    dbutils.notebook.exit(f"No new files found in {dataset_cfg.landing} matching pattern '{dataset_cfg.file_pattern}'")
else:
    print(f"Found {str(files)} to process...") 

# COMMAND ----------

def get_storage_options():
        return {
            "account_name": f"{env_config.get('adls.storage_account')}",
            "tenant_id": f"{env_config.get('secrets.tenant_id')}",
            "client_id": f"{env_config.get('secrets.client_id')}",
            "client_secret": f"{env_config.get('secrets.client_secret')}",        
        }

# COMMAND ----------

def read_metadata(file_path, source_type):
    sheet_name = dataset_cfg.detail_config[source_type]["sheet_name"]
    read_configs = dataset_cfg.detail_config[source_type]["metadata_configs"]

    scenario_df = pd.concat(
        [
            pd.read_excel(
                file_path,
                storage_options=get_storage_options(),
                engine="xlrd",
                sheet_name=sheet_name,
                header=None,
                **config
            )
            for config in read_configs
        ],
        ignore_index=True,
    )

    scenario_dict = dict(zip(scenario_df[0], scenario_df[1]))

    # Validate mandatory columns
    missing_columns = [
        col
        for col in dataset_cfg.mandatory_columns
        if pd.isna(scenario_dict.get(col))
        or str(scenario_dict.get(col)).strip() == ""
    ]

    if missing_columns:
        raise ValueError(
            f"Mandatory metadata missing in "
            f"{os.path.basename(file_path)}: "
            f"{', '.join(missing_columns)}"
        )

    # Add source file name
    scenario_dict["Source"] = os.path.basename(file_path)
    return scenario_dict

# COMMAND ----------

def read_detail(file_path, source_type):

    config = dataset_cfg.detail_config[source_type]

    df = pd.read_excel(
        file_path,
        storage_options=get_storage_options(),
        engine="xlrd",
        sheet_name=config["sheet_name"],
        skiprows=config["detail_skiprows"]
    )

    file_name = os.path.splitext(os.path.basename(file_path))[0]

    df["Scenario_name"] = file_name
    df["Scenario_type"] = "BarraOne Factor Scenarios"

    if config["has_subtype"]:
        df["Scenario_Subtype"] = ("Country Parallel Shocks" if file_name in ["Govt Down 50bps", "Govt Up 50bps"] else "Historical Shocks"
    )
    df["Source"] = os.path.basename(file_path)
    return df

# COMMAND ----------

def add_audit_columns(df: DataFrame) -> DataFrame:
        df = df.withColumn('CREATED_BY', F.lit('ADB')) \
        .withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))
        df = df.toDF(*[c.upper().replace(" ", "_").replace("(", "").replace(")", "") for c in df.columns])
        return df

# COMMAND ----------

metadata_records = []
detail_records = []
metadata_final_df = None
detail_final_df = None

# Get source type from config
source_type = next(iter(dataset_cfg.detail_config.keys()))
batch_timestamp = datetime.now(UTC)
schema = StructType(
    [
        StructField(
            col,
            StringType(),
            False if col in dataset_cfg.mandatory_columns else True
        )
        for col in dataset_cfg.metadata_columns
    ]
    + [
        StructField("Source", StringType(), True)
    ]
)

for file in files:

    scenario_dict = read_metadata(file.path, source_type)
    record = {column: scenario_dict.get(column) for column in dataset_cfg.metadata_columns}
    record["Source"] = scenario_dict["Source"]
    metadata_records.append(record)

    detail_df = read_detail(file.path, source_type)
    detail_records.extend(detail_df.to_dict("records"))

if metadata_records:
    metadata_df = pd.DataFrame(metadata_records)
    metadata_detail_df = spark.createDataFrame(metadata_df, schema=schema)
    metadata_final_df = add_audit_columns(metadata_detail_df)
    uc.write(metadata_final_df, dataset_cfg.master_table.raw_table, dataset_cfg.master_table.raw_ext_table_loc)

if detail_records:
    detail_df = pd.DataFrame(detail_records)
    detail_spark_df = spark.createDataFrame(detail_df)
    cast_column = dataset_cfg.detail_config[source_type]["cast_column"]
    detail_spark_df = detail_spark_df.withColumn(cast_column, col(cast_column).cast(DecimalType(20, 2)))
    detail_final_df = add_audit_columns(detail_spark_df)
    uc.write(detail_final_df, dataset_cfg.scenario_table.raw_table, dataset_cfg.scenario_table.raw_ext_table_loc)

for file in files:  
    ingestor.archive(file, dataset_cfg.archive)
