# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EC Upper Bound ingestion started...")

# COMMAND ----------

dataset_key = "ec_upper_bound"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.file.{dataset_key}")

# COMMAND ----------

from rda.ingestion.file_ingestor import FileIngestor
ingestor = FileIngestor(env_config, spark, dbutils)

# COMMAND ----------

files = ingestor.list_and_filter_files(dataset_cfg.landing, dataset_cfg.file_pattern)

if not files:
    dbutils.notebook.exit(f"No new files found in {dataset_cfg.landing} matching pattern '{dataset_cfg.file_pattern}'")
else:
    logger.info(f"Found {str(files)} to process...")

# COMMAND ----------

def unpivot(df):
    tenors = df.columns
    del tenors[0]

    from pyspark.sql import functions as F
    expr = "stack({0}, {1}) as (tenor, upper_bound)".format( len(tenors), ", ".join([f"'{c}', `{c}`" for c in tenors]) ) 
    df = df.select("currency", F.expr(expr)).withColumn("tenor", F.col("tenor").cast("double"))
    return df

# COMMAND ----------

for file in files:
    df = ingestor.read(file, dataset_cfg)
    df = unpivot(df)
    df = ingestor.add_audit_columns(df, file.name)
    ingestor.write(df, dataset_cfg)
    ingestor.archive(file, dataset_cfg.archive)


# COMMAND ----------

logger.info("EC Upper Bound ingestion completed successfully")