# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pyspark.sql import functions as F
import calendar

import pandas as pd
import os
import sys
import re

from rda.utils.date_utils import get_quarter_end_date

from pyspark.sql.functions import last_day
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType

# COMMAND ----------

#Read config file sheet <Sheets> to be used to identify sheets that will be processed
pdf_sheets = read_excel(env_config.get("common.config_files.par_curve"), sheet_name='Sheets', header=0)
# display(pdf_sheets)

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.ear_par_curve.file_pattern")}' in '{env_config.get("ingest.file.ear_par_curve.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.ear_par_curve.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.ear_par_curve.file_pattern"))

print(f"Found {str(files_to_process)} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Currency_Code': pd.Series(dtype='str'),
    'Curve_Name': pd.Series(dtype='str'),
    'Tenor': pd.Series(dtype='int'),
    'ParCurveValue': pd.Series(dtype='float')    
}

tenors = [2, 5, 7, 10, 20, 30]

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:

    # Create the empty DataFrame
    pdf_output = pd.DataFrame(columns)

    #Call the function to extract the data
    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    for sheet_row in pdf_sheets.iterrows():
        print(sheet_row[1]['SheetName'])      
        try:
            pdf_source = pd.read_excel(bin_buffer, header=sheet_row[1]['RowHeader'], dtype=str, sheet_name=sheet_row[1]['SheetName'])
            pdf_source = pdf_source[pdf_source[pdf_source.columns[sheet_row[1]['CurveName_Child']]].str.contains('Public', na=False) |
                                            pdf_source[pdf_source.columns[sheet_row[1]['CurveName_Child']]].str.contains('Provincial_AAA', na=False) |
                                            pdf_source[pdf_source.columns[sheet_row[1]['CurveName']]].str.fullmatch('Govt')]
                    
            if(pdf_source[pdf_source.columns[sheet_row[1]['CurveName_Child']]].str.contains('Provincial_AAA').any()):
                    pdf_source = pdf_source[~pdf_source[pdf_source.columns[sheet_row[1]['CurveName_Child']]].str.contains('Public_AAA', na=False)]      
            
            for tenor in tenors:
                output_rows = pd.DataFrame(columns)

                output_rows['Curve_Name'] = pdf_source[pdf_source.columns[sheet_row[1]['CurveName']]]
                output_rows['Tenor'] = tenor
                output_rows['ParCurveValue'] = pdf_source[str(tenor)+'y'].astype('float')
                # output_rows['2y'] = pdf_source['y']
                # output_rows['5y'] = pdf_source['5y']
                # output_rows['7y'] = pdf_source['7y']
                # output_rows['10y'] = pdf_source['10y']
                # output_rows['20y'] = pdf_source['20y']
                # output_rows['30y'] = pdf_source['30y']
                output_rows['Currency_Code'] = sheet_row[1]['SheetName']

                pdf_output = pd.concat([pdf_output, output_rows], ignore_index=True) 
        except ValueError as e:
            print(f"Error reading file: {f.name} sheet: {sheet_row[1]['SheetName']}, Error: {e}")
            continue
        except Exception as e:
            print(f"An error occurred: {e}")
            continue
    
    print(len(pdf_output))
    pdf_output['Source_File'] = f.name

    #Add the date and key columns
    datetoday = datetime.now(ZoneInfo("UTC"))
    pdf_output['Ingestion_TS'] = datetoday

    #Extract reporting date from filename
    for d in re.findall(r'\d+', f.name):
        if(len(d) == 8):
            pdf_output['Reporting_Date'] = datetime.strptime(d, '%Y%m%d').strftime('%Y-%m-%d')

    if 'Reporting_Date' not in pdf_output.columns:
        match = re.search(r'(Q[1-4])\s(\d{4})', f.name)
        if match:            
            match match.group(1):                
                case 'Q1':
                    lastdayofmonth = match.group(2) + '-03-31'
                case 'Q2':
                    lastdayofmonth = match.group(2) + '-06-30'
                case 'Q3':
                    lastdayofmonth = match.group(2) + '-09-30'
                case 'Q4':
                    lastdayofmonth = match.group(2) + '-12-31'

            lastdayofmonth = datetime.strptime(lastdayofmonth, '%Y-%m-%d')

            while lastdayofmonth.weekday() >= 5:
                lastdayofmonth -= datetime.timedelta(days=1)

            pdf_output['Reporting_Date'] = lastdayofmonth.strftime('%Y-%m-%d')

    if 'Reporting_Date' not in pdf_output.columns:
        match = re.search(r'([A-Za-z]+)\s(\d{4})', f.name)
        if match:
            month_name = match.group(1)
            year = int(match.group(2))            
            month_num = datetime.strptime(month_name, '%B').month

            lastdayofmonth = datetime(year, month_num, calendar.monthrange(year, month_num)[1])

            while lastdayofmonth.weekday() >= 5:
                lastdayofmonth -= timedelta(days=1)
            
            pdf_output['Reporting_Date'] = lastdayofmonth.strftime('%Y-%m-%d')

    if 'Reporting_Date' not in pdf_output.columns:
        raise Exception(f"Date not found in for file \"{f.name}\"")

    datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
    print(datetimestamp)

    df_run = spark.createDataFrame(data=[('Par Curve', f.name, datetoday, None, None, None)], 
                                   schema=StructType([StructField("Process_Name", StringType(), True),
                                                StructField("Source_File", StringType(), True),
                                                StructField("Ingestion_TS", TimestampType(), True),
                                                StructField("Curation_TS", TimestampType(), True),
                                                StructField("Consumption_TS", TimestampType(), True),
                                                StructField("Consumption_Remarks", StringType(), True)]))    

    if(len(pdf_output) > 0):               
        spark.createDataFrame(pdf_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.ear_par_curve.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.ear_par_curve.raw_table"))

        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    ext = f.name[f.name.rindex("."):]
    parcurve_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.ear_par_curve.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{parcurve_archive_file}")