# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("ST B1 Country currency mapping loading started...")

# COMMAND ----------

dataset_key = "b1_Country_Currency_Mapping"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.file.{dataset_key}")

# COMMAND ----------

from rda.ingestion.file_ingestor import FileIngestor
ingestor = FileIngestor(env_config, spark, dbutils)

# COMMAND ----------

files = ingestor.list_and_filter_files(dataset_cfg.landing, dataset_cfg.file_pattern)

if not files:
    dbutils.notebook.exit(f"No new files found in {dataset_cfg.landing} matching pattern '{dataset_cfg.file_pattern}'")
else:
    logger.info(f"Found {str(files)} to process...")

# COMMAND ----------

import pandas as pd
pdf = pd.DataFrame()

for file in files:
    for sheet in dataset_cfg.sheets.keys():
        pdf_temp = ingestor.read_excel(file, dataset_cfg.sheets.get(sheet))
        cols = ["THREE_LETTER_COUNTRY_CODE", "TWO_LETTER_COUNTRY_CODE", "CURRENCY_CODE"]
        for col in cols:
            pdf_temp[col] = pdf_temp[col].str.replace(r"[^A-Z]", "", regex=True)

        note_index = pdf_temp[pdf_temp.COUNTRY.astype(str).str.startswith("Note:")].index
        pdf_temp = pdf_temp.iloc[:note_index[0]]
        
        if pdf.empty:
            pdf = pdf_temp
        else:
            pdf = pd.concat([pdf, pdf_temp], ignore_index=True)

    df = spark.createDataFrame(pdf)
    df = ingestor.add_audit_columns(df, file.name)
    ingestor.write(df, dataset_cfg)
    ingestor.archive(file, dataset_cfg.archive)

# COMMAND ----------

logger.info("ST B1 Country currency mapping completed successfully")