# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

import warnings
warnings.filterwarnings("ignore") 

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import numpy as np
import re

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType, DecimalType

from rda.utils.date_utils import get_previous_quarter_end_date

# COMMAND ----------

#Read config file sheet <ColumnIndex> to be used for the coordinates of data to be extracted
pdf_columnindex = read_excel(env_config.get("common.config_files.gam"), sheet_name='ColumnIndex', header=0)
# display(pdf_columnindex)

#Read config file sheet <Sheets> to be used to identify sheets that will be processed
pdf_sheets = read_excel(env_config.get("common.config_files.gam"), sheet_name='Sheets', header=0)
# display(pdf_sheets)

#Read config file sheet <MLRL> to be used to identify sheets that will be processed
pdf_mlrl = read_excel(env_config.get("common.config_files.gam"), sheet_name='MLRL', header=0)
# display(pdf_mlrl)

#Read config file sheet <DB Pension> to be used to identify sheets that will be processed
pdf_dbpension = read_excel(env_config.get("common.config_files.gam"), sheet_name='DBPension', header=0)
# display(pdf_dbpension)

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.gam_sensitivities.file_pattern")}' in '{env_config.get("ingest.file.gam_sensitivities.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.gam_sensitivities.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.gam_sensitivities.file_pattern"))
files_to_process = sorted(files_to_process, key=lambda x: x.path)

print(f"Found {[file.name for file in files_to_process]} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Tax_Indicator_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Balance_Sheet_Component_Name': pd.Series(dtype='str'),
    'IFRS_Earnings_Component_Name': pd.Series(dtype='str'),
    'Scenario_Name': pd.Series(dtype='str'),
    'Currency_Name': pd.Series(dtype='str'),
    'Par_Status_Name': pd.Series(dtype='str'),
    'Amount': pd.Series(dtype='float'),
    'HKUnsplit': pd.Series(dtype='boolean')
}

mlrl_columns = {
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'MLRL_Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Balance_Sheet_Component_Name': pd.Series(dtype='str'),
    'HK_Allocation_Percentage': pd.Series(dtype='float'),
    'MLRL_Allocation_Percentage': pd.Series(dtype='float')
}

dbpension_columns = {
    'Tax_Indicator_Name': pd.Series(dtype='str'),
    'Currency_Name': pd.Series(dtype='str'),
    'Impact_Type': pd.Series(dtype='str'),
    'Estimated_Impacts_Amount': pd.Series(dtype='float'),
    'Scenario_Name': pd.Series(dtype='str'),
    'Comment': pd.Series(dtype='str')
}

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:

    processname = 'Consolidated Sensitivities Results '

    # Create the empty DataFrame
    pdf_output = pd.DataFrame(columns)
    pdf_mlrl_output = pd.DataFrame(mlrl_columns)
    pdf_dbpension_output = pd.DataFrame(dbpension_columns)

    #Call the function to extract the data
    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    for sheet_row in pdf_sheets.iterrows():
        print(f"Processing file: {f.name} sheet: {sheet_row[1]['SheetName']}")
        try:
            pdf_source = pd.read_excel(bin_buffer, engine='pyxlsb', header=None, dtype=str, sheet_name=sheet_row[1]['SheetName'])
            if(sheet_row[1]['ProcessType'] == 'MLRL'):
                pdf_source = pdf_source[3:]
                # display(pdf_source)
                for mlrl_row in pdf_mlrl.iterrows():
                    mlrl_output_row = pd.DataFrame()
                    mlrl_output_row['Lowest_Level_Portfolio_Name'] = pdf_source[sheet_row[1]['LLP']]
                    mlrl_output_row['MLRL_Lowest_Level_Portfolio_Name'] = mlrl_row[1]['MLRL_LLP']
                    mlrl_output_row['Balance_Sheet_Component_Name'] = mlrl_row[1]['Balance Sheet Component']
                    mlrl_output_row['HK_Allocation_Percentage'] = pdf_source[mlrl_row[1]['HK_Allocation_Percentage']].astype(float)
                    mlrl_output_row['MLRL_Allocation_Percentage'] = pdf_source[mlrl_row[1]['MLRL_Allocation_Percentage']].astype(float)

                    pdf_mlrl_output = pd.concat([pdf_mlrl_output, mlrl_output_row], ignore_index=True)

                continue

                # display(pdf_mlrl_output)
            
            if(sheet_row[1]['ProcessType'] == 'DBPension'):
                pdf_source = pdf_source[5:]
                # display(pdf_source)
                for dbpension_row in pdf_dbpension.iterrows():
                    dbpension_output_row = pd.DataFrame()
                    dbpension_output_row['Estimated_Impacts_Amount'] = pdf_source[dbpension_row[1]['EstImpactsAmount']]
                    dbpension_output_row['Scenario_Name'] = pdf_source[sheet_row[1]['Scenario']]
                    dbpension_output_row['Tax_Indicator_Name'] = dbpension_row[1]['TaxIndicator']
                    dbpension_output_row['Currency_Name'] = sheet_row[1]['Currency']
                    dbpension_output_row['Impact_Type'] = dbpension_row[1]['ImpactType']
                    if(dbpension_row[1]['Comment'] is not None):
                        dbpension_output_row['Comment'] = pdf_source[dbpension_row[1]['Comment']]

                    pdf_dbpension_output = pd.concat([pdf_dbpension_output, dbpension_output_row], ignore_index=True)
                
                continue

            else:
                pdf_columns = pdf_columnindex[pdf_columnindex['ProcessType'] == sheet_row[1]['ProcessType']]
                if(len(pdf_columns) == 0): break
                
                if(sheet_row[1]['ProcessType'] == 'GAMFile'):
                    pdf_source = pdf_source[(pdf_source[0].notnull()) & 
                                            (pdf_source[1].notnull()) &
                                            (pdf_source[sheet_row[1]['Scenario']] != '0') &
                                            (pdf_source[sheet_row[1]['LLP']] != '0') &
                                            (pdf_source[sheet_row[1]['LLP']] != 'nan') &
                                            (pdf_source[sheet_row[1]['LLP']] != 'not req') &
                                            (pdf_source[sheet_row[1]['LLP']].notnull())]
                else:
                    pdf_source = pdf_source[(pdf_source[1].notnull()) &
                                            (pdf_source[sheet_row[1]['Scenario']] != '0') &
                                            (pdf_source[sheet_row[1]['LLP']] != '0') &
                                            (pdf_source[sheet_row[1]['LLP']] != 'nan') &
                                            (pdf_source[sheet_row[1]['LLP']] != 'not req') &
                                            (pdf_source[sheet_row[1]['LLP']].notnull())]

                # display(pdf_source)

                for columnindex_row in pdf_columns.iterrows():
                    output_row = pd.DataFrame()
                    if columnindex_row[1]['ScenarioAmount'] > 0:                
                        output_row['Lowest_Level_Portfolio_Name'] = pdf_source[sheet_row[1]['LLP']]
                        output_row['Balance_Sheet_Component_Name'] = columnindex_row[1]['BalanceSheetComponent']
                        output_row['IFRS_Earnings_Component_Name'] = columnindex_row[1]['IFRSEarningsComponent']
                        output_row['Scenario_Name'] = pdf_source[sheet_row[1]['Scenario']]
                        output_row['Currency_Name'] = sheet_row[1]['Currency']
                        if(sheet_row[1]['ParStatus']==None):
                            output_row['Par_Status_Name'] = sheet_row[1]['ParStatusFixed']
                        else:
                            output_row['Par_Status_Name'] = pdf_source[sheet_row[1]['ParStatus']]
                        pdf_source[columnindex_row[1]['ScenarioAmount']] = pd.to_numeric(pdf_source[columnindex_row[1]['ScenarioAmount']], errors='coerce')
                        output_row['Amount'] = pdf_source[columnindex_row[1]['ScenarioAmount']].astype(float)
                        output_row['Country_Name'] = sheet_row[1]['Country']
                        output_row['Tax_Indicator_Name'] = columnindex_row[1]['TaxIndicator']
                        output_row['HKUnsplit'] = sheet_row[1]['HKUnsplit']
                        
                        pdf_output = pd.concat([pdf_output, output_row], ignore_index=True)

        except ValueError as e:
            print(f"Error reading file: {f.name} sheet: {sheet_row[1]['SheetName']}, Error: {e}")
            continue
        except Exception as e:
            print(f"An error occurred: {e}")
            continue

    print(len(pdf_output))
    pdf_output['Source_File'] = f.name
    pdf_mlrl_output['Source_File'] = f.name
    pdf_dbpension_output['Source_File'] = f.name

    if("PART1" in f.name.upper().replace(' ', '')): 
        processname += 'Part 1'
    elif("PART2" in f.name.upper().replace(' ', '')):
        processname += 'Part 2'

    #Add the date and key columns
    datetoday = datetime.now(ZoneInfo("UTC"))
    pdf_output['Ingestion_TS'] = datetoday
    pdf_mlrl_output['Ingestion_TS'] = datetoday
    pdf_dbpension_output['Ingestion_TS'] = datetoday

    #Extract reporting date from filename
    for d in re.findall(r'\d+', f.name):
        if(len(d) == 8):
            datepart = datetime.strptime(d, '%Y%m%d')

    pdf_output['Reporting_Date'] = get_previous_quarter_end_date(datepart).strftime('%Y-%m-%d')
    pdf_mlrl_output['Reporting_Date'] = get_previous_quarter_end_date(datepart).strftime('%Y-%m-%d')
    pdf_dbpension_output['Reporting_Date'] = get_previous_quarter_end_date(datepart).strftime('%Y-%m-%d')

    pdf_output_with_scenario = pdf_output[pdf_output['Tax_Indicator_Name'].notna()]
    pdf_output_without_scenario = pdf_output[pdf_output['Tax_Indicator_Name'].isna()]
    pdf_output_without_scenario.drop(['Scenario_Name', 'Tax_Indicator_Name'], inplace=True, axis=1)
    pdf_output_without_scenario.drop_duplicates(inplace=True)

    datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
    print(datetimestamp)

    df_run = spark.createDataFrame(data=[(processname, f.name, datetoday, None, None, None)], 
                                   schema=StructType([StructField("Process_Name", StringType(), True),
                                                StructField("Source_File", StringType(), True),
                                                StructField("Ingestion_TS", TimestampType(), True),
                                                StructField("Curation_TS", TimestampType(), True),
                                                StructField("Consumption_TS", TimestampType(), True),
                                                StructField("Consumption_Remarks", StringType(), True)]))

    if(len(pdf_output_with_scenario) > 0 or len(pdf_mlrl_output) > 0 or len(pdf_dbpension_output) > 0):
        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    if(len(pdf_output_with_scenario) > 0): 
        spark.createDataFrame(pdf_output_with_scenario) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.gam_sensitivities.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.gam_sensitivities.raw_table"))
        
        spark.createDataFrame(pdf_output_without_scenario) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("mergeSchema", "true") \
            .option("path", env_config.get("ingest.file.gam_sensitivities.raw_ext_table_loc_without_scenario")) \
            .saveAsTable(env_config.get("ingest.file.gam_sensitivities.raw_table_without_scenario"))

    if(len(pdf_mlrl_output) > 0):
        spark.createDataFrame(pdf_mlrl_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.gam_sensitivities.raw_ext_table_mlrl_loc")) \
            .saveAsTable(env_config.get("ingest.file.gam_sensitivities.raw_table_mlrl"))

    if(len(pdf_dbpension_output) > 0):        
        spark.createDataFrame(pdf_dbpension_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.gam_sensitivities.raw_ext_table_dbpension_loc")) \
            .saveAsTable(env_config.get("ingest.file.gam_sensitivities.raw_table_dbpension"))
        

    ext = f.name[f.name.rindex("."):]
    gam_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.gam_sensitivities.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{gam_archive_file}")
     