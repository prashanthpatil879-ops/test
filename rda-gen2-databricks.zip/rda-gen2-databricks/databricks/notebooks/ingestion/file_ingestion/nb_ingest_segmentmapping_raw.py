# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import os
import sys
import re

from rda.utils.date_utils import get_quarter_end_date

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType

# COMMAND ----------

#Read config file sheet <Sheets> to be used to identify sheets that will be processed
pdf_sheets = read_excel(env_config.get("common.config_files.segment_mapping"), sheet_name='Sheets', header=0)
# display(pdf_sheets)

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.gam_segmentmapping.file_pattern")}' in '{env_config.get("ingest.file.gam_segmentmapping.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.gam_segmentmapping.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.gam_segmentmapping.file_pattern"))

print(f"Found {str(files_to_process)} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Tam_Segment_Name': pd.Series(dtype='str'),
    'Asset_Segment_Name': pd.Series(dtype='str'),
    'Liability_Segment_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Product_Type_Name': pd.Series(dtype='str'),
    'Par_Status_Name': pd.Series(dtype='str'),
    'Tax_Rate': pd.Series(dtype='str'),
    'Minority_Interest': pd.Series(dtype='int'),
    'GMT': pd.Series(dtype='str')
}

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:    

    # Create the empty DataFrame
    pdf_output = pd.DataFrame(columns)

    #Call the function to extract the data
    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    for sheet_row in pdf_sheets.iterrows():        
                
        pdf_source = pd.read_excel(bin_buffer, header=0, dtype=str, sheet_name=sheet_row[1]['SheetName'])
        
        pdf_output['Country_Name'] = pdf_source['Country']
        pdf_output['Tam_Segment_Name'] = pdf_source['Tam Segment Name']
        pdf_output['Asset_Segment_Name'] = pdf_source['Assets Segment Name']
        pdf_output['Liability_Segment_Name'] = pdf_source['Liabilities Segment Name']
        pdf_output['Lowest_Level_Portfolio_Name'] = pdf_source['Consol Segment Name']
        pdf_output['Product_Type_Name'] = pdf_source['Product Type']
        pdf_output['Par_Status_Name'] = pdf_source['Par Status']
        pdf_output['Tax_Rate'] = pdf_source['Tax Rate']
        pdf_output['Minority_Interest'] = pdf_source['Minority Interest']
        pdf_output['GMT'] = pdf_source['GMT']

    print(len(pdf_output))
    pdf_output['Source_File'] = f.name

    #Add the date and key columns
    datetoday = datetime.now(ZoneInfo("UTC"))
    pdf_output['Ingestion_TS'] = datetoday

    #Extract reporting date from filename
    # datepart = fi.path[len(fi.path)-13:len(fi.path)-5]
    # datepart = datetime.strptime(datepart, '%Y%m%d')
    quarter = re.search(r"\d{2}Q[1-4]", f.name)
    pdf_output['Reporting_Date'] = get_quarter_end_date(quarter.group(0)).strftime('%Y-%m-%d') if quarter else None 

    datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
    print(datetimestamp)

    df_run = spark.createDataFrame(data=[('Consolidated Sensitivities Segment Mapping', f.name, datetoday, None, None, None)], 
                                   schema=StructType([StructField("Process_Name", StringType(), True),
                                                StructField("Source_File", StringType(), True),
                                                StructField("Ingestion_TS", TimestampType(), True),
                                                StructField("Curation_TS", TimestampType(), True),
                                                StructField("Consumption_TS", TimestampType(), True),
                                                StructField("Consumption_Remarks", StringType(), True)]))    

    if(len(pdf_output) > 0):               
        df_output = spark.createDataFrame(pdf_output)

        df_output = df_output.withColumn("Product_Type_Name", col("Product_Type_Name").cast(StringType()))
        df_output = df_output.withColumn("Par_Status_Name", col("Par_Status_Name").cast(StringType()))
        
        df_output.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.gam_segmentmapping.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.gam_segmentmapping.raw_table"))

        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    ext = f.name[f.name.rindex("."):]
    segmentmapping_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.gam_segmentmapping.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{segmentmapping_archive_file}")