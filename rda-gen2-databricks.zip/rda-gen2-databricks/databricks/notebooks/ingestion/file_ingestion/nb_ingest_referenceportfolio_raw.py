# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import re

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.ear_reference_portfolio.file_pattern")}' in '{env_config.get("ingest.file.ear_reference_portfolio.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.ear_reference_portfolio.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.ear_reference_portfolio.file_pattern"))

print(f"Found {str(files_to_process)} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Liability_Segment_Name': pd.Series(dtype='str'),
    'Currency_Code': pd.Series(dtype='str'),
    'Curve_Name': pd.Series(dtype='str'),
    'Tenor': pd.Series(dtype='str'),
    'RefPortValue': pd.Series(dtype='float')
}

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:

    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    pdf_output = pd.DataFrame(columns)

    pdf_inventory = pd.read_excel(bin_buffer, header=4, dtype=str, sheet_name='Inventory')
    pdf_inventory = pdf_inventory[['Segment List', 'Liability Currency']].dropna()

    # display(pdf_inventory)

    for inventory_row in pdf_inventory.iterrows():
        pdf_source = pd.read_excel(bin_buffer, header=None, dtype=str, sheet_name=inventory_row[1]['Segment List'])
        #display(pdf_source)

        # print(pdf_source[0][2:])

        for source_col in pdf_source.columns:
            output_rows = pd.DataFrame(columns)
            if(pdf_source[source_col][0] == inventory_row[1]['Liability Currency'] and not pd.isna(pdf_source[source_col][1]) and pdf_source[source_col][1] != ""):
                output_rows['Tenor'] = pdf_source[0][2:]
                output_rows['RefPortValue'] = pdf_source[source_col][2:].astype('float')
                output_rows['Currency_Code'] = pdf_source[source_col][0]
                output_rows['Curve_Name'] = pdf_source[source_col][1]
                output_rows['Liability_Segment_Name'] = inventory_row[1]['Segment List']

                pdf_output = pd.concat([pdf_output, output_rows], ignore_index=True)

    print(len(pdf_output))

    if(len(pdf_output) > 0):
        pdf_output['Source_File'] = f.name

        #Add the date and key columns
        datetoday = datetime.now(ZoneInfo("UTC"))
        pdf_output['Ingestion_TS'] = datetoday

        #Extract reporting date from filename
        for d in re.findall(r'\d+', f.name):
            if(len(d) == 8):
                pdf_output['Reporting_Date'] = datetime.strptime(d, '%Y%m%d').strftime('%Y-%m-%d')

        # display(pdf_output)

        datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
        print(datetimestamp)

        df_run = spark.createDataFrame(data=[('Reference Portfolio', f.name, datetoday, None, None, None)], 
                                    schema=StructType([StructField("Process_Name", StringType(), True),
                                                    StructField("Source_File", StringType(), True),
                                                    StructField("Ingestion_TS", TimestampType(), True),
                                                    StructField("Curation_TS", TimestampType(), True),
                                                    StructField("Consumption_TS", TimestampType(), True),
                                                    StructField("Consumption_Remarks", StringType(), True)]))
        
        spark.createDataFrame(pdf_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.ear_reference_portfolio.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.ear_reference_portfolio.raw_table"))

        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    ext = f.name[f.name.rindex("."):]
    parcurve_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.ear_reference_portfolio.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{parcurve_archive_file}")