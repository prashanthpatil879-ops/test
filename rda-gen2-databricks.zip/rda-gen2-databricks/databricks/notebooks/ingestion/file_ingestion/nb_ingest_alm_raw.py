# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import re

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType

# COMMAND ----------

#Read config file sheet <ColumnIndex> to be used for the coordinates of data to be extracted
pdf_columnindex = read_excel(env_config.get("common.config_files.alm"), sheet_name='ColumnIndex', header=0)
# display(pdf_columnindex)

#Read config file sheet <Sheets> to be used to identify sheets that will be processed
pdf_sheets = read_excel(env_config.get("common.config_files.alm"), sheet_name='Sheets', header=0)
# display(pdf_sheets)

#Read config file sheet <NetCountries> to be used to identify sheets that will be processed
pdf_netcountries = read_excel(env_config.get("common.config_files.alm"), sheet_name='NetCountries', header=0)
# display(pdf_netcountries)

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.alm.file_pattern")}' in '{env_config.get("ingest.file.alm.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.alm.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.alm.file_pattern"))

print(f"Found {str(files_to_process)} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Tax_Indicator_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Balance_Sheet_Component_Name': pd.Series(dtype='str'),
    'IFRS_Earnings_Component_Name': pd.Series(dtype='str'),
    'Scenario_Name': pd.Series(dtype='str'),
    'Currency_Name': pd.Series(dtype='str'),
    'Amount': pd.Series(dtype='float')
}

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:  

    # Create the empty DataFrame
    pdf_output = pd.DataFrame(columns)

    #Call the function to extract the data
    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    for sheet_row in pdf_sheets.iterrows():        
        
        if(len(pdf_columnindex) == 0): break

        pdf_columns = pdf_columnindex[pdf_columnindex['ProcessType'] == sheet_row[1]['ProcessType']]
        
        pdf_source = pd.read_excel(bin_buffer, header=None, dtype=str, sheet_name=sheet_row[1]['SheetName'])
        print(sheet_row[1]['SheetName'] + str(datetime.now(ZoneInfo("UTC"))))        

        # display(pdf_source)

        for columnindex_row in pdf_columns.iterrows():
            # print(columnindex_row)
            NetCtr = 1
            if sheet_row[1]['ProcessType'] == 'Net':
                # display(pdf_source)
                for source_row in pdf_source.iloc[9:].iterrows():                    
                    if str(source_row[1][sheet_row[1]['LLP']]) != 'nan' :
                        if str(source_row[1][sheet_row[1]['LLP']]) == 'VA':
                            break
                        
                        if len(pdf_netcountries[(pdf_netcountries["Country"] == source_row[1][sheet_row[1]['Country']])])>0:
                            netcountry = source_row[1][sheet_row[1]['Country']]
                        else:
                            output_row = [netcountry, 
                                          columnindex_row[1]['TaxIndicator'],
                                          source_row[1][sheet_row[1]['LLP']],
                                          columnindex_row[1]['BalanceSheetComponent'],
                                          columnindex_row[1]['IFRSEarningsComponent'],
                                          sheet_row[1]['Scenario'],
                                          sheet_row[1]['Currency'],
                                          float(source_row[1][columnindex_row[1]['ScenarioAmount']])]
                            
                            pdf_output = pd.concat([pdf_output, pd.DataFrame([output_row], columns=['Country_Name', 'Tax_Indicator_Name', 'Lowest_Level_Portfolio_Name', 'Balance_Sheet_Component_Name', 'IFRS_Earnings_Component_Name', 'Scenario_Name', 'Currency_Name', 'Amount'])], ignore_index=True)                   

            else:
                pdf_source = pdf_source[(pdf_source[0].notnull() & pdf_source[3].notnull()) & (pdf_source[0] != 'Division')]
                
                pdf_output_row = pd.DataFrame()
                pdf_output_row['Country_Name'] = pdf_source[sheet_row[1]['Country']]
                pdf_output_row['Tax_Indicator_Name'] = columnindex_row[1]['TaxIndicator']
                pdf_output_row['Lowest_Level_Portfolio_Name'] = pdf_source[sheet_row[1]['LLP']]
                pdf_output_row['Balance_Sheet_Component_Name'] = columnindex_row[1]['BalanceSheetComponent']
                pdf_output_row['IFRS_Earnings_Component_Name'] = columnindex_row[1]['IFRSEarningsComponent']
                pdf_output_row['Scenario_Name'] = sheet_row[1]['Scenario']
                pdf_output_row['Currency_Name'] = sheet_row[1]['Currency']
                pdf_output_row['Amount'] = pdf_source[columnindex_row[1]['ScenarioAmount']].astype(float)
                pdf_output = pd.concat([pdf_output, pdf_output_row], ignore_index=True)

    print(len(pdf_output))
    pdf_output['Source_File'] = f.name

    #Add the date and key columns
    datetoday = datetime.now(ZoneInfo("UTC"))
    pdf_output['Ingestion_TS'] = datetoday

    #Extract reporting date from filename
    for d in re.findall(r'\d+', f.name):
        if(len(d) == 8):
            pdf_output['Forecast_Date'] = datetime.strptime(d, '%Y%m%d').strftime('%Y-%m-%d')

    datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
    print(datetimestamp)
    
    df_run = spark.createDataFrame(data=[('ALM Sensitivities Forecast', f.name, datetoday, None, None, None)], 
                                schema=StructType([StructField("Process_Name", StringType(), True),
                                            StructField("Source_File", StringType(), True),
                                            StructField("Ingestion_TS", TimestampType(), True),
                                            StructField("Curation_TS", TimestampType(), True),
                                            StructField("Consumption_TS", TimestampType(), True),
                                            StructField("Consumption_Remarks", StringType(), True)]))

    if(len(pdf_output) > 0):               
        spark.createDataFrame(pdf_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.alm.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.alm.raw_table"))

        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    ext = f.name[f.name.rindex("."):]
    alm_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.alm.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{alm_archive_file}")