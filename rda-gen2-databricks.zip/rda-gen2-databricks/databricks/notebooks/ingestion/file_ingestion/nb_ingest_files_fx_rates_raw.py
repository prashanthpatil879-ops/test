# Databricks notebook source
# MAGIC %md
# MAGIC ### Notebook to load FX rates from File

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("FX Rates ingestion started...") 

# COMMAND ----------

dataset_key = "fx"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.file.{dataset_key}")

# COMMAND ----------

from rda.ingestion.file_ingestor import FileIngestor
ingestor = FileIngestor(env_config, spark, dbutils)

# COMMAND ----------

files = ingestor.list_and_filter_files(dataset_cfg.landing, dataset_cfg.file_pattern)

if not files:
    dbutils.notebook.exit(f"No new files found in {dataset_cfg.landing} matching pattern '{dataset_cfg.file_pattern}'")
else:
    logger.info(f"Found {str(files)} to process...")

# COMMAND ----------

for file in files:
    df = ingestor.read(file, dataset_cfg)
    df = ingestor.add_audit_columns(df, file.name)
    ingestor.write(df, dataset_cfg)
    ingestor.archive(file, dataset_cfg.archive)


# COMMAND ----------

logger.info("FX Rates ingestion completed successfully") 