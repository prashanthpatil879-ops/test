# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

dataset_key = "swap_spread_interest_rate_ec"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.file.{dataset_key}")

# COMMAND ----------

import re
from pyspark.sql import DataFrame, functions as F
import pandas as pd
from rda.utils.date_utils import get_quarter_end_date
from rda.ingestion.file_ingestor import FileIngestor
ingestor = FileIngestor(env_config, spark, dbutils)

# COMMAND ----------

files = ingestor.list_and_filter_files(dataset_cfg.landing, dataset_cfg.file_pattern)

if not files:
    dbutils.notebook.exit(f"No new files found in {dataset_cfg.landing} matching pattern '{dataset_cfg.file_pattern}'")
else:
    print(f"Found {str(files)} to process...") 

# COMMAND ----------

def process_data(pdf_temp, pdf, dataset_cfg):

    pdf_temp = pdf_temp.dropna(how="all")
    d_header = pdf_temp.columns[0]

    pdf_temp = pdf_temp[pdf_temp[d_header].notna()]
    pdf_temp = pdf_temp[pdf_temp[d_header].astype(str).str.strip() != ""]
    pdf_temp[d_header] = (pdf_temp[d_header].astype(str).str.replace(r"\s+", " ", regex=True).str.strip())

    pdf_temp = pdf_temp[
        ~(
            pdf_temp[d_header].isin(dataset_cfg.exclude_values)
            | pdf_temp[d_header].str.contains(r"^Total\s", case=False, na=False)
            | pdf_temp[d_header].str.contains("Diversifi", case=False, na=False)
            | pdf_temp[d_header].str.contains("Current Quarter EC", case=False, na=False)
        )
    ]

    pdf = pd.concat([pdf, pdf_temp], ignore_index=True)

    return pdf

# COMMAND ----------

pdf = pd.DataFrame()

for file in files:
    for sheet in dataset_cfg.sheets.keys():
        sheet_cfg = dataset_cfg.sheets.get(sheet)
        pdf_temp = ingestor.read_excel(file, sheet_cfg)
        pdf = process_data(pdf_temp, pdf, dataset_cfg)
    df = spark.createDataFrame(pdf)
    quarter = get_quarter_end_date(file.name.replace(".xlsm", "").split()[-1])
    df = df.withColumn("REPORTING_DATE", F.lit(quarter).cast("date"))
    df = ingestor.add_audit_columns(df, file.name)
    ingestor.write(df, dataset_cfg)
    ingestor.archive(file, dataset_cfg.archive)