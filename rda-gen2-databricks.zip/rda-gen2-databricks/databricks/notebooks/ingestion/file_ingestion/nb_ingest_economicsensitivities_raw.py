# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

# dbutils.library.restartPython()

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from io import BytesIO
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import numpy as np
import re

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType, DecimalType

from rda.utils.date_utils import get_previous_quarter_end_date

# COMMAND ----------

#Read config file sheet <ColumnIndex> to be used for the coordinates of data to be extracted
pdf_columnindex = read_excel(env_config.get("common.config_files.economicsensitivities"), sheet_name='ColumnIndex', header=0)
# display(pdf_columnindex)

#Read config file sheet <Sheets> to be used to identify sheets that will be processed
pdf_sheets = read_excel(env_config.get("common.config_files.economicsensitivities"), sheet_name='Sheets', header=0)
# display(pdf_sheets)

# COMMAND ----------

print(f"Looking for files of Pattern '{env_config.get("ingest.file.economicsensitivities.file_pattern")}' in '{env_config.get("ingest.file.economicsensitivities.landing")}'")

files = dbutils.fs.ls(env_config.get("ingest.file.economicsensitivities.landing"))

from rda.utils.file_util import *

files_to_process = filter_files(files, env_config.get("ingest.file.economicsensitivities.file_pattern"))
files_to_process = sorted(files_to_process, key=lambda x: x.path)

print(f"Found {[file.name for file in files_to_process]} to process")

# COMMAND ----------

# Define the columns and their desired data types
columns = {
    'Country_Name': pd.Series(dtype='str'),
    'Tax_Indicator_Name': pd.Series(dtype='str'),
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Balance_Sheet_Component_Name': pd.Series(dtype='str'),
    'IFRS_Earnings_Component_Name': pd.Series(dtype='str'),
    'Scenario_Name': pd.Series(dtype='str'),
    'Currency_Name': pd.Series(dtype='str'),
    'Amount': pd.Series(dtype='float')
}

# COMMAND ----------

#Loop through files found for processing

for f in files_to_process:

    processname = 'Economic Sensitivities '

    # Create the empty DataFrame
    pdf_output = pd.DataFrame(columns)

    #Call the function to extract the data
    bin_buffer = BytesIO(spark.read.format('binaryFile').load(f.path).limit(1).collect()[0]['content'])

    for sheet_row in pdf_sheets.iterrows():        
        print(f"Processing file: {f.name} sheet: {sheet_row[1]['SheetName']}")
        pdf_columns = pdf_columnindex[pdf_columnindex['ProcessType'] == sheet_row[1]['ProcessType']]
        if(len(pdf_columns) == 0): break
        try:
            pdf_source = pd.read_excel(bin_buffer, engine='pyxlsb', header=None, dtype=str, sheet_name=sheet_row[1]['SheetName'])
            # pdf_source = pdf_source[((pdf_source[0] == 'Wave 1') | (pdf_source[0] == 'Wave 2')) & (pdf_source[sheet_row[1]['LLP']] != '0') & (pdf_source[sheet_row[1]['LLP']] != 'nan')]

            pdf_source = pdf_source[(pdf_source[0].notnull()) & 
                                    (pdf_source[1].notnull()) &
                                    (pdf_source[sheet_row[1]['Scenario']] != '0') &
                                    (pdf_source[sheet_row[1]['LLP']] != '0') &
                                    (pdf_source[sheet_row[1]['LLP']] != 'nan') &
                                    (pdf_source[sheet_row[1]['LLP']] != 'not req') &
                                    (pdf_source[sheet_row[1]['LLP']].notnull())]

            # display(pdf_source)

            for columnindex_row in pdf_columns.iterrows():
                output_row = pd.DataFrame()
                if columnindex_row[1]['ScenarioAmount'] > 0:                
                    output_row['Lowest_Level_Portfolio_Name'] = pdf_source[sheet_row[1]['LLP']]
                    output_row['Balance_Sheet_Component_Name'] = columnindex_row[1]['BalanceSheetComponent']
                    output_row['IFRS_Earnings_Component_Name'] = columnindex_row[1]['IFRSEarningsComponent']
                    output_row['Scenario_Name'] = pdf_source[sheet_row[1]['Scenario']]
                    output_row['Currency_Name'] = sheet_row[1]['Currency']
                    pdf_source[columnindex_row[1]['ScenarioAmount']] = pd.to_numeric(pdf_source[columnindex_row[1]['ScenarioAmount']], errors='coerce')
                    output_row['Amount'] = pdf_source[columnindex_row[1]['ScenarioAmount']].astype(float)
                    output_row['Country_Name'] = sheet_row[1]['Country']
                    output_row['Tax_Indicator_Name'] = columnindex_row[1]['TaxIndicator']
                    
                    pdf_output = pd.concat([pdf_output, output_row], ignore_index=True)
        except ValueError as e:
            print(f"Error reading file: {f.name} sheet: {sheet_row[1]['SheetName']}, Error: {e}")
            continue
        except Exception as e:
            print(f"An error occurred: {e}")
            continue

    print(len(pdf_output))
    pdf_output['Source_File'] = f.name

    if("PART1" in f.name.upper().replace(' ', '')): 
        processname += 'Part 1'
    elif("PART2" in f.name.upper().replace(' ', '')):
        processname += 'Part 2'

    #Add the date and key columns
    datetoday = datetime.now(ZoneInfo("UTC"))
    pdf_output['Ingestion_TS'] = datetoday

    #Extract reporting date from filename
    for d in re.findall(r'\d+', f.name):
        if(len(d) == 8):
            datepart = datetime.strptime(d, '%Y%m%d')

    pdf_output['Reporting_Date'] = get_previous_quarter_end_date(datepart).strftime('%Y-%m-%d')

    datetimestamp = datetoday.strftime("%Y%m%d%H%M%S")
    print(datetimestamp)

    df_run = spark.createDataFrame(data=[(processname, f.name, datetoday, None, None, None)], 
                                   schema=StructType([StructField("Process_Name", StringType(), True),
                                                StructField("Source_File", StringType(), True),
                                                StructField("Ingestion_TS", TimestampType(), True),
                                                StructField("Curation_TS", TimestampType(), True),
                                                StructField("Consumption_TS", TimestampType(), True),
                                                StructField("Consumption_Remarks", StringType(), True)]))
    
    # display(df_run)    
    # display(pdf_output)

    if(len(pdf_output) > 0): 
        spark.createDataFrame(pdf_output) \
            .write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("ingest.file.economicsensitivities.raw_ext_table_loc")) \
            .saveAsTable(env_config.get("ingest.file.economicsensitivities.raw_table"))

        df_run.write \
            .mode("append") \
            .format("delta") \
            .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
            .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))

    ext = f.name[f.name.rindex("."):]
    gam_archive_file = f.name.replace(f"{ext}", f"_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}")
    archive_path = env_config.get('ingest.file.economicsensitivities.archive').replace("YYYYMMDD", datetime.now().strftime('%Y%m%d'))

    dbutils.fs.mkdirs(f"{archive_path}")
    dbutils.fs.mv(f.path, f"{archive_path}/{gam_archive_file}")
     