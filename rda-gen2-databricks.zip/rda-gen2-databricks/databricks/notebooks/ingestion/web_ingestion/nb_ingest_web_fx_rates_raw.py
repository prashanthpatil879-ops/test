# Databricks notebook source
# MAGIC %md
# MAGIC ### Notebook to load FX rates from IFS Web

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("FX Rates ingestion started...")

# COMMAND ----------

dataset_key = "fx_rates"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.web.{dataset_key}")

# COMMAND ----------

from rda.ingestion.web_ingestor import WebIngestor
ingestor = WebIngestor(env_config, spark)

# COMMAND ----------

new_df = ingestor.read(dataset_cfg)

if spark.catalog.tableExists(dataset_cfg.raw_table):
    old_df = ingestor._uc.read_latest(dataset_cfg.raw_table)
else:
    old_df = None

is_new = ingestor.detect_new_data(new_df, old_df, dataset_cfg)

if is_new:
    final_df = ingestor.add_audit_columns(new_df)
    ingestor.write(final_df, dataset_cfg)
else:
    logger.info("No new FX Rates data to write...")


# COMMAND ----------

logger.info("FX Rates ingestion completed successfully")