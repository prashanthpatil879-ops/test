# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("RF Ear PCA Stats ingestion started...")

# COMMAND ----------

dataset_key = "rf_ear_pca_stats"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.sqlmi.{dataset_key}")

# COMMAND ----------

from rda.ingestion.sqlmi_ingestor import SqlIngestor
ingestor = SqlIngestor(env_config, spark)

# COMMAND ----------

df = ingestor.read(dataset_cfg)

if df is None: 
    dbutils.notebook.exit(f"No new data found at {dataset_cfg.source_table}")

df = ingestor.add_audit_columns(df, dataset_cfg)
ingestor.write(df, dataset_cfg)

# COMMAND ----------

logger.info("RF EaR PCA Stats ingestion completed successfully")