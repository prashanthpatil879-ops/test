# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("RF Ear FinalShocks ingestion started...")

# COMMAND ----------

dataset_key = "rf_ear_final_shocks"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.sqlmi.{dataset_key}")

# COMMAND ----------

from rda.ingestion.sqlmi_ingestor import SqlIngestor
ingestor = SqlIngestor(env_config, spark)

# COMMAND ----------

df = ingestor.read(dataset_cfg)

if df is None: 
    dbutils.notebook.exit(f"No new data found at {dataset_cfg.source_table}")

df = ingestor.add_audit_columns(df, dataset_cfg)
ingestor.write(df, dataset_cfg)


# COMMAND ----------

logger.info("RF EaR FinalShocks ingestion completed successfully")