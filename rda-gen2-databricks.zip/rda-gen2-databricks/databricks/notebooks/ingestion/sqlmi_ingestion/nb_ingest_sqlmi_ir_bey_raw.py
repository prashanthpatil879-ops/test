# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

dataset_key = "ir_bey"

# COMMAND ----------

dataset_cfg = env_config.get(f"ingest.sqlmi.{dataset_key}")

# COMMAND ----------

from rda.ingestion.sqlmi_ingestor import SqlIngestor
ingestor = SqlIngestor(env_config, spark)

# COMMAND ----------

df = ingestor.read(dataset_cfg)

if df is None: 
    dbutils.notebook.exit(f"No new data found at {dataset_cfg.source_table}")

df = ingestor.add_audit_columns(df, dataset_cfg)
ingestor.write(df, dataset_cfg)