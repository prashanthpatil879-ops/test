# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EC engine Foward Curve Generator started")

# COMMAND ----------

engine_key = "foward_curve_generator"

# COMMAND ----------

engine_config = env_config.get(f"engine.ec.{engine_key}")

# COMMAND ----------

from rda.engine.ec.forward_curve_generator import ForwardCurveGenerator
fwd_crv_gen = ForwardCurveGenerator(env_config, spark, engine_config)

inputs = fwd_crv_gen.read()
ir_bey_rates_output_df = fwd_crv_gen.generate_bey_rates(inputs)
benchmark_yc_df = fwd_crv_gen.calculate_benchmark_yc(inputs, ir_bey_rates_output_df)
curve_bootstrap_discount_factor_df = fwd_crv_gen.generate_bootstrap_curve(inputs, benchmark_yc_df)
curve_extrap_intrap_discount_factor = fwd_crv_gen.extrapolate_output_spot(inputs, curve_bootstrap_discount_factor_df)
curve_output_base_fwd_rates = fwd_crv_gen.generate_output(inputs, curve_extrap_intrap_discount_factor)
fwd_crv_gen.unpersist_all()

# COMMAND ----------

logger.info("EC engine Foward Curve Generator completed")