# Databricks notebook source
dbutils.widgets.text(name="forecast_date", defaultValue="yyyy-MM-DD", label="Forecast Date")
forecast_date = dbutils.widgets.get("forecast_date")

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EC engine Daily EC forecast started")

# COMMAND ----------

engine_key = "daily_ec_forecast"

# COMMAND ----------

engine_config = env_config.get(f"engine.ec.{engine_key}")

# COMMAND ----------

from rda.engine.ec.daily_ec_forecast import DailyECForecast
daily_ec_forecast = DailyECForecast(env_config, spark, engine_config, forecast_date)

inputs = daily_ec_forecast.read()
parcurve_diff_df = daily_ec_forecast.calculate_parcurve_diff(inputs)
blended_df = daily_ec_forecast.blending_market_inputs(inputs, parcurve_diff_df)
gam_model_input_df = daily_ec_forecast.model_input_preparation(inputs)
sensitivity_grid_df = daily_ec_forecast.compute_sensitivity_grid(inputs, gam_model_input_df)
spline_base_df = daily_ec_forecast.step_apply_cublic_spline(sensitivity_grid_df, blended_df)
forecast_rates_df = daily_ec_forecast.step_calculate_forecast_rates(spline_base_df)
sensitivity_base_df = daily_ec_forecast.step_daily_sensitivity(inputs, forecast_rates_df)

daily_ec_forecast.unpersist_all()