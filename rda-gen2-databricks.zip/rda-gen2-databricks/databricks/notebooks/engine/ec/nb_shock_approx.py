# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EC engine Shock approximation started")

# COMMAND ----------

engine_key = "shock_approximation"

# COMMAND ----------

engine_config = env_config.get(f"engine.ec.{engine_key}")

# COMMAND ----------

from rda.engine.ec.shock_approx import ShockApprox
shock_approx = ShockApprox(env_config, spark, engine_config)

inputs = shock_approx.read()
ratios_df = shock_approx.calculate_ratios(inputs)
combined_qe_fc_df = shock_approx.calculate_shocks(inputs, ratios_df)
shock_approx.unpersist_all()

# COMMAND ----------

logger.info("EC engine Shock approximation completed")