# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

dataset_key = "swap_spread_interest_rate_ec_curation"

# COMMAND ----------

dataset_cfg = env_config.get(f"engine.ec.{dataset_key}")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType
from datetime import datetime, date
from zoneinfo import ZoneInfo
from pyspark.sql import DataFrame
from rda.utils.sqlfunctions import get_sql_token
from rda.utils.date_utils import last_quarter_end
from rda.io.unity_catalog import UnityCatalog
uc = UnityCatalog(env_config, spark)

# COMMAND ----------

swap_spread_df = uc.read_latest(dataset_cfg.inputs.swap_spread.table_name, dataset_cfg.inputs.swap_spread.watermark_col)
dim_heirarchy_df = uc.read_latest(dataset_cfg.inputs.heirarchy_mapping_latest.table_name, dataset_cfg.inputs.heirarchy_mapping_latest.watermark_col)

# COMMAND ----------

def add_audit_cols(df: DataFrame) -> DataFrame:
    # today_key = date(2026, 1, 17)
    today_key = datetime.now(tz=ZoneInfo("America/Toronto")).date()
    prev_qtr_end_date = last_quarter_end(today_key)
    return (
        df.withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))
        .withColumn("RUN_DATE", F.to_date(F.col("INGESTION_TS")) )
        .withColumn("REPORTING_DATE", F.lit(prev_qtr_end_date))
    )

# COMMAND ----------

if spark.catalog.tableExists(dataset_cfg.output.table_name):
    watermark_value = uc.read_watermark(dataset_cfg.output.table_name, "REPORTING_DATE")
    if watermark_value:
        raw_filtered_df = swap_spread_df.filter(F.to_date(F.col("REPORTING_DATE")) > watermark_value)
    else:
        raw_filtered_df = swap_spread_df
else:
    raw_filtered_df = swap_spread_df

if raw_filtered_df.limit(1).count() == 0:
    dbutils.notebook.exit("No new swap sread data to process")

hierarchy_df = dim_heirarchy_df.select("LOWEST_LEVEL_PORTFOLIO_NAME", "TARGET_CURRENCY_NAME")

joined_df = (
    raw_filtered_df.alias("raw")
    .join(
        hierarchy_df.alias("hier"),
        F.upper(F.trim(F.col("raw.LLP_NAME")))
        == F.upper(F.trim(F.col("hier.LOWEST_LEVEL_PORTFOLIO_NAME"))),
        "left"
    ))


curation_df = (
    joined_df.select(F.lit("Interest Rate Risk").alias("RISK_TYPE"),
                    F.lit("Swap Spread").alias("SUB_RISK_TYPE"),
                    F.col("raw.LLP_NAME").alias("LLP_NAME"),
                    F.col("hier.TARGET_CURRENCY_NAME").alias("TARGET_CURRENCY"),
                    F.lit("Pre-Tax").alias("TAX_INDICATOR"),
                    F.lit("Net").alias("BALANCE_SHEET_COMPONENT_NAME"),
                    F.lit("OCI").alias("IFRS_EARNINGS_COMPONENT_NAME"),
                    F.lit("EC non-parallel interest rate scenario A").alias("SCENARIO_KEY"),
                    F.col("raw.AMOUNT").cast("decimal(28,15)").alias("AMOUNT"))
    )
final_df = add_audit_cols(curation_df)
uc.write(final_df, dataset_cfg.output.table_name, dataset_cfg.output.ext_table_loc)