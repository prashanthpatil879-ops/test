# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EAR engine CSM Flooring started...")

# COMMAND ----------

engine_key = "csm_flooring"

# COMMAND ----------

engine_config = env_config.get(f"engine.ear.{engine_key}")

# COMMAND ----------

from rda.engine.ear.csm_flooring import CSMFlooring
csm = CSMFlooring(env_config, spark, engine_config)

inputs = csm.read()
avg_shocks_df = csm.calculate_avg_shocks(inputs)
earning_sensitivity_df = csm.calcualte_earnings_sensitivity(inputs)
pnl_gain_loss_posttax_df, pnl_gain_loss_posttax_df_final = csm.calcualte_pnl_with_shocks(inputs, avg_shocks_df, earning_sensitivity_df)
pnl_gain_loss_posttax_df = csm.calculate_reinsurence_pnl(pnl_gain_loss_posttax_df)
csm.unpersist_all()

# COMMAND ----------

logger.info("EAR engine CSM Flooring completed successfully")