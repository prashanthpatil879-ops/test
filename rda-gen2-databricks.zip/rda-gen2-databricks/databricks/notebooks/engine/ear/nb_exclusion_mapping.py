# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EAR Exclusion Mapping engine started...")

# COMMAND ----------

engine_key = "tamsegment_exclusion_mapping"

# COMMAND ----------

engine_config = env_config.get(f"engine.ear.{engine_key}")

# COMMAND ----------

from rda.engine.ear.exclusion_mapping import ExclusionMapping
exc_mapping = ExclusionMapping(env_config, spark, engine_config)

# COMMAND ----------

inputs = exc_mapping.read()
exclusion_mapping_df = exc_mapping.calculate_tamsegment_exclusion_mapping(inputs)

# COMMAND ----------

logger.info("EAR Exclusion Mapping engine completed successfully")