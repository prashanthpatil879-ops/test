# Databricks notebook source
dbutils.widgets.text("ANALYSIS_DATE", "YYYY-MM-DD", "YYYY-MM-DD")
analysis_date = dbutils.widgets.get("ANALYSIS_DATE")

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Stress test engine started to compute asset impact...")

# COMMAND ----------

engine_key = "asset_impact"
engine_config = env_config.get(f"engine.stresstest.{engine_key}")

# COMMAND ----------

from rda.engine.stresstest.asset_impact import StressTestAssetImpact
assetImpact = StressTestAssetImpact(env_config, spark, engine_config, analysis_date)

inputs = assetImpact.read()
ga_b1_derive_df, ga_b1_derive_alda_pe_df = assetImpact.step_asset_impact(inputs)

assetImpact.unpersist_all()

# COMMAND ----------

logger.info("Stress test engine to compute asset impact completed")