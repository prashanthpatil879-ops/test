# Databricks notebook source
dbutils.widgets.text("ANALYSIS_DATE", "YYYY-MM-DD", "YYYY-MM-DD")
analysis_date = dbutils.widgets.get("ANALYSIS_DATE")

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Stress test engine started for ST Propogation curation and scenario automation...")

# COMMAND ----------

engine_key = "sca"
engine_config = env_config.get(f"engine.stresstest.{engine_key}")

# COMMAND ----------

from rda.engine.stresstest.st_prop_sca import SCA
sca = SCA(env_config, spark, engine_config, analysis_date)

inputs = sca.read()

st_propogation_derived_df = sca.curate_st_propogation(inputs)
unified_shocks_df = sca.calculate_unified_shocks(inputs, st_propogation_derived_df)
consolidated_shocks_df = sca.calculate_consolidated_shocks(inputs, unified_shocks_df)

sca.unpersist_all()

# COMMAND ----------

logger.info("Stress test engine for ST Propogation curation and scenario automation completed")