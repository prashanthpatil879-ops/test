# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Stress test engine started for Liability Impact...")

# COMMAND ----------

engine_key = "liability_impact"
engine_config = env_config.get(f"engine.stresstest.{engine_key}")

# COMMAND ----------

from rda.engine.stresstest.liability_impact import StressTestLiabilityImpact
liability_impact = StressTestLiabilityImpact(env_config, spark, engine_config)

inputs = liability_impact.read()

es_fi_sensitivity_base_df = liability_impact.step_es_fi_sensitivity(inputs)
es_fi_sensitivity_base_df.display()

liability_impact.unpersist_all()

# COMMAND ----------

logger.info("Stress test engine Liability Impact completed")