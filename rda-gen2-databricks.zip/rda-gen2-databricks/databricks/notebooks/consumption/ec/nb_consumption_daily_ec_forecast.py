# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EC engine Daily EC forecast consumption layer started")

# COMMAND ----------

from rda.io.sql_mi import SqlMI
from rda.io.unity_catalog import UnityCatalog
sql_mi = SqlMI(env_config, spark)
uc = UnityCatalog(env_config, spark)

# COMMAND ----------

max_watermark = sql_mi.read_watermark('dbo.Fact_EC_Forecast', 'Load_TS')
data_df = uc.read_incremental(env_config.get('engine.ec.daily_ec_forecast.output.table_name'), watermark_col='INGESTION_TS', watermark_value=max_watermark)

# COMMAND ----------

# from datetime import datetime
# max_forecast_date_int_key = sql_mi.read_query("select max(forecast_date_key) as dk from dbo.Fact_EC_Forecast").collect()[0]['dk']
# max_forecast_date = None if max_forecast_date_int_key is None else datetime.strptime(str(max_forecast_date_int_key), '%Y%m%d').strftime('%Y-%m-%d')
# if max_forecast_date:
#     logger.info(f"Finding records from curation with forecast_date > {max_forecast_date}")
#     data_df = uc.read_query(f"select * from {env_config.get('engine.ec.daily_ec_forecast.output.table_name')} where forecast_date > '{max_forecast_date}'")
# else:
#     logger.info("Loading all records from curation to consumption...")
#     data_df = uc.read_query(f"select * from {env_config.get('engine.ec.daily_ec_forecast.output.table_name')}")

# COMMAND ----------

import pyspark.sql.functions as F
data_df = (
    data_df
    .withColumn("RISK_TYPE", F.lit("Interest Rate Risk"))
    .withColumn("SUB_RISK_TYPE", F.lit("Risk Free"))
    .withColumn("RISK_MEASURE_TYPE", F.lit("EC"))
    .withColumn("MEASUREMENT_FREQUENCY", F.lit("DAILY"))
    .withColumn("SCENARIO", F.lit("EC non-parallel interest rate scenario A"))
    .withColumn("PRE_ADJUSTED_AMOUNT", F.col("IR_EC_DOWN") )
    .withColumn("ADJUSTMENT_AMOUNT", F.lit(0))
    .withColumn("POST_ADJUSTED_AMOUNT", F.col("IR_EC_DOWN") )
)

# COMMAND ----------

data_fact_df = (
    data_df.alias("src")
    .join(uc.read_latest_dim("dim_risk_type").alias("dim_rt"), F.col("src.risk_type") == F.col("dim_rt.risk_type_name"), "left")
    .join(uc.read_latest_dim("dim_sub_risk_type").alias("dim_srt"), F.col("src.SUB_RISK_TYPE") == F.col("dim_srt.SUB_RISK_TYPE_NAME"), "left")
    .join(uc.read_latest_dim("dim_risk_measure_type").alias("dim_rmt"), F.col("src.RISK_MEASURE_TYPE") == F.col("dim_rmt.RISK_MEASURE_TYPE_CODE"), "left")
    .join(uc.read_latest_dim("dim_measurement_frequency").alias("dim_mf"), F.col("src.MEASUREMENT_FREQUENCY") == F.col("dim_mf.MEASUREMENT_FREQUENCY_CODE"), "left")
    .join(uc.read_latest_dim("dim_date").alias("dim_dt1"), F.col("src.FORECAST_DATE") == F.col("dim_dt1.date"), "left")
    .join(uc.read_latest_dim("dim_date").alias("dim_dt2"), F.col("src.REPORTING_DATE") == F.col("dim_dt2.date"), "left")
    .join(uc.read_latest_dim("dim_tax_indicator").alias("dim_ti"), F.col("src.TAX_INDICATOR_NAME") == F.col("dim_ti.TAX_INDICATOR_NAME"), "left")
    .join(uc.read_latest_dim("dim_lowest_level_portfolio").alias("dim_llp"), F.col("src.LOWEST_LEVEL_PORTFOLIO_NAME") == F.col("dim_llp.LOWEST_LEVEL_PORTFOLIO_NAME"), "left")
    .join(uc.read_latest_dim("dim_balance_sheet_component").alias("dim_bs"), F.col("src.BALANCE_SHEET_COMPONENT_NAME") == F.col("dim_bs.BALANCE_SHEET_COMPONENT_NAME"), "left")
    .join(uc.read_latest_dim("dim_ifrs_earnings_component").alias("dim_if"), F.col("src.IFRS_EARNINGS_COMPONENT_NAME") == F.col("dim_if.IFRS_EARNINGS_COMPONENT_NAME"), "left")
    .join(uc.read_latest_dim("dim_scenario").alias("dim_s"), F.col("src.SCENARIO") == F.col("dim_s.SCENARIO_NAME"), "left")
    .join(uc.read_latest_dim("dim_currency").alias("dim_cur"), F.col("src.CURRENCY_CODE") == F.col("dim_cur.CURRENCY_ALPHA_CODE"), "left")
    .select(
        F.coalesce(F.col("dim_rt.risk_type_key"), F.lit(0)).alias("RISK_TYPE_KEY"),
        F.coalesce(F.col("dim_srt.Sub_Risk_Type_Key"), F.lit(0)).alias("SUB_RISK_TYPE_KEY"),
        F.coalesce(F.col("dim_rmt.Risk_Measure_Type_Key"), F.lit(0)).alias("RISK_MEASURE_TYPE_KEY"),
        F.coalesce(F.col("dim_mf.MEASUREMENT_FREQUENCY_KEY"), F.lit(0)).alias("MEASUREMENT_FREQUENCY_KEY"),
        F.coalesce(F.col("dim_dt1.DATE_KEY"), F.lit(0)).alias("FORECAST_DATE_KEY"),
        F.coalesce(F.col("dim_dt2.DATE_KEY"), F.lit(0)).alias("REPORTING_DATE_KEY"),
        F.coalesce(F.col("dim_ti.TAX_INDICATOR_KEY"), F.lit(0)).alias("TAX_INDICATOR_KEY"),
        F.coalesce(F.col("dim_llp.LOWEST_LEVEL_PORTFOLIO_KEY"), F.lit(0)).alias("LOWEST_LEVEL_PORTFOLIO_KEY"),
        F.coalesce(F.col("dim_bs.BALANCE_SHEET_COMPONENT_KEY"), F.lit(0)).alias("BALANCE_SHEET_COMPONENT_KEY"),
        F.coalesce(F.col("dim_if.IFRS_EARNINGS_COMPONENT_KEY"), F.lit(0)).alias("IFRS_EARNINGS_COMPONENT_KEY"),
        F.coalesce(F.col("dim_s.SCENARIO_KEY"), F.lit(0)).alias("SCENARIO_KEY"),
        F.coalesce(F.col("dim_cur.CURRENCY_KEY"), F.lit(0)).alias("CURRENCY_KEY"),
        "src.PRE_ADJUSTED_AMOUNT",
        "src.ADJUSTMENT_AMOUNT",
        "src.POST_ADJUSTED_AMOUNT",
        F.col("src.RUN_DATE").alias("RUN_DATE"),
        F.col("src.INGESTION_TS").alias("LOAD_TS")
    )
)

if data_fact_df.take(1):
    logger.info("Writing to Fact_EC_Forecast...")
    sql_mi.write_fact(data_fact_df, "dbo.Fact_EC_Forecast")
else:
    logger.info("No data to write to Fact_EC_Forecast")