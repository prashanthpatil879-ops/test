# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("EC swap spread interest rate consumption layer started")

# COMMAND ----------

import pyspark.sql.functions as F
from rda.io.sql_mi import SqlMI
from rda.io.unity_catalog import UnityCatalog
sql_mi = SqlMI(env_config, spark)
uc = UnityCatalog(env_config, spark)

# COMMAND ----------

max_watermark = sql_mi.read_watermark('dbo.Fact_EC_Swap_Spread', 'Load_TS')
data_df = uc.read_incremental(env_config.get('engine.ec.swap_spread_interest_rate_ec_curation.output.table_name'), watermark_col='INGESTION_TS', watermark_value=max_watermark)

# COMMAND ----------

data_fact_df = (
    data_df.alias("src")
    .join(uc.read_latest_dim("dim_risk_type").alias("dim_rt"), F.col("src.RISK_TYPE") == F.col("dim_rt.risk_type_name"), "left")
    .join(uc.read_latest_dim("dim_sub_risk_type").alias("dim_srt"), F.col("src.SUB_RISK_TYPE") == F.col("dim_srt.SUB_RISK_TYPE_NAME"), "left")
    .join(uc.read_latest_dim("dim_lowest_level_portfolio").alias("dim_llp"), F.col("src.LLP_NAME") == F.col("dim_llp.LOWEST_LEVEL_PORTFOLIO_NAME"), "left")
    .join(uc.read_latest_dim("dim_currency").alias("dim_cur"), F.col("src.TARGET_CURRENCY") == F.col("dim_cur.CURRENCY_ALPHA_CODE"), "left")
    .join(uc.read_latest_dim("dim_tax_indicator").alias("dim_ti"), F.col("src.TAX_INDICATOR") == F.col("dim_ti.TAX_INDICATOR_NAME"), "left")
    .join(uc.read_latest_dim("dim_balance_sheet_component").alias("dim_bs"), F.col("src.BALANCE_SHEET_COMPONENT_NAME") == F.col("dim_bs.BALANCE_SHEET_COMPONENT_NAME"), "left")
    .join(uc.read_latest_dim("dim_ifrs_earnings_component").alias("dim_if"), F.col("src.IFRS_EARNINGS_COMPONENT_NAME") == F.col("dim_if.IFRS_EARNINGS_COMPONENT_NAME"), "left")
    .join(uc.read_latest_dim("dim_scenario").alias("dim_s"), F.col("src.SCENARIO_KEY") == F.col("dim_s.SCENARIO_NAME"), "left")
    .join(uc.read_latest_dim("dim_date").alias("dim_dt2"), F.col("src.REPORTING_DATE") == F.col("dim_dt2.date"), "left")
    .select(
        F.coalesce(F.col("dim_rt.risk_type_key"), F.lit(0)).alias("RISK_TYPE_KEY"),
        F.coalesce(F.col("dim_srt.Sub_Risk_Type_Key"), F.lit(0)).alias("SUB_RISK_TYPE_KEY"),
        F.coalesce(F.col("dim_llp.LOWEST_LEVEL_PORTFOLIO_KEY"), F.lit(0)).alias("LOWEST_LEVEL_PORTFOLIO_KEY"),
        F.coalesce(F.col("dim_cur.CURRENCY_KEY"), F.lit(0)).alias("CURRENCY_KEY"),
        F.coalesce(F.col("dim_ti.TAX_INDICATOR_KEY"), F.lit(0)).alias("TAX_INDICATOR_KEY"),
        F.coalesce(F.col("dim_bs.BALANCE_SHEET_COMPONENT_KEY"), F.lit(0)).alias("BALANCE_SHEET_COMPONENT_KEY"),
        F.coalesce(F.col("dim_if.IFRS_EARNINGS_COMPONENT_KEY"), F.lit(0)).alias("IFRS_EARNINGS_COMPONENT_KEY"),
        F.coalesce(F.col("dim_s.SCENARIO_KEY"), F.lit(0)).alias("SCENARIO_KEY"),
        F.coalesce(F.col("dim_dt2.DATE_KEY"), F.lit(0)).alias("REPORTING_DATE_KEY"),
        "src.AMOUNT",
        F.col("src.RUN_DATE").alias("RUN_DATE"),
        F.col("src.INGESTION_TS").alias("LOAD_TS")
    )
)

if data_fact_df.take(1):
    logger.info("Writing to Fact_EC_Swap_Spread...")
    sql_mi.write_fact(data_fact_df, "dbo.Fact_EC_Swap_Spread")
else:
    logger.info("No data found to write to Fact_EC_Swap_Spread")