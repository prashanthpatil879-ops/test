# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from datetime import datetime
from zoneinfo import ZoneInfo

import sys
import os

from rda.utils.sqlfunctions import get_sql_token, save_sql_run_data

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType
from pyspark.sql.functions import col

# COMMAND ----------

pdf_runs = spark.sql(f"SELECT * \
                        FROM " + env_config.get("common.ear_forecast_rda_run.rda_run_table") + " \
                        WHERE Consumption_TS IS NULL AND Consumption_Remarks IS NULL AND Process_Name = 'Consolidated Sensitivities Segment Mapping'").toPandas()
# display(pdf_runs)

for run_row in pdf_runs.iterrows():

    # print(run_row)
    datetoday = datetime.now(ZoneInfo("UTC"))
    extractiondate = run_row[1]["Ingestion_TS"].tz_localize('UTC')

    df_curated = spark.sql("SELECT * FROM " + env_config.get("curation.gam_segmentmapping.curation_table") + " WHERE Source_File = '" + run_row[1]['Source_File'] + "'" + 
                        " AND Curation_TS = '" + str(run_row[1]['Curation_TS']) + "' ")
    
    consumption_remarks = ""
    
    if df_curated.count() > 0:

        if(df_curated.filter(col("Country_Key").isNull()).count() > 0):
            consumption_remarks += "Has null Country Key, "
        
        if(df_curated.filter(col("Date_Key").isNull()).count()):
            consumption_remarks += "Has null Date Key, "

        if(df_curated.filter(col("Reporting_Date_Key").isNull()).count()):
            consumption_remarks += "Has null Reporting Date Key, "

        if(consumption_remarks != ""):
            consumption_remarks = consumption_remarks[:-2]
        else:
            df_run = spark.createDataFrame(data=[(run_row[1]["Process_Name"], extractiondate, datetoday, 'ADB', run_row[1]["Source_File"], 
                                                df_curated.first()['Date_Key'], df_curated.first()['Reporting_Date_Key'])], 
                                    schema=StructType([StructField("Process_Name", StringType(), True),
                                                        StructField("Process_Start_Date", TimestampType(), True),
                                                        StructField("Process_End_Date", TimestampType(), True),
                                    
                                                        StructField("Process_Run_By", StringType(), True),
                                                        StructField("InputFileName", StringType(), True),
                                                        StructField("Date_Key", IntegerType(), True),
                                                        StructField("Reporting_Date_Key", IntegerType(), True)]))        

            # display(df_run)
            # display(df_curated)    

            df_consumption = df_curated[['Country_Key', 'Tam_Segment_Key', 'Lowest_Level_Portfolio_Key', 'Asset_Segment_Key', 
                                            'Liability_Segment_Key', 'Product_Type_Key', 'Par_Status_Key', 
                                            'Tax_Rate', 'Minority_Interest', 'GMT']]
            
            jdbc_url = f"jdbc:sqlserver://{env_config.get("sqlmi.server")};databaseName={env_config.get("sqlmi.database")};encrypt=true;hostNameInCertificate=*.database.windows.net;"
            access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                                        client_id=env_config.get("secrets.client_id"), 
                                        client_secret=env_config.get("secrets.client_secret"))

            save_sql_run_data(df_run=df_run, df_run_details=df_consumption, access_token=access_token, jdbc_url=jdbc_url, table_prefix=env_config.get("env_table_prefix"))

    spark.sql(f"UPDATE {env_config.get("common.ear_forecast_rda_run.rda_run_table")} " +
            "SET Consumption_TS = '" + str(datetoday) + "', Consumption_Remarks = '" + consumption_remarks + "'" +
            "WHERE Process_Name = '" + run_row[1]['Process_Name'] + "' "+
            "AND Source_File = '" + run_row[1]['Source_File'] + "' " +
            "AND Curation_TS = '" + str(run_row[1]['Curation_TS']) + "'")