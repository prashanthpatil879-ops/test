# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from datetime import datetime
from zoneinfo import ZoneInfo

import sys
import os

from rda.utils.sqlfunctions import get_sql_token, save_sql_run_data

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType
from pyspark.sql.functions import col

# COMMAND ----------

pdf_runs = spark.sql(f"SELECT * \
                        FROM {env_config.get("common.ear_forecast_rda_run.rda_run_table")} \
                        WHERE Consumption_TS IS NULL AND Consumption_Remarks IS NULL AND Process_Name = 'IR Ear RF Daily Forecasting'").toPandas()
# display(pdf_runs)

for run_row in pdf_runs.iterrows():

    # print(run_row)
    datetoday = datetime.now(ZoneInfo("UTC"))
    curationdate = run_row[1]["Curation_TS"].tz_localize('UTC')

    df_curated = spark.sql(f"SELECT * \
                            FROM {env_config.get("curation.ear_forecasting.curation_table.rates")} \
                            WHERE Source_File = '" + run_row[1]['Source_File'] + "' AND Curation_TS = '" + str(run_row[1]['Curation_TS']) + "'")
    
    consumption_remarks = ""
    print(df_curated.count())
    
    if df_curated.count() > 0:

        if(df_curated.filter(col("Country_Key").isNull()).count() > 0):
            consumption_remarks += "Has null Country Key, "
        
        if(df_curated.filter(col("Date_Key").isNull()).count()):
            consumption_remarks += "Has null Date Key, "

        if(df_curated.filter(col("Currency_Key").isNull()).count()):
            consumption_remarks += "Has null Currency Key, "

        if(df_curated.filter(col("Reporting_Date_Key").isNull()).count()):
            consumption_remarks += "Has null Reporting Date Key, "

        if(consumption_remarks != ""):
            consumption_remarks = consumption_remarks[:-2]
        else:
            df_run = spark.createDataFrame(data=[(run_row[1]["Process_Name"], curationdate, datetoday, 'ADB', run_row[1]["Source_File"], 
                                                df_curated.first()['Date_Key'], df_curated.first()['Reporting_Date_Key'])], 
                                    schema=StructType([StructField("Process_Name", StringType(), True),
                                                        StructField("Process_Start_Date", TimestampType(), True),
                                                        StructField("Process_End_Date", TimestampType(), True),
                                                        StructField("Process_Run_By", StringType(), True),
                                                        StructField("InputFileName", StringType(), True),
                                                        StructField("Date_Key", IntegerType(), True),
                                                        StructField("Reporting_Date_Key", IntegerType(), True)]))        

            # display(df_run)
            # display(df_consumption)    

            df_consumption = df_curated[['Country_Key', 'Tax_Indicator_Key', 'Lowest_Level_Portfolio_Key', 'Balance_Sheet_Component_Key', 
                                        'IFRS_Earnings_Component_Key', 'Scenario_Key', 'Currency_Key', 'Amount']]
            
            jdbc_url = f"jdbc:sqlserver://{env_config.get("sqlmi.server")};databaseName={env_config.get("sqlmi.database")};encrypt=true;hostNameInCertificate=*.database.windows.net;"
            access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                                        client_id=env_config.get("secrets.client_id"), 
                                        client_secret=env_config.get("secrets.client_secret"))

            save_sql_run_data(df_run=df_run, df_run_details=df_consumption, access_token=access_token, jdbc_url=jdbc_url, table_prefix=env_config.get("env_table_prefix"))

    spark.sql(f"UPDATE {env_config.get("common.ear_forecast_rda_run.rda_run_table")} " +
            "SET Consumption_TS = '" + str(datetoday) + "', Consumption_Remarks = '" + consumption_remarks + "'" +
            "WHERE Process_Name = '" + run_row[1]['Process_Name'] + "' "+
            "AND Source_File = '" + run_row[1]['Source_File'] + "' " +
            "AND Curation_TS = '" + str(run_row[1]['Curation_TS']) + "'")