# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Factor scenario curation loading started...")

# COMMAND ----------

dataset_key = "factor_scenarios_curation"

# COMMAND ----------

dataset_cfg = env_config.get(f"curation.{dataset_key}")

# COMMAND ----------

from pyspark.sql import functions as F, Window
from rda.io.unity_catalog import UnityCatalog
import rda.utils.spark_utils as su
uc = UnityCatalog(env_config, spark)

# COMMAND ----------

factor_raw_df = uc.read_table(dataset_cfg.inputs.factor_raw)
country_currency_mapping_df = uc.read_latest(dataset_cfg.inputs.country_currency_raw).distinct().filter(F.col("CURRENCY_CODE").isNotNull())

window = Window.partitionBy("COUNTRY").orderBy( F.when(F.col("CURRENCY_CODE").isin(["EUR", "NZD", "GBP", "DKK", "AUD"]), 0).otherwise(1) )
country_currency_mapping_df = country_currency_mapping_df.withColumn("RANK", F.dense_rank().over(window)).filter(F.col("RANK") == 1).drop("RANK")

factor_raw_df = (
    factor_raw_df
    .withColumn("rnk", F.dense_rank().over(Window.partitionBy("SOURCE").orderBy(F.col("INGESTION_TS").desc())))
    .filter( F.col("rnk") == 1 )
    .drop("rnk", "INGESTION_TS", "CREATED_BY")
)

derive_additional_columns_base_df = (
    factor_raw_df
    .withColumn(
        "RISK_FACTOR_SUBTYPE",
        F.when( (F.col("ASSET_CLASS") == "Fixed Income") & (F.col("FACTOR_GROUP") == "Term Structure") & (F.col("FACTOR_SUBGROUP") == "Treasury") & (F.col("FACTOR").rlike(r"^[A-Z]{3} Rate [A-Z0-9]+$") ), "RF" )
         .when( (F.col("ASSET_CLASS") == "Fixed Income") & (F.col("FACTOR_GROUP") == "Spread") & (F.col("FACTOR_SUBGROUP") == "Credit") & (F.col("FACTOR").rlike(r"^[A-Z]{1,4} Corporate IG Spread$") ), "CS" )
         .when( (F.col("ASSET_CLASS") == "Currency") & (F.col("FACTOR_GROUP") == "Currencies"), "Curr" ) 
         .when( (F.col("ASSET_CLASS") == "Equity") & (F.col("FACTOR_GROUP") == "Countries"), "PE" )
         .when( (F.col("ASSET_CLASS") == "Fixed Income") & (F.col("FACTOR_GROUP") == "Spread") & (F.col("FACTOR_SUBGROUP") == "Swap") & (F.col("FACTOR").rlike(r"^[A-Z]{3} Swap [A-Z0-9]+$")), "SS" )
         .otherwise("Unclassified")
    )
    .withColumn(
        "NORMALIZED_BPS_SHOCK",
        F.col("SHOCK")
    )
    .withColumn(
        "TENOR",
        F.when(
            F.col("RISK_FACTOR_SUBTYPE") == "RF",
            F.regexp_extract(F.col("FACTOR"), r"^[A-Z]{3} Rate ([A-Z0-9]+)$", 1)
        ).otherwise(F.lit(None))
    )
)

pe_records_df = derive_additional_columns_base_df.filter(F.col("RISK_FACTOR_SUBTYPE") == "PE")
pe_records_df = pe_records_df.withColumn("COUNTRY_TEMP", F.regexp_extract(F.col("FACTOR"), r"^[A-Z]+\s(.*)\sMkt$", 1))

pe_records_df = (
    pe_records_df.alias("pe")
    .join(
        country_currency_mapping_df.alias("c"),
        on = su.normalize_text_without_space(F.col("pe.COUNTRY_TEMP")) == su.normalize_text_without_space(F.col("c.COUNTRY")),
        how = "inner"
    )
    .select( "pe.*", "c.CURRENCY_CODE")
)

curr_cs_records_df = derive_additional_columns_base_df.filter(F.col("RISK_FACTOR_SUBTYPE").isin(["CS", "Curr"]))
curr_cs_records_df = curr_cs_records_df.withColumn("COUNTRY_TEMP", F.regexp_extract(F.col("FACTOR"), r"^([A-Z]+)\s", 1))

curr_cs_records_df = (
    curr_cs_records_df.alias("cs")
    .join(
        country_currency_mapping_df.alias("c"),
        on = su.normalize_text_without_space(F.col("cs.COUNTRY_TEMP")) == su.normalize_text_without_space(F.col("c.TWO_LETTER_COUNTRY_CODE")),
        how = "inner"
    )
    .select( "cs.*", "c.CURRENCY_CODE")
)

rf_records_df = derive_additional_columns_base_df.filter(F.col("RISK_FACTOR_SUBTYPE") == "RF")
rf_records_df = rf_records_df.withColumn("CURRENCY_CODE", F.regexp_extract(F.col("FACTOR"), r"^([A-Z]+)\sRate", 1))

df_with_currency = (
    pe_records_df.unionByName(curr_cs_records_df, allowMissingColumns=True)
    .unionByName(rf_records_df, allowMissingColumns=True)
    .unionByName(derive_additional_columns_base_df.filter(F.col("RISK_FACTOR_SUBTYPE") == "Unclassified"), allowMissingColumns=True ) 
    .drop("COUNTRY_TEMP")
)

df_with_currency = df_with_currency \
.withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))

uc.write(df_with_currency, dataset_cfg.curation_table, dataset_cfg.curation_ext_table_loc)

# COMMAND ----------

logger.info("Factor scenario curation loading completed")