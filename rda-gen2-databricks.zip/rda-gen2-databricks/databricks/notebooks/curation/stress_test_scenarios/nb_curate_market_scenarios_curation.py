# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

from rda.utils.logger import get_notebook_logger
logger = get_notebook_logger()
logger.info("Market scenario curation loading started...")

# COMMAND ----------

dataset_key = "market_scenarios_curation"

# COMMAND ----------

dataset_cfg = env_config.get(f"curation.{dataset_key}")

# COMMAND ----------

from pyspark.sql import functions as F, Window
from rda.io.unity_catalog import UnityCatalog
uc = UnityCatalog(env_config, spark)

# COMMAND ----------

dim_currency = uc.read_latest(dataset_cfg.inputs.dim_currency)
dim_tenors = uc.read_latest(dataset_cfg.inputs.dim_tenors)
market_raw_df = uc.read_table(dataset_cfg.inputs.market_raw)

market_raw_df = (
    market_raw_df
    .withColumn("rnk", F.dense_rank().over(Window.partitionBy("SOURCE").orderBy(F.col("INGESTION_TS").desc())))
    .filter( F.col("rnk") == 1 )
    .drop("rnk", "INGESTION_TS", "CREATED_BY")
)

# Currency DF
currency_filtered = dim_currency.filter(F.col("CURRENCY_ALPHA_CODE") != "NULL").select(F.col("CURRENCY_ALPHA_CODE"))
tenor_filtered = dim_tenors.select(F.col("TENOR_CODE"))

# Records where MARKET = 'All Currencies'
market_all_currencies_df = (market_raw_df.filter(F.col("SCENARIO_SUBTYPE") == "Country Parallel Shocks"))

# Records where MARKET != 'All Currencies'
market_non_all_currencies_df = (market_raw_df.filter(F.col("SCENARIO_SUBTYPE") != "Country Parallel Shocks"))

market_all_currencies_final_df = (
    market_all_currencies_df.alias("m")
    .crossJoin(currency_filtered.alias("c"))
    .crossJoin(tenor_filtered.alias("t"))
    .select(
        F.col("m.TYPE"),
        F.col("c.CURRENCY_ALPHA_CODE").alias("MARKET"),
        F.col("m.FILTER_ATTRIBUTE"),
        F.col("m.FILTER_VALUE"),
        F.col("t.TENOR_CODE").alias("SHOCK_VARIABLE"),
        F.col("m.SHOCK_UNIT"),
        F.col("m.SHOCK_AMOUNT"),
        F.col("m.SCENARIO_NAME"),
        F.col("m.SCENARIO_TYPE"),
        F.col("m.SCENARIO_SUBTYPE"),
        F.col("m.SOURCE")
    )
)

combined_df = market_non_all_currencies_df.union(market_all_currencies_final_df)

combined_df = (
    combined_df.withColumn(
        "FILTER_VALUE",
        F.when(
            F.col("FILTER_VALUE").contains(","),
            F.split(F.col("FILTER_VALUE"), r",\s*")
        ).otherwise(F.array(F.col("FILTER_VALUE")))
    )
    .withColumn("FILTER_VALUE", F.explode("FILTER_VALUE"))
)

# COMMAND ----------

derive_additional_columns_base_df = (
    combined_df
    .withColumn(
        "RISK_FACTOR_SUBTYPE",
        F.when( (F.col("TYPE") == "Rates") & (F.col("FILTER_ATTRIBUTE") == "Term Structure") & (F.col("FILTER_VALUE") == "Government"), "RF" )
         .when( (F.col("TYPE") == "Credit") & (F.col("FILTER_ATTRIBUTE") == "Issuer and Rating") & (F.col("FILTER_VALUE") == "Corporate A") & (F.col("SHOCK_VARIABLE") == "Spread"), "CS" )
         .when( (F.col("TYPE") == "Currency") & (F.col("SHOCK_VARIABLE") == "Exchange Rate"), "Curr" )
         .when( (F.col("TYPE") == "Equity Beta") & (F.col("SHOCK_VARIABLE") == "Est Universe"), "PE" )
         .when( (F.col("TYPE") == "Rates") & (F.col("FILTER_ATTRIBUTE") == "Term Structure") & (F.col("FILTER_VALUE") == "Swap"), "SS" )
         .otherwise("Unclassified")
    )
    .withColumn(
        "CURRENCY_CODE",
        F.when(
            (F.col("RISK_FACTOR_SUBTYPE").isin("RF", "CS", "SS", "Curr")) & (F.col("MARKET").rlike(r"\([A-Z]{3}\)")),
            F.regexp_extract(F.col("MARKET"), r"\(([A-Z]{3})\)", 1)
        )
        .when(
            (F.col("RISK_FACTOR_SUBTYPE").isin("RF", "CS", "SS", "Curr")) & (F.col("MARKET").rlike(r"^[A-Z]{3}$")),
            F.col("MARKET")
        )
        .when(
            F.col("RISK_FACTOR_SUBTYPE").isin("PE"),
            F.col("FILTER_VALUE")
        )
        .otherwise(F.lit(None))
    )
)

rf_values = (
    derive_additional_columns_base_df
    .filter( F.col("RISK_FACTOR_SUBTYPE") == "RF" )
    .select( "SHOCK_VARIABLE", "MARKET", "SHOCK_AMOUNT")
    .distinct()
)

derive_additional_columns_and_normalized_shocks_df = (
    derive_additional_columns_base_df.alias("main")
    .join(
        rf_values.alias("rf"),
        on = [
            F.col("main.SHOCK_VARIABLE") == F.col("rf.SHOCK_VARIABLE"),
            F.col("main.MARKET") == F.col("rf.MARKET"),
            F.col("main.RISK_FACTOR_SUBTYPE") == "SS"
        ],
        how = "left"
    )
    .select("main.*", F.coalesce(F.col("rf.SHOCK_AMOUNT"), F.lit(0)).alias("RF_SHOCK_AMOUNT") )
    .withColumn(
        "NORMALIZED_BPS_SHOCK", 
        F.when(
            F.col("RISK_FACTOR_SUBTYPE") == "SS", 
            F.col("SHOCK_AMOUNT") - F.col("RF_SHOCK_AMOUNT")
        )
        .otherwise(F.col("SHOCK_AMOUNT"))
    )
    .drop("RF_SHOCK_AMOUNT")
)

derive_additional_columns_and_normalized_shocks_df = derive_additional_columns_and_normalized_shocks_df \
.withColumn("INGESTION_TS", F.from_utc_timestamp(F.current_timestamp(), 'America/Toronto'))

uc.write(derive_additional_columns_and_normalized_shocks_df, dataset_cfg.curation_table, dataset_cfg.curation_ext_table_loc)

# COMMAND ----------

logger.info("Market scenario curation loading completed")