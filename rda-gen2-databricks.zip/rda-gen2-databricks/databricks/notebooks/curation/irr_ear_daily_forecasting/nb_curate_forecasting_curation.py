# Databricks notebook source
# DBTITLE 1,Variable Initialization
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

# DBTITLE 1,Import Libraries
#Import libraries
from pyspark.sql.functions import upper
from pyspark.pandas import read_excel
from datetime import datetime
from zoneinfo import ZoneInfo

import os
import sys
import pandas as pd
import re

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DoubleType, LongType, BooleanType, FloatType, DecimalType

from rda.utils.sqlfunctions import get_sql_token, get_sql_dimension, get_sql_query
from rda.utils.forecasting import cubic_spline_interpolation, get_sensitivity_grid, format_model_inputs, get_interpolation, get_forecast
from rda.utils.date_utils import get_previous_quarter_end_date

# COMMAND ----------

# DBTITLE 1,Config Initialization
#Read config file sheet <ModelInputs> to be used to identify the data needed for model inputs
pdf_config_modelinputs = read_excel(env_config.get("common.config_files.forecasting"), sheet_name='ModelInputs', header=0)
# display(pdf_config_modelinputs)

#Read config file sheet <SensitivityGrid> to be used to lookup for the sensitivity grid
pdf_config_sensitivitygrid = read_excel(env_config.get("common.config_files.forecasting"), sheet_name='SensitivityGrid', header=0)
# display(pdf_config_sensitivitygrid)

#Read config file sheet <ForecastDetails> to be used for the forecast name values
pdf_config_forecastdetails = read_excel(env_config.get("common.config_files.forecasting"), sheet_name='ForecastDetails', header=0)
# display(pdf_config_forecastdetails)

#Read config file sheet <Tenor> to be used to identify sheets that will be processed
pdf_config_tenor = read_excel(env_config.get("common.config_files.forecasting"), sheet_name='Tenor', header=0)
# display(pdf_config_tenor)

# COMMAND ----------

# DBTITLE 1,Build string for criteria to limit scenarios for GAM Sensitivities
scenarios = ""

for sensgrid_row in pdf_config_sensitivitygrid.itertuples():    
    for item in sensgrid_row[2:]:
        if not (str(item) in ['None', '0.0']):
            if scenarios == "":
                scenarios = "'" + str(item) + "'"
            else:
                scenarios = scenarios + ",'" + str(item) + "'"

# COMMAND ----------

jdbc_url = f"jdbc:sqlserver://{env_config.get("sqlmi.server")};databaseName={env_config.get("sqlmi.database")};encrypt=true;hostNameInCertificate=*.database.windows.net;"
datetoday = datetime.now(ZoneInfo("UTC"))

# COMMAND ----------

# DBTITLE 1,SegmentMapping

access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                        client_id=env_config.get("secrets.client_id"), 
                        client_secret=env_config.get("secrets.client_secret"))

sql_query = f"SELECT   LS.Liability_Segment_Name, LLP.Lowest_Level_Portfolio_Name, CU.Currency_Alpha_Code Currency_Code\
            FROM	{env_config.get("env_table_prefix")}Fact_Heirarchy_Mapping AS FM \
                    INNER JOIN (SELECT TOP 1 Run_Key FROM {env_config.get("env_table_prefix")}Fact_Run WHERE Process_Name = 'Consolidated Sensitivities Segment Mapping' \
                                ORDER BY Process_Start_Date DESC) FR ON FM.Run_Key = FR.Run_Key \
                    INNER JOIN {env_config.get("env_table_prefix")}Dim_Liability_Segment LS ON FM.Liability_Segment_Key = LS.Liability_Segment_Key \
                    INNER JOIN {env_config.get("env_table_prefix")}Dim_Lowest_Level_Portfolio AS LLP ON FM.Lowest_Level_Portfolio_Key = LLP.Lowest_Level_Portfolio_Key \
                    LEFT JOIN {env_config.get("env_table_prefix")}Dim_Currency AS CU ON LLP.Target_Currency_Key = CU.Currency_Key \
            WHERE	CU.Currency_Name IS NOT NULL"

pdf_segmentmapping = get_sql_query(sql_query=sql_query, access_token=access_token, jdbc_url=jdbc_url).toPandas()
if pdf_segmentmapping.empty:
  dbutils.notebook.exit("No segment mapping data found")

# display(pdf_segmentmapping)

# COMMAND ----------

# DBTITLE 1,Get Reference Portfolio
# Read the most recent Reference Portfolio data
df_referenceportfolio_run = spark.sql(f"SELECT * \
                                  FROM " + env_config.get("common.ear_forecast_rda_run.rda_run_table") + " \
                                  WHERE Process_Name = 'Reference Portfolio' \
                                  ORDER BY Ingestion_TS DESC \
                                  LIMIT 1")

if(df_referenceportfolio_run.count() > 0):
  refport_source_file = df_referenceportfolio_run.first()['Source_File']
  refport_ingestion_ts = str(df_referenceportfolio_run.first()['Ingestion_TS'])
else:
  dbutils.notebook.exit(f"No Reference Portfolio data found in {env_config.get('common.ear_forecast_rda_run.rda_run_table')}")

refportquery = f"SELECT Liability_Segment_Name, UPPER(Currency_Code) AS Currency_Code, \
                        CASE WHEN UPPER(Curve_Name) = 'BIG' THEN 'BB' ELSE UPPER(Curve_Name) END AS Curve_Name, \
                        Tenor, ROUND(RefPortValue, 6) RefPortValue \
                FROM {env_config.get("ingest.file.ear_reference_portfolio.raw_table")} \
                WHERE Source_File = '{refport_source_file}' AND Ingestion_TS = '{refport_ingestion_ts}' \
                      AND UPPER(Curve_Name) IN ('GOVT', 'AAA', 'AA', 'A', 'BBB', 'BB', 'BIG')"

df_referenceportfolio = spark.sql(refportquery)
df_referenceportfolio.createOrReplaceTempView("df_referenceportfolio_forblended")

print(f"Reference Portfolio Source File: {refport_source_file} / Ingestion TS: {refport_ingestion_ts}")

# COMMAND ----------

# DBTITLE 1,Get Parcurve

# Read the Par Curve data

if(spark.catalog.tableExists(env_config.get('curation.ear_forecasting.curation_table.rates'))):
  df_parcurve_run = spark.sql(f"SELECT r.Source_File, r.Ingestion_TS, pc.Reporting_Date \
                                  FROM " + env_config.get("common.ear_forecast_rda_run.rda_run_table") + " r \
                                        INNER JOIN " + env_config.get('ingest.file.ear_par_curve.raw_table') + " pc ON r.Source_File = pc.Source_File \
                                            AND r.Ingestion_TS = pc.Ingestion_TS \
                                  WHERE Process_Name = 'Par Curve' \
                                        AND to_Timestamp(pc.Reporting_Date) NOT IN (SELECT DISTINCT Date FROM " + env_config.get('curation.ear_forecasting.curation_table.rates') + ") \
                                        AND pc.Reporting_Date > '2026-06-01' \
                                  GROUP BY r.Source_File, r.Ingestion_TS, pc.Reporting_Date \
                                  ORDER BY pc.Reporting_Date ASC, Ingestion_TS DESC \
                                  LIMIT 1")
else:
  df_parcurve_run = spark.sql(f"SELECT r.Source_File, r.Ingestion_TS, pc.Reporting_Date \
                                  FROM " + env_config.get("common.ear_forecast_rda_run.rda_run_table") + " r \
                                        INNER JOIN " + env_config.get('ingest.file.ear_par_curve.raw_table') + " pc ON r.Source_File = pc.Source_File \
                                            AND r.Ingestion_TS = pc.Ingestion_TS \
                                  WHERE Process_Name = 'Par Curve' \
                                        AND pc.Reporting_Date > '2026-06-01' \
                                  GROUP BY r.Source_File, r.Ingestion_TS, pc.Reporting_Date \
                                  ORDER BY pc.Reporting_Date ASC, Ingestion_TS DESC \
                                  LIMIT 1")

if(df_parcurve_run.count() > 0):
  parcurve_source_file = df_parcurve_run.first()['Source_File']
  parcurve_ingestion_ts = str(df_parcurve_run.first()['Ingestion_TS'])
  parcurve_reporting_date = str(df_parcurve_run.first()['Reporting_Date'])
else:
  dbutils.notebook.exit(f"No new Par Curve data found in {env_config.get('common.ear_forecast_rda_run.rda_run_table')}")

previousQuarterEnd = get_previous_quarter_end_date(datetime.strptime(parcurve_reporting_date, '%Y-%m-%d'))

df_previous_parcurve_run = spark.sql(f"SELECT Source_File, Ingestion_TS \
                                     FROM {env_config.get('ingest.file.ear_par_curve.raw_table')} \
                                     WHERE Date(Reporting_Date) <= '{previousQuarterEnd}' ORDER BY Reporting_Date DESC, Ingestion_TS DESC LIMIT 1")

if(df_previous_parcurve_run.count() > 0):
    previous_parcurve_source_file = df_previous_parcurve_run.first()['Source_File']
    previous_parcurve_ingestion_ts = str(df_previous_parcurve_run.first()['Ingestion_TS'])

    parcurvequery = f"SELECT UPPER(CPC.Currency_Code) AS Currency_Code, \
                                CASE WHEN UPPER(CPC.Curve_Name) = 'BIG' THEN 'BB' ELSE UPPER(CPC.Curve_Name) END AS Curve_Name, \
                                CPC.Tenor, ROUND((COALESCE(CPC.ParCurveValue, 0) - COALESCE(PPC.ParCurveValue, 0)) * 100, 4) AS ParCurveValue \
                        FROM (SELECT  * \
                            FROM {env_config.get("ingest.file.ear_par_curve.raw_table")} \
                            WHERE Source_File = '{parcurve_source_file}' \
                                    AND  Ingestion_TS = '{parcurve_ingestion_ts}' AND UPPER(Curve_Name) IN ('GOVT', 'AAA', 'AA', 'A', 'BBB', 'BB', 'BIG')) CPC \
                            LEFT JOIN (SELECT * \
                                        FROM    {env_config.get("ingest.file.ear_par_curve.raw_table")} \
                                        WHERE   Source_File = '{previous_parcurve_source_file}' \
                                                AND Ingestion_TS = '{previous_parcurve_ingestion_ts}' \
                                                AND UPPER(Curve_Name) IN ('GOVT', 'AAA', 'AA', 'A', 'BBB', 'BB', 'BIG')) PPC \
                                                    ON CPC.Currency_Code = PPC.Currency_Code AND CPC.Curve_Name = PPC.Curve_Name AND CPC.Tenor = PPC.Tenor"

else:
    dbutils.notebook.exit(f"Par Curve data for previous quarter end not found in {env_config.get('common.ear_forecast_rda_run.rda_run_table')}")

df_parcurve = spark.sql(parcurvequery)
df_parcurve.createOrReplaceTempView("df_parcurve_forblended")

print(f"Current Par Curve Source File: {parcurve_source_file} / Ingestion TS: {parcurve_ingestion_ts}")
print(f"Previous Par Curve Source File: {previous_parcurve_source_file} / Ingestion TS: {previous_parcurve_ingestion_ts}")

# COMMAND ----------

# DBTITLE 1,Get GAM Senstitivities Info
# Get SourceFile and RunKey of the most recent GAM Sensitivities Part 1

sql_query = f"SELECT TOP 1 Run_Key, InputFileName FROM {env_config.get("env_table_prefix")}Fact_Run \
              WHERE Process_Name = 'Consolidated Sensitivities Results Part 1' \
              ORDER BY Process_Start_Date DESC"

access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                            client_id=env_config.get("secrets.client_id"), 
                            client_secret=env_config.get("secrets.client_secret"))

df_run = get_sql_query(sql_query=sql_query, access_token=access_token, jdbc_url=jdbc_url)
if(df_run.count() > 0):
    gam_runkey_part1 = df_run.first()['Run_Key']
    gam_source_file_part1 = df_run.first()['InputFileName']
else:
    dbutils.notebook.exit(f"Consolidated Sensitivities Results Part 1 data not found in {env_config.get('env_table_prefix')}Fact_Run")

# Get SourceFile and RunKey the most recent GAM Sensitivities Part 2

sql_query = f"SELECT TOP 1 Run_Key, InputFileName FROM {env_config.get("env_table_prefix")}Fact_Run \
              WHERE Process_Name = 'Consolidated Sensitivities Results Part 2' \
              ORDER BY Process_Start_Date DESC"

access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                            client_id=env_config.get("secrets.client_id"), 
                            client_secret=env_config.get("secrets.client_secret"))

df_run = get_sql_query(sql_query=sql_query, access_token=access_token, jdbc_url=jdbc_url)
if(df_run.count() > 0):
    gam_runkey_part2 = df_run.first()['Run_Key']
    gam_source_file_part2 = df_run.first()['InputFileName']
else:
    dbutils.notebook.exit(f"Consolidated Sensitivities Results Part 2 data not found in {env_config.get('env_table_prefix')}Fact_Run")

print(f"GAM Sensitivities Part 1 Source File: {gam_source_file_part1} / Run Key: {gam_runkey_part1}")
print(f"GAM Sensitivities Part 2 Source File: {gam_source_file_part2} / Run Key: {gam_runkey_part2}")

# COMMAND ----------

# DBTITLE 1,Columns Initiation
blended_columns = {
    'Lowest_Level_Portfolio_Name': pd.Series(dtype='str'),
    'Currency_Code': pd.Series(dtype='str'),
    'Tenor': pd.Series(dtype='int'),
    'Other_Rate_Change': pd.Series(dtype='float'),
    'RF_Rate_Change': pd.Series(dtype='float'),
    'Blended_Corporate_Spread_Change': pd.Series(dtype='float')
}

# COMMAND ----------

# DBTITLE 1,Blending
pdf_BlendingMarketInputs = pd.DataFrame()

blended_query = "SELECT pc.Currency_Code, pc.Tenor, rf.Liability_Segment_Name, SUM(pc.ParCurveValue) AS ParCurveValue, \
                        SUM(rf.RefPortValue) AS RefPortValue, ROUND(SUM(pc.ParCurveValue * rf.RefPortValue), 4) AS Blended \
                    FROM    df_parcurve_forblended AS pc \
                            LEFT JOIN df_referenceportfolio_forblended AS rf ON pc.Currency_Code = rf.Currency_Code \
                                                                            AND pc.Tenor = rf.Tenor \
                                                                            AND pc.Curve_Name = rf.Curve_Name \
                    WHERE   *criteria* \
                    GROUP BY pc.Currency_Code, pc.Tenor, rf.Liability_Segment_Name"

criteria = ""

for segmentmapping_row in pdf_segmentmapping.itertuples():      
      
    if(segmentmapping_row.Liability_Segment_Name != 'NULL'):
        criteria = f"UPPER(rf.Liability_Segment_Name) LIKE '{str(segmentmapping_row.Liability_Segment_Name).replace("'", "''").upper()}' \
                                AND UPPER(pc.Currency_Code) LIKE '{segmentmapping_row.Currency_Code.upper()}'"
    else:
        criteria = f"UPPER(rf.Liability_Segment_Name) LIKE '%RISK%FREE%' \
                                AND UPPER(pc.Currency_Code) LIKE '{segmentmapping_row.Currency_Code.upper()}'"
      
    df_blended = spark.sql(blended_query.replace('*criteria*', criteria))

    if((df_blended.count() == 0) and criteria.find('%RISK%FREE%') == -1):
        criteria = f"UPPER(rf.Liability_Segment_Name) LIKE '%RISK%FREE%' \
                                AND UPPER(pc.Currency_Code) LIKE '{segmentmapping_row.Currency_Code.upper()}'"
      
        df_blended = spark.sql(blended_query.replace('*criteria*', criteria))        

    if(df_blended.count() > 0):

        print(f"Blending Rates for {segmentmapping_row.Lowest_Level_Portfolio_Name} --- " + 
                f"{segmentmapping_row.Currency_Code} ({int(segmentmapping_row.Index) + 1}/{len(pdf_segmentmapping)})")
        for tenor in pdf_config_tenor.itertuples():
        
            pdf_Blended_Rows = pd.DataFrame(columns=blended_columns)
            pdf_Blended_Rows['Tenor'] = [tenor.Tenor]
            pdf_Blended_Rows['Lowest_Level_Portfolio_Name'] = segmentmapping_row.Lowest_Level_Portfolio_Name
            pdf_Blended_Rows['Currency_Code'] = segmentmapping_row.Currency_Code
            pdf_Blended_Rows['Other_Rate_Change'] = 0
        
            if (df_parcurve.where(f"Currency_Code = '{segmentmapping_row.Currency_Code}' AND Tenor = '{tenor.Tenor}' AND Curve_Name = 'GOVT'").count() > 0): 
                pdf_Blended_Rows['RF_Rate_Change'] = df_parcurve.where(f"Currency_Code = '{segmentmapping_row.Currency_Code}' AND Tenor = '{tenor.Tenor}' AND Curve_Name = 'GOVT'").first()['ParCurveValue']
            if (df_blended.where(f"Tenor = '{tenor.Tenor}'").count() > 0):
                pdf_Blended_Rows['Blended_Corporate_Spread_Change'] = df_blended.where(f"Tenor = '{tenor.Tenor}'").first()['Blended']
        
            pdf_BlendingMarketInputs = pd.concat([pdf_BlendingMarketInputs, pdf_Blended_Rows], ignore_index=True)
    
    else:
        print(f"No blended rates found for {segmentmapping_row.Lowest_Level_Portfolio_Name} --- " + 
                f"{segmentmapping_row.Currency_Code} ({int(segmentmapping_row.Index) + 1}/{len(pdf_segmentmapping)})")

pdf_BlendingMarketInputs['Other_RF'] = pdf_BlendingMarketInputs['Other_Rate_Change'].astype(float) + \
                                          pdf_BlendingMarketInputs['RF_Rate_Change'].astype(float)
pdf_BlendingMarketInputs['Total_Rate_Change_Base'] = pdf_BlendingMarketInputs['Other_Rate_Change'].astype(float) + \
                                          pdf_BlendingMarketInputs['RF_Rate_Change'].astype(float) + \
                                          pdf_BlendingMarketInputs['Blended_Corporate_Spread_Change'].astype(float)
pdf_BlendingMarketInputs['Total_Rate_Change_+50bps'] = pdf_BlendingMarketInputs['Total_Rate_Change_Base'] + 50
pdf_BlendingMarketInputs['Total_Rate_Change_-50bps'] = pdf_BlendingMarketInputs['Total_Rate_Change_Base'] - 50
pdf_BlendingMarketInputs['Total_Rate_Change_+100bps'] = pdf_BlendingMarketInputs['Total_Rate_Change_Base'] + 100
pdf_BlendingMarketInputs['Total_Rate_Change_-100bps'] = pdf_BlendingMarketInputs['Total_Rate_Change_Base'] - 100
pdf_BlendingMarketInputs['Total_Rate_Change_+200bps'] = pdf_BlendingMarketInputs['Total_Rate_Change_Base'] + 200
pdf_BlendingMarketInputs['Total_Rate_Change_-200bps'] = pdf_BlendingMarketInputs['Total_Rate_Change_Base'] - 200             

# display(pdf_BlendingMarketInputs)


# COMMAND ----------

# DBTITLE 1,ModelInputs
def get_model_inputs(runkey_part1, runkey_part2, pdf_config_modelinputs, scenarios, access_token):
        pdf_modelinputs = pd.DataFrame()

        for modelinput_row in pdf_config_modelinputs.itertuples():        
                sql_query = f"SELECT TOP 100 PERCENT C.Country_Name, TI.Tax_Indicator_Name, LLP.Lowest_Level_Portfolio_Name, \
                                        BSC.Balance_Sheet_Component_Name, IFRS.IFRS_Earnings_Component_Name, \
                                        S.Scenario_Name, PS.Par_Status_Name, CU.Currency_Alpha_Code AS Currency_Code, FA.Amount AS [{modelinput_row.ForecastingInput}] \
                                FROM	{env_config.get("env_table_prefix")}Fact_Actuals FA	\
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Country C ON FA.Country_Key = C.Country_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Tax_Indicator TI ON FA.Tax_Indicator_Key = TI.Tax_Indicator_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Lowest_Level_Portfolio LLP ON FA.Lowest_Level_Portfolio_Key = LLP.Lowest_Level_Portfolio_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Balance_Sheet_Component BSC ON FA.Balance_Sheet_Component_Key = BSC.Balance_Sheet_Component_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_IFRS_Earnings_Component IFRS ON FA.IFRS_Earnings_Component_Key = IFRS.IFRS_Earnings_Component_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Scenario S ON FA.Scenario_Key = S.Scenario_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Par_Status PS ON FA.Par_Status_Key = PS.Par_Status_Key \
                                        INNER JOIN {env_config.get("env_table_prefix")}Dim_Currency CU ON FA.Currency_Key = CU.Currency_Key \
                                WHERE   FA.Run_Key IN ({runkey_part1}, {runkey_part2}) \
                                        AND TI.Tax_Indicator_Name = '{modelinput_row.TaxIndicator}' \
                                        AND BSC.Balance_Sheet_Component_Name = '{modelinput_row.BalanceSheetComponent}' \
                                        AND IFRS.IFRS_Earnings_Component_Name = '{modelinput_row.IFRSEarningsComponent}' \
                                        AND S.Scenario_Name IN ({scenarios}) \
                                ORDER BY C.Country_Name, TI.Tax_Indicator_Name, LLP.Lowest_Level_Portfolio_Name, \
                                        BSC.Balance_Sheet_Component_Name, IFRS.IFRS_Earnings_Component_Name, \
                                        S.Scenario_Name, PS.Par_Status_Name, CU.Currency_Alpha_Code"
        
                df_actuals = get_sql_query(sql_query=sql_query, access_token=access_token, jdbc_url=jdbc_url)

                if df_actuals.count() > 0:
                        if not pdf_modelinputs.empty:
                                pdf_modelinputs = pd.concat([pdf_modelinputs, df_actuals.toPandas()], axis=0, ignore_index=True)
                        else:
                                pdf_modelinputs = df_actuals.toPandas()

        for config_modelinputs_row in pdf_config_modelinputs.itertuples():
                pdf_modelinputs[config_modelinputs_row.ForecastingInput] = pdf_modelinputs[config_modelinputs_row.ForecastingInput].astype('float64')        

        pdf_modelinputs = pdf_modelinputs.groupby(['Country_Name', 'Lowest_Level_Portfolio_Name', 'Scenario_Name', 'Currency_Code']).sum(numeric_only=True).reset_index()

        return pdf_modelinputs

# COMMAND ----------

# DBTITLE 1,Forecating
# display(pdf_config_modelinputs)
pdf_modelinput_all = pd.DataFrame()
pdf_sensitivitygrid_all = pd.DataFrame()
pdf_interpolation_all = pd.DataFrame()
pdf_forecast_all = pd.DataFrame()

for forecast in pdf_config_forecastdetails.itertuples():
    pdf_config_mi = pdf_config_modelinputs[pdf_config_modelinputs['ForecastType'] == forecast.ForecastType]
    periods = [-200, -100, -50, 0, 50, 100, 200]    

    print(f"{forecast.ForecastType} - Fetching Model Inputs....")
    
    access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                            client_id=env_config.get("secrets.client_id"), 
                            client_secret=env_config.get("secrets.client_secret"))
    pdf_modelinput = get_model_inputs(runkey_part1=gam_runkey_part1, 
                                      runkey_part2=gam_runkey_part2, 
                                      pdf_config_modelinputs=pdf_config_mi,
                                      scenarios=scenarios,
                                      access_token=access_token)
                
    print(f"{forecast.ForecastType} - Building Sensitivity Grid....")
    pdf_sensitivitygrid = get_sensitivity_grid(pdf_modelinputs=pdf_modelinput, 
                                               pdf_segmentmapping=pdf_segmentmapping, 
                                               pdf_config_modelinputs=pdf_config_mi, 
                                               pdf_config_sensitivitygrid=pdf_config_sensitivitygrid)    
    print(f"{forecast.ForecastType} - Computing Interpolation....")
    pdf_interpolation = get_interpolation(pdf_sensitivitygrid=pdf_sensitivitygrid, 
                                          pdf_blendingmarketinputs=pdf_BlendingMarketInputs, 
                                          periods=periods)
    
    print(f"{forecast.ForecastType} - Computing rates....")
    pdf_forecast = get_forecast(pdf_interpolation=pdf_interpolation, 
                                pdf_config_forecastdetails=forecast)

    pdf_modelinput['ForecastType'] = forecast.ForecastType
    pdf_modelinput_all = pd.concat([pdf_modelinput_all, format_model_inputs(pdf_modelinput)], ignore_index=True)

    pdf_sensitivitygrid['ForecastType'] = forecast.ForecastType
    pdf_sensitivitygrid_all = pd.concat([pdf_sensitivitygrid_all, pdf_sensitivitygrid], ignore_index=True)

    pdf_interpolation['ForecastType'] = forecast.ForecastType
    pdf_interpolation_all = pd.concat([pdf_interpolation_all, pdf_interpolation], ignore_index=True)

    pdf_forecast_all = pd.concat([pdf_forecast_all, pdf_forecast], ignore_index=True)

    print(f"")


# COMMAND ----------

# DBTITLE 1,Call Notebook for Setting Dimension Keys
# MAGIC %run ../../common/nb_set_rda_dimension_keys

# COMMAND ----------

# DBTITLE 1,Save to Delta Tables
Source_File = f"GAM Sensitivities Part 1: {gam_source_file_part1}, RunKey Part 1: {str(gam_runkey_part1)} / GAM Sensitivities Part 2: {gam_source_file_part2}, RunKey Part 2: {str(gam_runkey_part2)}"
if len(pdf_forecast_all) > 0:    

    df_run = spark.createDataFrame(data=[('IR Ear RF Daily Forecasting', Source_File, None, datetoday, None, None)], 
                                    schema=StructType([StructField("Process_Name", StringType(), True),
                                                StructField("Source_File", StringType(), True),
                                                StructField("Ingestion_TS", TimestampType(), True),
                                                StructField("Curation_TS", TimestampType(), True),
                                                StructField("Consumption_TS", TimestampType(), True),
                                                StructField("Consumption_Remarks", StringType(), True)]))

    # display(df_run)

    pdf_BlendingMarketInputs['Reference_Portfolio'] = refport_source_file
    pdf_BlendingMarketInputs['Reference_Portfolio_Ingestion_TS'] = refport_ingestion_ts
    pdf_BlendingMarketInputs['Par_Curve'] = parcurve_source_file
    pdf_BlendingMarketInputs['Par_Curve_Ingestion_TS'] = refport_ingestion_ts
    pdf_BlendingMarketInputs['Source_File'] = Source_File
    pdf_BlendingMarketInputs['Curation_TS'] = datetoday
    # display(pdf_BlendingMarketInputs)

    pdf_modelinput_all['Source_File'] = Source_File
    pdf_modelinput_all['Curation_TS'] = datetoday
    # display(pdf_modelinput_all)

    pdf_sensitivitygrid_all['Source_File'] = Source_File
    pdf_sensitivitygrid_all['Curation_TS'] = datetoday
    # display(pdf_sensitivitygrid_all)

    pdf_interpolation_all['Source_File'] = Source_File
    pdf_interpolation_all['Curation_TS'] = datetoday
    # display(pdf_interpolation_all)

    pdf_forecast_all['Source_File'] = Source_File
    pdf_forecast_all['Curation_TS'] = datetoday
    pdf_forecast_all['Date'] = datetime.strptime(str(parcurve_reporting_date)[0:10], '%Y-%m-%d')
    pdf_forecast_all['Reporting_Date'] = get_previous_quarter_end_date(datetime.strptime(str(parcurve_reporting_date)[0:10], '%Y-%m-%d')).strftime('%Y-%m-%d')
    
    print(f"Setting Dim Keys....")

    access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                                client_id=env_config.get("secrets.client_id"), 
                                client_secret=env_config.get("secrets.client_secret"))

    pdf_forecast_all = set_dimension_keys(pdf_raw=pdf_forecast_all, 
                                    env_table_prefix=env_config.get("env_table_prefix"), 
                                    access_token=access_token, 
                                    jdbc_url=jdbc_url)
    
    spark.createDataFrame(pdf_BlendingMarketInputs) \
        .write \
        .mode("append") \
        .format("delta") \
        .option("path", env_config.get("curation.ear_forecasting.curation_ext_table_loc.blended_rates")) \
        .saveAsTable(env_config.get("curation.ear_forecasting.curation_table.blended_rates"))

    spark.createDataFrame(pdf_modelinput_all) \
        .write \
        .mode("append") \
        .format("delta") \
        .option("path", env_config.get("curation.ear_forecasting.curation_ext_table_loc.model_input")) \
        .saveAsTable(env_config.get("curation.ear_forecasting.curation_table.model_input"))       

    spark.createDataFrame(pdf_sensitivitygrid_all) \
        .write \
        .mode("append") \
        .format("delta") \
        .option("path", env_config.get("curation.ear_forecasting.curation_ext_table_loc.sensitivity_grid")) \
        .saveAsTable(env_config.get("curation.ear_forecasting.curation_table.sensitivity_grid"))

    spark.createDataFrame(pdf_interpolation_all) \
        .write \
        .mode("append") \
        .format("delta") \
        .option("path", env_config.get("curation.ear_forecasting.curation_ext_table_loc.interpolation")) \
        .saveAsTable(env_config.get("curation.ear_forecasting.curation_table.interpolation"))

    df_forecast_all = spark.createDataFrame(pdf_forecast_all)
    df_forecast_all = df_forecast_all.withColumn('Amount', col('Amount').cast(DecimalType(28,15)))

    df_forecast_all.write \
        .mode("append") \
        .format("delta") \
        .option("path", env_config.get("curation.ear_forecasting.curation_ext_table_loc.rates")) \
        .option("mergeSchema", "true") \
        .saveAsTable(env_config.get("curation.ear_forecasting.curation_table.rates"))

    df_run.write \
        .mode("append") \
        .format("delta") \
        .option("path", env_config.get("common.ear_forecast_rda_run.rda_run_ext_table_loc")) \
        .saveAsTable(env_config.get("common.ear_forecast_rda_run.rda_run_table"))