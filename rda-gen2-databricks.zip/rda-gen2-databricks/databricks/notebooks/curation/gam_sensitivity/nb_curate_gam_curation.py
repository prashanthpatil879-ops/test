# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from datetime import datetime
from zoneinfo import ZoneInfo

import os
import sys
import pandas as pd
import numpy as np
import re

from rda.utils.sqlfunctions import get_sql_token, get_sql_dimension

from pyspark.sql.functions import col
from pyspark.sql.types import DecimalType

# COMMAND ----------

#Read config file sheet <ColumnIndex> to be used for the coordinates of data to be extracted
pdf_columnindex = read_excel(env_config.get("common.config_files.gam"), sheet_name='ColumnIndex', header=0)
# pdf_columnindex = pdf_columnindex[pdf_columnindex['WithFormula'] == True]
# display(pdf_columnindex)

#Read config file sheet <ColumnIndexFormula> to be used for the coordinates of data to be extracted with formulas
pdf_columnindexformula = read_excel(env_config.get("common.config_files.gam"), sheet_name='ColumnIndexFormula', header=0)
# display(pdf_columnindexformula)

#Read config file sheet <CountryAlias> to be used for countries aliases
pdf_countryalias = read_excel(env_config.get("common.config_files.config"), sheet_name='CountryAlias', header=0)
# display(pdf_countryalias)

# COMMAND ----------

# MAGIC %run ../../common/nb_set_rda_dimension_keys

# COMMAND ----------

pdf_runs = spark.sql("SELECT    *  \
                     FROM " + env_config.get("common.ear_forecast_rda_run.rda_run_table") + " \
                     WHERE Curation_TS is NULL AND Process_Name LIKE 'Consolidated Sensitivities Results%' \
                     ORDER BY Ingestion_TS").toPandas()
# display(pdf_runs)

for run_row in pdf_runs.iterrows():
    print(run_row[1]['Source_File'] + ' --- ' + str(run_row[1]['Ingestion_TS']))

    pdf_raw = spark.sql("SELECT * \
                        FROM " + env_config.get("ingest.file.gam_sensitivities.raw_table") + " \
                        WHERE Source_File = '" + run_row[1]['Source_File'] + "' \
                        AND Ingestion_TS = '" + str(run_row[1]['Ingestion_TS']) + "' \
                        AND Scenario_Name <> '0' \
                        ORDER BY Country_Name, Tax_Indicator_Name, Lowest_Level_Portfolio_Name, \
                            Balance_Sheet_Component_Name, IFRS_Earnings_Component_Name, Scenario_Name").toPandas()    
    
    datetoday = datetime.now(ZoneInfo("UTC"))
    
    print(len(pdf_raw))

    if(len(pdf_raw) > 0):
    
        pdf_formulacolumns = pdf_columnindex[pdf_columnindex['WithFormula'] == True]
        for formulacolumns_row in pdf_formulacolumns.iterrows():
            print('     ' + formulacolumns_row[1]['TaxIndicator'] + ' --- ' + formulacolumns_row[1]['BalanceSheetComponent'] + ' --- ' + formulacolumns_row[1]['IFRSEarningsComponent'])

            pdf_formula =  pdf_columnindexformula[pdf_columnindexformula['ProcessType'] == formulacolumns_row[1]['ProcessType']]
            pdf_formula = pdf_formula[pdf_formula['TaxIndicator'] == formulacolumns_row[1]['TaxIndicator']]
            pdf_formula = pdf_formula[pdf_formula['BalanceSheetComponent'] == formulacolumns_row[1]['BalanceSheetComponent']]
            pdf_formula = pdf_formula[pdf_formula['IFRSEarningsComponent'] == formulacolumns_row[1]['IFRSEarningsComponent']]
                    
            scenario_formula = ''
            scenario_operator = ''
            output_row = pd.DataFrame()
            
            for formula_row in pdf_formula.iterrows():                        
                
                if formula_row[1]['Operator'] == '+':
                    scenario_operator = '+'
                else:
                    scenario_operator = '-'

                if scenario_formula != '':
                    scenario_formula = scenario_formula + ' ' + scenario_operator + ' col' + str(formula_row[1]['ValueIndex'])
                else:
                    scenario_formula = 'col' + str(formula_row[1]['ValueIndex'])

                pdf_formulasource = pdf_columnindex[pdf_columnindex['ScenarioAmount'] == formula_row[1]['ValueIndex']]
                print('          ' + formula_row[1]['TaxIndicator'] + ' --- ' + 
                    formula_row[1]['BalanceSheetComponent'] + ' --- ' + formula_row[1]['IFRSEarningsComponent'] + ' --- ' + 
                    formula_row[1]['Operator'] + ' --- ' + str(formula_row[1]['ValueIndex']) + ' --- ' +
                    pdf_formulasource.head(1)['TaxIndicator'].values[0] + ' --- ' + 
                    pdf_formulasource.head(1)['BalanceSheetComponent'].values[0] + ' --- ' + 
                    pdf_formulasource.head(1)['IFRSEarningsComponent'].values[0] + ' --- ' + str(pdf_formulasource.head(1)['ScenarioAmount'].values[0]))
                
                pdf_formulavalue = pdf_raw[(pdf_raw["Tax_Indicator_Name"] == str(pdf_formulasource.head(1)['TaxIndicator'].values[0])) &
                                                (pdf_raw['Balance_Sheet_Component_Name'] == str(pdf_formulasource.head(1)['BalanceSheetComponent'].values[0])) &
                                                (pdf_raw['IFRS_Earnings_Component_Name'] == str(pdf_formulasource.head(1)['IFRSEarningsComponent'].values[0]))]
                
                # print(str(len(output_row)) + ' ' + str(len(pdf_formulavalue)))            

                # display(pdf_formulavalue)
                if output_row.empty:                
                    
                    output_row['Country_Name'] = pdf_formulavalue['Country_Name']
                    output_row['Lowest_Level_Portfolio_Name'] = pdf_formulavalue['Lowest_Level_Portfolio_Name']
                    output_row['Scenario_Name'] = pdf_formulavalue['Scenario_Name']
                    output_row['Currency_Name'] = pdf_formulavalue['Currency_Name']
                    output_row['Par_Status_Name'] = pdf_formulavalue['Par_Status_Name']
                    output_row['col' + str(formula_row[1]['ValueIndex'])] = pdf_formulavalue['Amount']
                    output_row['Source_File'] = pdf_formulavalue['Source_File']
                    output_row['Ingestion_TS'] = pdf_formulavalue['Ingestion_TS']
                    output_row['Reporting_Date'] = pdf_formulavalue['Reporting_Date']
                    output_row['HKUnsplit'] = pdf_formulavalue['HKUnsplit']
                    # display(output_row)

                else:
                    
                    pdf_formulavalue.rename(columns={'Amount': 'col' + str(formula_row[1]['ValueIndex'])}, inplace=True)
                    output_row = pd.merge(output_row, pdf_formulavalue, on=['Country_Name', 'Lowest_Level_Portfolio_Name', 'Scenario_Name', 'Currency_Name', 
                                                                            'Par_Status_Name', 'Source_File', 'Ingestion_TS', 'Reporting_Date', 'HKUnsplit'])
                    
                    # display(output_row)

            output_row['Amount'] = output_row.eval(scenario_formula)
            output_row['Tax_Indicator_Name'] = formulacolumns_row[1]['TaxIndicator']
            output_row['Balance_Sheet_Component_Name'] = formulacolumns_row[1]['BalanceSheetComponent']
            output_row['IFRS_Earnings_Component_Name'] = formulacolumns_row[1]['IFRSEarningsComponent']

            output_row = output_row[['Country_Name', 'Tax_Indicator_Name', 'Lowest_Level_Portfolio_Name', 'Balance_Sheet_Component_Name', 
                        'IFRS_Earnings_Component_Name', 'Scenario_Name', 'Currency_Name', 'Par_Status_Name', 'Amount', 
                        'Source_File', 'Ingestion_TS', 'Reporting_Date', 'HKUnsplit']]

            # display(output_row)
            print(len(output_row))
            pdf_raw = pd.concat([pdf_raw, output_row], ignore_index=True)   

            # display(output_row)

        pdf_raw = pdf_raw.fillna({'Amount': 0})
        pdf_raw['Amount'] = pdf_raw['Amount'] * 1000000        
        
        # pdf_raw['Par_Status_Name'] = pdf_raw['Par_Status_Name'].replace('0', np.nan)
        # pdf_raw['Par_Status_Name'] = pdf_raw['Par_Status_Name'].replace('?', np.nan)

        pdf_raw['Par_Status_Name'] = np.where(np.logical_or(pdf_raw['Par_Status_Name'] == '0', pdf_raw['Par_Status_Name'] == '?'), np.nan, pdf_raw['Par_Status_Name'])

        pdf_raw['Curation_TS'] = datetoday
        pdf_raw['Date'] = datetime.strptime(str(run_row[1]['Ingestion_TS'])[0:10], '%Y-%m-%d')

        jdbc_url = f"jdbc:sqlserver://{env_config.get("sqlmi.server")};databaseName={env_config.get("sqlmi.database")};encrypt=true;hostNameInCertificate=*.database.windows.net;"
        access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                                     client_id=env_config.get("secrets.client_id"), 
                                     client_secret=env_config.get("secrets.client_secret"))

        pdf_raw = set_dimension_keys(pdf_raw=pdf_raw, 
                                    env_table_prefix=env_config.get("env_table_prefix"), 
                                    access_token=access_token, 
                                    jdbc_url=jdbc_url, 
                                    pdf_countryalias=pdf_countryalias)

        #Get curated data from raw dataframe
        df_curated = spark.createDataFrame(pdf_raw[['Country_Key', 'Tax_Indicator_Key', 'Lowest_Level_Portfolio_Key', 'Balance_Sheet_Component_Key', 
                                'IFRS_Earnings_Component_Key', 'Scenario_Key', 'Currency_Key', 'Par_Status_Key', 'Amount', 
                                'Source_File', 'Curation_TS', 'Date_Key', 'Reporting_Date_Key', 'HKUnsplit']])
        
        df_curated = df_curated.withColumn('Amount', col('Amount').cast(DecimalType(28,15)))
        
        df_curated.write.mode("append") \
            .format("delta") \
            .option("mergeSchema", "true") \
            .option("path", env_config.get("curation.gam_sensitivities.curation_ext_table_loc")) \
            .saveAsTable(env_config.get("curation.gam_sensitivities.curation_table"))

    spark.sql(f"UPDATE {env_config.get("common.ear_forecast_rda_run.rda_run_table")} " +
                "SET Curation_TS = '" + str(datetoday) + "' " +
                "WHERE Process_Name = '" + run_row[1]['Process_Name'] + "' "+
                "AND Source_File = '" + run_row[1]['Source_File'] + "' " +
                "AND Ingestion_TS = '" + str(run_row[1]['Ingestion_TS']) + "'")
            
    print(len(pdf_raw))
    