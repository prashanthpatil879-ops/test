# Databricks notebook source
# MAGIC %run ../../common/nb_load_rda_package

# COMMAND ----------

#Import libraries
from pyspark.pandas import read_excel
from datetime import datetime
from zoneinfo import ZoneInfo

import os
import sys
import pandas as pd
import re

from rda.utils.sqlfunctions import get_sql_token, get_sql_dimension
from rda.utils.date_utils import get_previous_quarter_end_date

from pyspark.sql.functions import col
from pyspark.sql.types import DecimalType

# COMMAND ----------

#Read config file sheet <CountryAlias> to be used for countries aliases
pdf_countryalias = read_excel(env_config.get("common.config_files.config"), sheet_name='CountryAlias', header=0)
# display(pdf_countryalias)

# COMMAND ----------

# MAGIC %run ../../common/nb_set_rda_dimension_keys

# COMMAND ----------

pdf_runs = spark.sql("SELECT * FROM " + env_config.get("common.ear_forecast_rda_run.rda_run_table") + \
                        " WHERE Curation_TS is NULL AND Process_Name = 'ALM Sensitivities Forecast'").toPandas()
# display(pdf_runs)

for run_row in pdf_runs.iterrows():
    print(run_row[1]['Source_File'] + ' --- ' + str(run_row[1]['Ingestion_TS']))

    pdf_raw = spark.sql("SELECT * FROM " + env_config.get("ingest.file.alm.raw_table") + \
                        " WHERE Source_File = '" + run_row[1]['Source_File'] + "'" + 
                        " AND Ingestion_TS = '" + str(run_row[1]['Ingestion_TS']) + "' " +
                        " ORDER BY Country_Name, Tax_Indicator_Name, Lowest_Level_Portfolio_Name, Balance_Sheet_Component_Name, IFRS_Earnings_Component_Name, Scenario_Name").toPandas()    
    
    datetoday = datetime.now(ZoneInfo("UTC"))

    print(len(pdf_raw))
    if(len(pdf_raw) > 0):

        pdf_raw = pdf_raw.fillna({'Amount': 0})
        pdf_raw['Amount'] = pdf_raw['Amount'] * 1000000

        reportingdate = get_previous_quarter_end_date(datetime.strptime(pdf_raw['Forecast_Date'][0], '%Y-%m-%d').date()).strftime('%Y-%m-%d')
        pdf_raw['Reporting_Date'] = reportingdate
        pdf_raw['Date'] = datetime.strptime(str(pdf_raw['Forecast_Date'][0])[0:10], '%Y-%m-%d')        
        pdf_raw['Curation_TS'] = datetoday

        jdbc_url = f"jdbc:sqlserver://{env_config.get("sqlmi.server")};databaseName={env_config.get("sqlmi.database")};encrypt=true;hostNameInCertificate=*.database.windows.net;"
        access_token = get_sql_token(tenant_id=env_config.get("secrets.tenant_id"), 
                                    client_id=env_config.get("secrets.client_id"), 
                                    client_secret=env_config.get("secrets.client_secret"))

        pdf_raw = set_dimension_keys(pdf_raw=pdf_raw, 
                                    env_table_prefix=env_config.get("env_table_prefix"), 
                                    access_token=access_token, 
                                    jdbc_url=jdbc_url, 
                                    pdf_countryalias=pdf_countryalias)

        #Get curated data from raw dataframe
        df_curated = spark.createDataFrame(pdf_raw[['Country_Key', 'Tax_Indicator_Key', 'Lowest_Level_Portfolio_Key', 'Balance_Sheet_Component_Key', 
                                'IFRS_Earnings_Component_Key', 'Scenario_Key', 'Currency_Key', 'Amount', 
                                'Source_File', 'Curation_TS', 'Date_Key', 'Reporting_Date_Key']])

        df_curated = df_curated.withColumn('Amount', col('Amount').cast(DecimalType(28,15)))        
        
        df_curated.write.mode("append") \
            .format("delta") \
            .option("path", env_config.get("curation.alm.curation_ext_table_loc")) \
            .saveAsTable(env_config.get("curation.alm.curation_table"))

    spark.sql(f"UPDATE {env_config.get("common.ear_forecast_rda_run.rda_run_table")} " +
                "SET Curation_TS = '" + str(datetoday) + "' " +
                "WHERE Process_Name = '" + run_row[1]['Process_Name'] + "' "+
                "AND Source_File = '" + run_row[1]['Source_File'] + "' " +
                "AND Ingestion_TS = '" + str(run_row[1]['Ingestion_TS']) + "'")        
    
    # print(len(pdf_raw))