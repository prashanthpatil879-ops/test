# Databricks notebook source
# MAGIC %md
# MAGIC ### Adding "rda" root package to the python path

# COMMAND ----------

import os 
import sys
from pathlib import Path

try:
    import rda
except ImportError:
    notebook_path = str(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
    project_root = notebook_path[:notebook_path.rfind("/databricks/")]
    print(f"Project root: {project_root}")
    project_root_src = f"/Workspace{project_root}/databricks/src"
    print(f"Project root src: {project_root_src}")

    if project_root_src not in sys.path:
        sys.path.insert(0, project_root_src)

    import rda

# COMMAND ----------

from rda.commons.config_loader import EnvConfig
env_config = EnvConfig(dbutils)
print(f"Environment Config is loaded: {env_config.env}")

# COMMAND ----------

from rda.utils.logger import configure_logging
configure_logging(env_config.logging.level)