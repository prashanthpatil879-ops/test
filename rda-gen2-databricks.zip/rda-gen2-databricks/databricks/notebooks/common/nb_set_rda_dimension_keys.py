# Databricks notebook source
from rda.utils.sqlfunctions import get_sql_dimension
import pandas as pd

# COMMAND ----------

def set_dimension_keys(pdf_raw, env_table_prefix, access_token, jdbc_url, pdf_countryalias=None, drop_na_llp=False):
    for column_name in pdf_raw:
        if(column_name == 'Country_Name'):
            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Country', access_token=access_token, jdbc_url=jdbc_url)
            pdf_dim = df_dim.toPandas()

            pdf_dim_duplicate = pd.DataFrame()
            pdf_dim_duplicate['Country_Key'] = pdf_dim['Country_Key']
            pdf_dim_duplicate['Country_Name'] = pdf_dim['Country_Code']

            pdf_dim = pd.concat([pdf_dim, pdf_dim_duplicate])
            pdf_dim = pdf_dim.drop_duplicates(subset = ['Country_Name'])

            pdf_dim['Country_Name'] = pdf_dim['Country_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Country_Name'] = pdf_raw['Country_Name'].str.replace(" ", "").str.upper()

            if(pdf_countryalias is not None):
                pdf_countryalias['Country_Name'] = pdf_countryalias['Country_Name'].str.replace(" ", "").str.upper()
                pdf_raw['Country_Name'] = pdf_raw['Country_Name'] \
                                            .map(pdf_countryalias.set_index('Alias')['Country_Name'].to_dict()) \
                                            .fillna(pdf_raw['Country_Name'])                        

            pdf_raw['Country_Key'] = pdf_raw['Country_Name'].map(pdf_dim.set_index('Country_Name')['Country_Key'])
            pdf_raw = pdf_raw.fillna({'Country_Key': 0})
            pdf_raw['Country_Key'] = pdf_raw['Country_Key'].astype('Int32')

        if(column_name == 'Currency_Name'):
            df_dim = get_sql_dimension(dim_name=env_table_prefix + "Dim_Currency", access_token=access_token, jdbc_url=jdbc_url)
            pdf_dim = df_dim.toPandas()

            pdf_raw['Currency_Key'] = pdf_raw['Currency_Name'].map(pdf_dim.set_index('Currency_Name')['Currency_Key'])
            pdf_raw = pdf_raw.fillna({'Currency_Key': 0})
            pdf_raw['Currency_Key'] = pdf_raw['Currency_Key'].astype('Int32')

        if(column_name == 'Currency_Code'):
            df_dim = get_sql_dimension(dim_name=env_table_prefix + "Dim_Currency", access_token=access_token, jdbc_url=jdbc_url)
            pdf_dim = df_dim.toPandas()

            pdf_raw['Currency_Key'] = pdf_raw['Currency_Code'].map(pdf_dim.set_index('Currency_Alpha_Code')['Currency_Key'])
            pdf_raw = pdf_raw.fillna({'Currency_Key': 0})
            pdf_raw['Currency_Key'] = pdf_raw['Currency_Key'].astype('Int32')
        
        if(column_name == 'Tax_Indicator_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Tax_Indicator_Name'].unique()], ['Tax_Indicator_Name'])
            df_infile_dim = df_infile_dim.dropna()

            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Tax_Indicator', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Tax_Indicator_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()        

            pdf_dim['Tax_Indicator_Name'] = pdf_dim['Tax_Indicator_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Tax_Indicator_Name'] = pdf_raw['Tax_Indicator_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Tax_Indicator_Key'] = pdf_raw['Tax_Indicator_Name'].map(pdf_dim.set_index('Tax_Indicator_Name')['Tax_Indicator_Key'])
            pdf_raw = pdf_raw.fillna({'Tax_Indicator_Key': 0})
            pdf_raw['Tax_Indicator_Key'] = pdf_raw['Tax_Indicator_Key'].astype('Int32')

        if(column_name == 'Lowest_Level_Portfolio_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Lowest_Level_Portfolio_Name'].unique()], ['Lowest_Level_Portfolio_Name'])
            df_infile_dim = df_infile_dim.dropna()
            
            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Lowest_Level_Portfolio', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Lowest_Level_Portfolio_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Lowest_Level_Portfolio_Name'] = pdf_dim['Lowest_Level_Portfolio_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Lowest_Level_Portfolio_Name'] = pdf_raw['Lowest_Level_Portfolio_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Lowest_Level_Portfolio_Key'] = pdf_raw['Lowest_Level_Portfolio_Name'].map(pdf_dim.set_index('Lowest_Level_Portfolio_Name')['Lowest_Level_Portfolio_Key'])

            if(drop_na_llp):
                pdf_raw = pdf_raw.dropna(subset=['Lowest_Level_Portfolio_Key'])
                pdf_raw = pdf_raw.reset_index()

            pdf_raw = pdf_raw.fillna({'Lowest_Level_Portfolio_Key': 0})
            pdf_raw['Lowest_Level_Portfolio_Key'] = pdf_raw['Lowest_Level_Portfolio_Key'].astype('Int32')

        if(column_name == 'Balance_Sheet_Component_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Balance_Sheet_Component_Name'].unique()], ['Balance_Sheet_Component_Name'])
            df_infile_dim = df_infile_dim.dropna()

            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Balance_Sheet_Component', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Balance_Sheet_Component_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Balance_Sheet_Component_Name'] = pdf_dim['Balance_Sheet_Component_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Balance_Sheet_Component_Name'] = pdf_raw['Balance_Sheet_Component_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Balance_Sheet_Component_Key'] = pdf_raw['Balance_Sheet_Component_Name'].map(pdf_dim.set_index('Balance_Sheet_Component_Name')['Balance_Sheet_Component_Key'])
            pdf_raw = pdf_raw.fillna({'Balance_Sheet_Component_Key': 0})
            pdf_raw['Balance_Sheet_Component_Key'] = pdf_raw['Balance_Sheet_Component_Key'].astype('Int32')
        
        if(column_name == 'IFRS_Earnings_Component_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['IFRS_Earnings_Component_Name'].unique()], ['IFRS_Earnings_Component_Name'])
            df_infile_dim = df_infile_dim.dropna()
            
            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_IFRS_Earnings_Component', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='IFRS_Earnings_Component_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['IFRS_Earnings_Component_Name'] = pdf_dim['IFRS_Earnings_Component_Name'].str.replace(" ", "").str.upper()
            pdf_raw['IFRS_Earnings_Component_Name'] = pdf_raw['IFRS_Earnings_Component_Name'].str.replace(" ", "").str.upper()

            pdf_raw['IFRS_Earnings_Component_Key'] = pdf_raw['IFRS_Earnings_Component_Name'].map(pdf_dim.set_index('IFRS_Earnings_Component_Name')['IFRS_Earnings_Component_Key'])
            pdf_raw = pdf_raw.fillna({'IFRS_Earnings_Component_Key': 0})
            pdf_raw['IFRS_Earnings_Component_Key'] = pdf_raw['IFRS_Earnings_Component_Key'].astype('Int32')

        if(column_name == 'Scenario_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Scenario_Name'].unique()], ['Scenario_Name'])
            df_infile_dim = df_infile_dim.dropna()
            
            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Scenario', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Scenario_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Scenario_Name'] = pdf_dim['Scenario_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Scenario_Name'] = pdf_raw['Scenario_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Scenario_Key'] = pdf_raw['Scenario_Name'].map(pdf_dim.set_index('Scenario_Name')['Scenario_Key'])
            pdf_raw = pdf_raw.fillna({'Scenario_Key': 0})
            pdf_raw['Scenario_Key'] = pdf_raw['Scenario_Key'].astype('Int32')

        if(column_name == 'Par_Status_Name'):
            pdf_raw = pdf_raw.fillna({'Par_Status_Name': 'NULL'})
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Par_Status_Name'].unique()], ['Par_Status_Name'])
            df_infile_dim = df_infile_dim.dropna()

            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Par_Status', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Par_Status_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Par_Status_Name'] = pdf_dim['Par_Status_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Par_Status_Name'] = pdf_raw['Par_Status_Name'].str.replace(" ", "").str.upper()
            
            pdf_raw['Par_Status_Key'] = pdf_raw['Par_Status_Name'].map(pdf_dim.set_index('Par_Status_Name')['Par_Status_Key'])
            pdf_raw = pdf_raw.fillna({'Par_Status_Key': 0})
            pdf_raw['Par_Status_Key'] = pdf_raw['Par_Status_Key'].astype('Int32')

        if(column_name == 'Date'):
            df_dim = get_sql_dimension(dim_name=env_table_prefix + 'Dim_Date', access_token=access_token, jdbc_url=jdbc_url)
            pdf_dim = df_dim.toPandas()
            
            pdf_raw['Date_Key'] = pdf_raw['Date'].map(pdf_dim.set_index('Date')['Date_Key'])
            pdf_raw['Date_Key'] = pdf_raw['Date_Key'].astype('Int32')
            pdf_raw['Reporting_Date_Key'] = pdf_raw['Reporting_Date'].map(pdf_dim.set_index('Short_Date_YMD')['Date_Key'])
            pdf_raw['Reporting_Date_Key'] = pdf_raw['Reporting_Date_Key'].astype('Int32')
        
        if(column_name == 'Tam_Segment_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Tam_Segment_Name'].unique()], ['Tam_Segment_Name'])
            df_infile_dim = df_infile_dim.dropna()

            df_dim = get_sql_dimension(dim_name=env_config.get("env_table_prefix") + 'Dim_Tam_Segment', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Tam_Segment_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Tam_Segment_Name'] = pdf_dim['Tam_Segment_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Tam_Segment_Name'] = pdf_raw['Tam_Segment_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Tam_Segment_Key'] = pdf_raw['Tam_Segment_Name'].map(pdf_dim.set_index('Tam_Segment_Name')['Tam_Segment_Key'])
            pdf_raw = pdf_raw.fillna({'Tam_Segment_Key': 0})
            pdf_raw['Tam_Segment_Key'] = pdf_raw['Tam_Segment_Key'].astype('Int32')
        
        if(column_name == 'Asset_Segment_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Asset_Segment_Name'].unique()], ['Asset_Segment_Name'])
            df_infile_dim = df_infile_dim.dropna()

            df_dim = get_sql_dimension(dim_name=env_config.get("env_table_prefix") + 'Dim_Asset_Segment', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Asset_Segment_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Asset_Segment_Name'] = pdf_dim['Asset_Segment_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Asset_Segment_Name'] = pdf_raw['Asset_Segment_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Asset_Segment_Key'] = pdf_raw['Asset_Segment_Name'].map(pdf_dim.set_index('Asset_Segment_Name')['Asset_Segment_Key'])
            pdf_raw = pdf_raw.fillna({'Asset_Segment_Key': 0})
            pdf_raw['Asset_Segment_Key'] = pdf_raw['Asset_Segment_Key'].astype('Int32')

        if(column_name == 'Liability_Segment_Name'):
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Liability_Segment_Name'].unique()], ['Liability_Segment_Name'])
            df_infile_dim = df_infile_dim.dropna()
            
            df_dim = get_sql_dimension(dim_name=env_config.get("env_table_prefix") + 'Dim_Liability_Segment', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Liability_Segment_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Liability_Segment_Name'] = pdf_dim['Liability_Segment_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Liability_Segment_Name'] = pdf_raw['Liability_Segment_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Liability_Segment_Key'] = pdf_raw['Liability_Segment_Name'].map(pdf_dim.set_index('Liability_Segment_Name')['Liability_Segment_Key'])
            pdf_raw = pdf_raw.fillna({'Liability_Segment_Key': 0})
            pdf_raw['Liability_Segment_Key'] = pdf_raw['Liability_Segment_Key'].astype('Int32')
        
        if(column_name == 'Product_Type_Name'):
            pdf_raw = pdf_raw.fillna({'Product_Type_Name': 'NULL'})
            df_infile_dim = spark.createDataFrame([(x,) for x in pdf_raw['Product_Type_Name'].unique()], ['Product_Type_Name'])
            df_infile_dim = df_infile_dim.dropna()
        
            df_dim = get_sql_dimension(dim_name=env_config.get("env_table_prefix") + 'Dim_Product_Type', access_token=access_token, jdbc_url=jdbc_url, 
                                    dim_list=df_infile_dim, name_column='Product_Type_Name', insertnew=1)
            pdf_dim = df_dim.toPandas()

            pdf_dim['Product_Type_Name'] = pdf_dim['Product_Type_Name'].str.replace(" ", "").str.upper()
            pdf_raw['Product_Type_Name'] = pdf_raw['Product_Type_Name'].str.replace(" ", "").str.upper()

            pdf_raw['Product_Type_Key'] = pdf_raw['Product_Type_Name'].map(pdf_dim.set_index('Product_Type_Name')['Product_Type_Key'])
            pdf_raw = pdf_raw.fillna({'Product_Type_Key': 0})
            pdf_raw['Product_Type_Key'] = pdf_raw['Product_Type_Key'].astype('Int32')
    
    return pdf_raw
            