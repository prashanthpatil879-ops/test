# sources/utils/path_tokens.py
from __future__ import annotations
import fnmatch
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional

try:
    # Python 3.9+
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None  # fallback if zoneinfo isn't available

def compute_tokens(tz_name: Optional[str] = None, now_utc: Optional[datetime] = None) -> Dict[str, str]:
    """
    Compute tokens for dynamic filenames and folder paths:
    {year}, {yy}, {quarter}, {yyqq}, {yearq}, {year_q}, 
    {month}, {month2}, {month_name}, {month_abbr}, {date}

    - tz_name: e.g., "Asia/Manila"; if None, uses UTC.
    - now_utc: override current time for testing (aware).
    """
    
    target_tz = None
    if tz_name and ZoneInfo is not None:
        try:
            target_tz = ZoneInfo(tz_name)
        except Exception as ex:
            # Option A: fail fast (recommended for config errors)
            raise ValueError(f"Invalid timezone in config: '{tz_name}'") from ex
            # Option B: fallback silently (less strict)
            # target_tz = timezone.utc
    else:
        target_tz = timezone.utc

    if now_utc is not None:
        # Ensure we have an aware datetime; if naive, assume it's UTC
        dt = now_utc if now_utc.tzinfo is not None else now_utc.replace(tzinfo=timezone.utc)
        # Convert to target timezone
        dt = dt.astimezone(target_tz)
    else:
        # No external now provided: get 'now' in target timezone directly
        dt = datetime.now(target_tz)


    year = dt.year                          # 2026
    yy = str(year)[2:]                      # 26
    month = dt.month                        # 1 / no leading zeroes
    month2 = dt.strftime("%m")              # 01 with leading zeroes
    month_name = dt.strftime("%B")          # "January"
    month_abbr = dt.strftime("%b")          # "Jan"
    quarter_number = ((month - 1) // 3) + 1
    quarter = f"Q{quarter_number}"          # Q1
    yyqq = f"{yy}{quarter}"                 # 26Q1
    yearq = f"{year}{quarter}"              # 2026Q1
    year_q = f"{year} {quarter}"            # 2026 Q1
    date_compact = dt.strftime("%Y%m%d")    # 20260120
    year_m = f"{year} {month2}"             # 2026 01

    return {
        # Year-related
        "year": str(year),              #20XX
        "yy": yy,                       #26Q1
        "quarter": quarter,             #Q1
        "yyqq": yyqq,                   #26Q1
        "yearq": yearq,                 #2026Q1
        "year_q": year_q,               #2026 Q1
        "year_m": year_m,               #2026 01

        # Month-related
        "month": str(month),             # 1
        "month2": month2,                # 01
        "month_name": month_name,        # January
        "month_abbr": month_abbr,        # Jan

        # Date
        "date": date_compact,            # YYYYMMDD

    }


def apply_tokens(template: str, tokens: Dict[str, str]) -> str:
    """
    Replace {token} in a template string.
    """
    out = template
    for k, v in tokens.items():
        out = out.replace("{" + k + "}", v)
    return out


def expand_patterns(patterns, tokens, auto_trailing_wildcard_if_no_ext=True):
    """
    Expand patterns with tokens.
    - If pattern has an extension (e.g., .xlsx), keep it STRICT (no trailing *).
    - If pattern has NO extension, add '*' only if auto_trailing_wildcard_if_no_ext=True.
    """
    expanded = []
    for p in (patterns or []):
        s = p
        for k, v in tokens.items():
            s = s.replace("{" + k + "}", v)

        expanded.append(s)

        # Only auto-add wildcard if pattern does NOT contain a '.'
        # and pattern does NOT already contain '*' or '?'
        if auto_trailing_wildcard_if_no_ext and "." not in s and "*" not in s and "?" not in s:
            expanded.append(s + "*")

    return expanded


def name_matches_any(name: str, patterns: Optional[Iterable[str]]) -> bool:
    """
    Return True if name matches any glob pattern; if no patterns, allow all.
    """
    pats = list(patterns or [])
    if not pats:
        return True
    return any(fnmatch.fnmatch(name, pat) for pat in pats)

def ext_allowed(name: str, allowed_exts: Optional[Iterable[str]]) -> bool:
    """
    Extension guard. allowed_exts entries can be 'xlsx' or '.xlsx'.
    """
    allowed = [e.lower().lstrip(".") for e in (allowed_exts or [])]
    if not allowed:
        return True
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return ext in allowed
