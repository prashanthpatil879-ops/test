
from abc import ABC, abstractmethod
from typing import Iterable, Tuple
from datetime import datetime

class BaseSource(ABC):
    '''
    Interface for sources that yield files to transfer.
    Each yielded item is a tuple: (relative_name, bytes_content, modified_dt)
    - relative_name: str, e.g., "sample.xlsx"
    - bytes_content: bytes
    - modified_dt: datetime (UTC) for filtering recent files
    '''

    @abstractmethod
    def iter_files(self) -> Iterable[Tuple[str, bytes, datetime]]:
        '''Yield files available to transfer.'''
        raise NotImplementedError
