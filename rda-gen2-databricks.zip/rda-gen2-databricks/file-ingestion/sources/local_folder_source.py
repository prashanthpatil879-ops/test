
import os
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Optional, Callable

from .base_source import BaseSource
from .utils.path_tokens import (
    compute_tokens, apply_tokens, expand_patterns,
    name_matches_any, ext_allowed
)

class LocalFolderSource(BaseSource):
    """
    Local folder source with optional:
      - path templating using {year}, {quarter}, {date}
      - filename pattern filtering (glob, supports extensionless patterns)
      - recursive traversal
      - extension filtering
    """

    def __init__(
        self,
        folder_path: str,
        include_exts: List[str],
        recursive: bool = False,
        file_patterns: Optional[List[str]] = None,
        path_is_template: bool = False,
        tz_name: Optional[str] = None,
        now_provider: Optional[Callable[[], datetime]] = None,
    ):
        # Provide a time provider (aware datetime) for testability
        self._now_provider = now_provider or (lambda: datetime.now(timezone.utc))
        tokens = compute_tokens(tz_name=tz_name, now_utc=self._now_provider())

        raw_path = os.path.expandvars(os.path.expanduser(folder_path))
        self.folder_path = apply_tokens(raw_path, tokens) if path_is_template else raw_path

        self.include_exts = include_exts or []
        self.recursive = bool(recursive)
        self.file_patterns = expand_patterns(file_patterns, tokens)

    def iter_files(self) -> Iterable[Tuple[str, bytes, datetime]]:
        if not os.path.isdir(self.folder_path):
            return  # nothing to yield

        if not self.recursive:
            for fname in os.listdir(self.folder_path):
                fpath = os.path.join(self.folder_path, fname)
                if not os.path.isfile(fpath):
                    continue
                if not ext_allowed(fname, self.include_exts):
                    continue
                # if not name_matches_any(fname, self.file_patterns):
                #     continue
                try:
                    with open(fpath, "rb") as f:
                        data = f.read()
                except Exception as e:
                    print(f"[SOURCE SKIP] Cannot read file: {fpath}")
                    print(f"[SOURCE SKIP] Reason: {type(e).__name__}: {e}")
                    continue
                mtime = os.path.getmtime(fpath)
                modified_dt = datetime.fromtimestamp(mtime, tz=timezone.utc)
                yield fname, data, modified_dt
            return

        base_len = len(self.folder_path.rstrip(os.sep)) + 1
        for root, _, files in os.walk(self.folder_path):
            for fname in files:
                if not ext_allowed(fname, self.include_exts):
                    continue
                # if not name_matches_any(fname, self.file_patterns):
                #     continue
                fpath = os.path.join(root, fname)
                rel = fpath[base_len:]
                
                try:
                    with open(fpath, "rb") as f:
                        data = f.read()                
                except Exception as e:
                    print(f"[SOURCE SKIP] Cannot read file: {fpath}")
                    print(f"[SOURCE SKIP] Reason: {type(e).__name__}: {e}")
                    continue

                mtime = os.path.getmtime(fpath)
                modified_dt = datetime.fromtimestamp(mtime, tz=timezone.utc)
                yield rel if self.recursive else fname, data, modified_dt
