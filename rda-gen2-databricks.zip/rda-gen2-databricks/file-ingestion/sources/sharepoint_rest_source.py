import os
import json
import msal
import requests
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Optional, Callable
from urllib.parse import quote
from helpers.time_utils import (
    log,
)

from .base_source import BaseSource
from .utils.path_tokens import (
    compute_tokens, apply_tokens, expand_patterns,
    name_matches_any, ext_allowed
)

class SharePointRestSource(BaseSource):
    """
    SharePoint Online REST source (no Graph):
      - Auth: MSAL + PFX certificate (client credentials)
      - List files from a site-relative folder using _api/web/GetFolderByServerRelativeUrl
    """

    def __init__(
        self,
        host: str,
        site: str,
        folder: str,
        include_exts: List[str],
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        tenant_id_env: Optional[str] = None,
        client_id_env: Optional[str] = None,
        pfx_path_env: Optional[str] = None,
        pfx_password_env: Optional[str] = None,
        pfx_bytes_env: Optional[str] = None,
        recursive: bool = False,
        auth_mode: str = "certificate_pfx",   # only supported mode here
        file_patterns: Optional[List[str]] = None,
        path_is_template: bool = False,
        tz_name: Optional[str] = None,
        now_provider: Optional[Callable[[], datetime]] = None,
    ):
        if auth_mode != "certificate_pfx":
            raise ValueError("SharePointRestSource currently supports only auth_mode='certificate_pfx'")

        
        env_tenant = os.getenv(tenant_id_env) if tenant_id_env else None
        env_client = os.getenv(client_id_env) if client_id_env else None

        self.tenant_id = env_tenant or tenant_id
        self.client_id = env_client or client_id
       
        if not self.tenant_id:
            raise RuntimeError("Tenant ID must be provided either via tenant_id or tenant_id_env")

        if not self.client_id:
            raise RuntimeError("Client ID must be provided either via client_id or client_id_env")

        env_pfx_bytes = os.getenv(pfx_bytes_env) if pfx_bytes_env else None
        self.pfx_password = os.getenv(pfx_password_env) if pfx_password_env else None

        if env_pfx_bytes:
            import base64
            self.pfx_bytes = base64.b64decode(env_pfx_bytes)
        else:
            self.pfx_path = os.getenv(pfx_path_env) if pfx_path_env else None
            if not self.pfx_path:
                raise RuntimeError("PFX path is required via env var (pfx_path_env)")

        self.host = host                  # e.g., mfc.sharepoint.com
        self.site = site                  # e.g., ALM_REP_ANAL
        self.include_exts = include_exts or []
        self.recursive = recursive

        # resolve tokens for optional templating on folder
        self._now_provider = now_provider or (lambda: datetime.now(timezone.utc))
        tokens = compute_tokens(tz_name=tz_name, now_utc=self._now_provider())
        self.folder = apply_tokens(folder, tokens) if path_is_template else folder
        self.file_patterns = expand_patterns(file_patterns, tokens)
        log(f"[SOURCE] SharePoint folder resolved: {self.folder}")
        self._access_token = None
        self._base_site_url = f"https://{self.host}/sites/{self.site}"

    # -----------------------
    # Auth: MSAL + PFX
    # -----------------------
    def _get_token(self) -> str:
        if self._access_token:
            return self._access_token

        # -----------------------------------------------------------
        # If PFX bytes from AKV are available → write to a temp file
        # -----------------------------------------------------------
        if self.pfx_bytes:
            import tempfile

            # Create temporary .pfx file
            temp = tempfile.NamedTemporaryFile(delete=False, suffix=".pfx")
            temp.write(self.pfx_bytes)
            temp.close()

            client_credential = {
                "private_key_pfx_path": temp.name,
                "passphrase": self.pfx_password or None,
            }

        else:
            client_credential = {
                "private_key_pfx_path": self.pfx_path,
                "passphrase": self.pfx_password or None,
            }

        cca = msal.ConfidentialClientApplication(
            client_id=self.client_id,
            authority=f"https://login.microsoftonline.com/{self.tenant_id}",
            client_credential=client_credential,
        )

        scopes = [f"https://{self.host}/.default"]
        result = cca.acquire_token_for_client(scopes=scopes)

        if "access_token" not in result:
            raise RuntimeError(
                f"Token failure: {result.get('error')} {result.get('error_description')}"
            )

        self._access_token = result["access_token"]
        return self._access_token

    def _headers(self):
        return {
            "Authorization": f"Bearer {self._get_token()}",
            "Accept": "application/json;odata=nometadata"
        }

    # -----------------------
    # SharePoint REST helpers
    # -----------------------
    def _encode_server_rel(self, rel_path: str) -> str:
        # Expect e.g. 'Documents/SubFolder'
        # Build '/sites/<site>/<rel_path>' then encode segments and keep '/'s intact.
        raw = f"/sites/{self.site}/{rel_path.strip('/')}"
        parts = [quote(seg, safe="") for seg in raw.split("/")]
        enc = "/".join(parts)
        if not enc.startswith("%2F"):
            enc = "%2F" + enc.lstrip("/")
        return enc

    def _list_children(self, rel_folder: str):
        # Get folders and files under a folder
        server_rel = self._encode_server_rel(rel_folder)
        base = f"{self._base_site_url}/_api/web/GetFolderByServerRelativeUrl('{server_rel}')"

        resp_folders = requests.get(f"{base}/Folders?$select=Name,ServerRelativeUrl", headers=self._headers(), timeout=60)
        resp_files = requests.get(f"{base}/Files?$select=Name,ServerRelativeUrl,TimeLastModified,Length", headers=self._headers(), timeout=300)

        if resp_folders.status_code == 404 or resp_files.status_code == 404:
            raise FileNotFoundError(f"Folder not found: /sites/{self.site}/{rel_folder.lstrip('/')}")

        resp_folders.raise_for_status()
        resp_files.raise_for_status()

        return (resp_folders.json().get("value", []), resp_files.json().get("value", []))

    def _iter_folder(self, rel_folder: str) -> Iterable[Tuple[str, bytes, datetime]]:
        folders, files = self._list_children(rel_folder)

        # Recurse into subfolders
        for f in folders:
            name = f.get("Name")
            if not name:
                continue
            if self.recursive:
                subrel = f"{rel_folder.rstrip('/')}/{name}"
                yield from self._iter_folder(subrel)

        # Yield files
        for f in files:
            name = f.get("Name")
            if not name:
                continue

            if not ext_allowed(name, self.include_exts):
                continue
            # if not name_matches_any(name, self.file_patterns):
            #     continue

            # Download file content
            server_rel = f.get("ServerRelativeUrl")  # e.g., /sites/SITE/Documents/file.xlsx
            if not server_rel:
                continue

            # dl_url = f"{self._base_site_url}/_api/web/GetFileByServerRelativeUrl('{quote(server_rel, safe='')}')/$value"
            
            dl_url = (
                f"{self._base_site_url}"
                f"/_api/web/GetFileByServerRelativePath(decodedurl='{server_rel}')/$value"
            )
            
            resp = requests.get(dl_url, headers=self._headers(), stream=True, timeout=300)
            resp.raise_for_status()
            data = resp.content

            lm = f.get("TimeLastModified")
            modified_dt = (
                datetime.fromisoformat(lm.replace("Z", "+00:00")).astimezone(timezone.utc)
                if lm else self._now_provider()
            )

            yield name, data, modified_dt

    def iter_files(self) -> Iterable[Tuple[str, bytes, datetime]]:
        # self.folder is site-relative (e.g., "Documents/Inbound")
        yield from self._iter_folder(self.folder)