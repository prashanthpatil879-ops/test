import os
import sys
import subprocess
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Optional, Callable
from helpers.time_utils import (
    log,
)

from .local_folder_source import LocalFolderSource  # reuse traversal/filters

class NasSource(LocalFolderSource):
    """
    NAS/UNC source that (on Windows) establishes an SMB session via `net use`,
    then reuses LocalFolderSource to enumerate & read files.

    On non-Windows (linux), assume the share is already mounted by the OS
    and simply use LocalFolderSource over the UNC/mount path.
    """

    def __init__(
        self,
        folder_path: str,
        include_exts: List[str],
        recursive: bool = False,
        file_patterns: Optional[List[str]] = None,
        tz_name: Optional[str] = None,
        username_env: Optional[str] = None,
        password_env: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        path_is_template: bool = False,
        now_provider: Optional[Callable[[], datetime]] = None,
    ):
        self._unc = folder_path
        log(f"[SOURCE] Resolved local/NAS folder: {self._unc}")
        # Resolve creds (env takes precedence over literals)
        user_from_env = os.getenv(username_env) if username_env else None
        pass_from_env = os.getenv(password_env) if password_env else None

        self._username = user_from_env or username
        self._password = pass_from_env if (user_from_env or password_env) else password

        if not self._username:
            raise RuntimeError("Username must be provided either via username or user_from_env")

        if not self._password:
            raise RuntimeError("Password must be provided either via password or password_env")

        self._did_connect = False

        # Establish session on Windows only. On linux/mac, expect OS mount.
        if sys.platform.startswith("win"):
            self._connect_windows()

        # Delegate traversal to LocalFolderSource with the UNC path (same filters)
        super().__init__(
            folder_path=folder_path,
            include_exts=include_exts,
            recursive=recursive,
            file_patterns=file_patterns,
            path_is_template=path_is_template,
            tz_name=tz_name,
            now_provider=now_provider,
        )

    def _connect_windows(self):
        """
        Attempt `net use` with the resolved credentials.
        If username is present but password is None, try without password (net use prompts-less attempt).
        If neither is present, skip (assume existing session or anonymous).
        """
        if not self._username:
            return  # no creds provided; rely on existing session or OS auth

        cmd = ["net", "use", self._unc, f"/user:{self._username}"]
        if self._password is not None:
            cmd.append(self._password)

        try:
            completed = subprocess.run(cmd, capture_output=True, text=True)
            out = (completed.stdout or "") + (completed.stderr or "")
            if completed.returncode == 0 or "The command completed successfully." in out:
                self._did_connect = True
            elif "The local device name is already in use" in out or "multiple connections" in out.lower():
                # Pre-connected session is acceptable
                self._did_connect = True
            else:
                # You can log `out` for diagnostics if you have logging
                pass
        except Exception:
            # Swallow connection errors to let traversal fail gracefully if inaccessible
            pass

    def __del__(self):
        # Best-effort disconnect to avoid session leaks; Windows only
        try:
            if self._did_connect and sys.platform.startswith("win"):
                subprocess.run(["net", "use", self._unc, "/delete", "/y"], capture_output=True)
        except Exception:
            pass