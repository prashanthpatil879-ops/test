import os
import requests
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Optional, Callable

from .base_source import BaseSource
from .utils.path_tokens import (
    compute_tokens, apply_tokens, expand_patterns,
    name_matches_any, ext_allowed
)

# Auth
try:
    from azure.identity import ManagedIdentityCredential, DefaultAzureCredential
    _AZURE_IDENTITY_AVAILABLE = True
except Exception:
    _AZURE_IDENTITY_AVAILABLE = False

# NEW: MSAL (for certificate_pfx mode)
try:
    import msal
    _MSAL_AVAILABLE = True
except Exception:
    _MSAL_AVAILABLE = False

GRAPH_BASE = "https://graph.microsoft.com/v1.0"
GRAPH_SCOPE = "https://graph.microsoft.com/.default"


class SharePointSource(BaseSource):
    def __init__(
        self,
        tenant_id: Optional[str],
        client_id: Optional[str],
        client_secret_env: Optional[str],
        site_id: str,
        drive_id: str,
        path: str,
        include_exts: List[str],
        recursive: bool = False,
        auth_mode: str = "managed_identity",  # "managed_identity" | "client_secret" | "certificate_pfx"
        file_patterns: Optional[List[str]] = None,
        path_is_template: bool = False,
        tz_name: Optional[str] = None,
        now_provider: Optional[Callable[[], datetime]] = None,
        # NEW: PFX env variables
        pfx_path_env: Optional[str] = None,
        pfx_password_env: Optional[str] = None,
    ):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = os.getenv(client_secret_env) if client_secret_env else None

        # NEW: PFX
        self.pfx_path = os.getenv(pfx_path_env) if pfx_path_env else None
        self.pfx_password = os.getenv(pfx_password_env) if pfx_password_env else None

        self.site_id = site_id
        self.drive_id = drive_id
        self.include_exts = include_exts or []
        self.recursive = recursive
        self.auth_mode = auth_mode

        self._now_provider = now_provider or (lambda: datetime.now(timezone.utc))
        tokens = compute_tokens(tz_name=tz_name, now_utc=self._now_provider())

        self.path = apply_tokens(path, tokens) if path_is_template else path
        self.file_patterns = expand_patterns(file_patterns, tokens)
        self._token = None

        if self.auth_mode == "managed_identity":
            if not _AZURE_IDENTITY_AVAILABLE:
                raise RuntimeError("azure-identity is required for managed identity auth. Add it to requirements and install.")
        elif self.auth_mode == "client_secret":
            missing = []
            if not self.tenant_id: missing.append("tenant_id")
            if not self.client_id: missing.append("client_id")
            if not self.client_secret: missing.append("client_secret (via env)")
            if missing:
                raise RuntimeError(f"Missing parameters for client_secret auth: {', '.join(missing)}")
        elif self.auth_mode == "certificate_pfx":
            if not _MSAL_AVAILABLE:
                raise RuntimeError("msal is required for certificate_pfx auth. Add it to requirements and install.")
            missing = []
            if not self.tenant_id: missing.append("tenant_id")
            if not self.client_id: missing.append("client_id")
            if not self.pfx_path: missing.append("pfx_path (via env)")
            # pfx_password may be empty if the PFX is not protected
            if missing:
                raise RuntimeError(f"Missing parameters for certificate_pfx auth: {', '.join(missing)}")
        else:
            raise ValueError("auth_mode must be 'managed_identity', 'client_secret', or 'certificate_pfx'")

    # ----- Graph helpers -----
    def _get_token(self) -> str:
        if self._token:
            return self._token

        if self.auth_mode == "managed_identity":
            try:
                cred = DefaultAzureCredential(exclude_interactive_browser_credential=True)
                token = cred.get_token(GRAPH_SCOPE)
            except Exception:
                cred = ManagedIdentityCredential()
                token = cred.get_token(GRAPH_SCOPE)
            self._token = token.token

        elif self.auth_mode == "client_secret":
            token_url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
            data = {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "scope": GRAPH_SCOPE,
                "grant_type": "client_credentials",
            }
            resp = requests.post(token_url, data=data, timeout=60)
            resp.raise_for_status()
            self._token = resp.json()["access_token"]

        elif self.auth_mode == "certificate_pfx":
            # MSAL client-credentials with PFX certificate
            cca = msal.ConfidentialClientApplication(
                client_id=self.client_id,
                authority=f"https://login.microsoftonline.com/{self.tenant_id}",
                client_credential={
                    "private_key_pfx_path": self.pfx_path,
                    "passphrase": self.pfx_password,
                    # If you later want SN/I with pfx and your PFX includes the public cert:
                    # "public_certificate": True
                },
            )
            res = cca.acquire_token_for_client(scopes=[GRAPH_SCOPE])
            if "access_token" not in res:
                raise RuntimeError(f"Token failure: {res.get('error')} {res.get('error_description')}")
            self._token = res["access_token"]

        return self._token

    def _headers(self):
        return {"Authorization": f"Bearer {self._get_token()}"}

    def _list_children(self, folder_path: str) -> Iterable[dict]:
        url = f"{GRAPH_BASE}/sites/{self.site_id}/drives/{self.drive_id}/root:{folder_path}:/children"
        resp = requests.get(url, headers=self._headers(), timeout=60)
        resp.raise_for_status()
        return resp.json().get("value", [])

    def _download_item_bytes(self, item_id: str) -> bytes:
        url = f"{GRAPH_BASE}/sites/{self.site_id}/drives/{self.drive_id}/items/{item_id}/content"
        resp = requests.get(url, headers=self._headers(), stream=True, timeout=300)
        resp.raise_for_status()
        return resp.content

    def _iter_folder(self, folder_path: str) -> Iterable[Tuple[str, bytes, datetime]]:
        for child in self._list_children(folder_path):
            if child.get("folder"):
                if self.recursive:
                    sub_path = f"{folder_path}/{child['name']}"
                    yield from self._iter_folder(sub_path)
                continue

            name = child["name"]
            if not ext_allowed(name, self.include_exts):
                continue
            if not name_matches_any(name, self.file_patterns):
                continue

            item_id = child["id"]
            last_modified = child.get("lastModifiedDateTime")
            modified_dt = datetime.fromisoformat(last_modified.replace("Z", "+00:00")).astimezone(timezone.utc)
            data = self._download_item_bytes(item_id)
            yield name, data, modified_dt

    def iter_files(self) -> Iterable[Tuple[str, bytes, datetime]]:
        yield from self._iter_folder(self.path)
