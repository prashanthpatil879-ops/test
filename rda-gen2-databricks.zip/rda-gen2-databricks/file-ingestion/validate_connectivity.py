#!/usr/bin/env python3

import argparse
from ast import Load
import secrets
import sys
from pathlib import Path
import glob
import yaml
import traceback

from azure.identity import DefaultAzureCredential
from azure.storage.filedatalake import DataLakeServiceClient

# Reuse existing helpers
from helpers.time_utils import log
from helpers.secret_loader import load_secrets
from helpers.adls_config_loader import is_adls_path, _parse, load_adls_config_with_fallback

# Sources
from sources.sharepoint_graph_source import SharePointSource
from sources.sharepoint_rest_source import SharePointRestSource
from sources.local_folder_source import LocalFolderSource
from sources.nas_source import NasSource

# Destinations
from destinations.adls_destination import ADLSGen2Destination
from destinations.local_folder_destination import LocalFolderDestination

DEFAULT_CONFIG_BASE_DIR = Path("config").resolve()


# ============================================================
# Phase 0 – Config accessibility validation (READ-ONLY)
# ============================================================

def validate_config_access(config_dir: str, env: str):
    """
    Validate that configuration is accessible, readable, and parsable.
    This is a READ-ONLY operation and must be zero-risk.

    Returns:
        List of config references (Path for local, str for ADLS)
    """
    log(f"[CONFIG] Starting config accessibility validation")
    log(f"[CONFIG] Env={env}, ConfigDir={config_dir}")

    if is_adls_path(config_dir):
        return _validate_adls_config_access(config_dir, env)
    
    config_path = Path(config_dir).expanduser().resolve()

    # Enforce containment (Snyk needs this)
    if DEFAULT_CONFIG_BASE_DIR not in config_path.parents and config_path != DEFAULT_CONFIG_BASE_DIR:
        raise ValueError(f"Invalid config directory: {config_path}")

    if not config_path.exists():
        raise FileNotFoundError(config_path)

    return _validate_local_config_access(config_path, env)

def _validate_local_config_access(config_path: Path, env: str):
    log(f"[CONFIG] Detected LOCAL config directory")

    if not config_path.exists():
        raise RuntimeError(f"Local config directory does not exist: {config_path}")

    if not config_path.is_dir():
        raise RuntimeError(f"Config path is not a directory: {config_path}")

    configs = list(config_path.rglob(f"**/settings.{env}.yaml"))

    if not configs:
        raise RuntimeError(f"No settings.{env}.yaml files found under {config_path}")

    for cfg in configs:
        log(f"[CONFIG] Reading local config: {cfg}")
        with cfg.open("r", encoding="utf-8") as f:
            yaml.safe_load(f)

    log(f"[CONFIG] Local config validation passed ({len(configs)} file(s))")

    return configs  # FIX: ensures caller always gets an iterable


def _validate_adls_config_access(adls_url: str, env: str):
    log(f"[CONFIG] Detected ADLS-backed config directory")

    account, filesystem, folder = _parse(adls_url)

    credential = DefaultAzureCredential()
    service = DataLakeServiceClient(
        account_url=f"https://{account}.dfs.core.windows.net",
        credential=credential,
    )

    fs_client = service.get_file_system_client(filesystem)

    found = []
    for path in fs_client.get_paths(path=folder):
        if path.name.endswith(f"settings.{env}.yaml"):
            log(f"[CONFIG] Reading ADLS config: {path.name}")
            file_client = fs_client.get_file_client(path.name)
            content = file_client.download_file().readall()
            yaml.safe_load(content)  # parse only
            found.append(path.name)

    if not found:
        raise RuntimeError(f"No settings.{env}.yaml files found in ADLS path {adls_url}")

    log(f"[CONFIG] ADLS config validation passed ({len(found)} file(s))")
    return found


# ============================================================
# Phase 1 & 2 – Connectivity validation (READ-ONLY)
# ============================================================

def validate_single_config(cfg_data: dict, cfg_label: str, env: str):
    log(f"[{cfg_label}] Starting connectivity validation")

    # --------------------
    # Validate source
    # --------------------
    src_cfg = cfg_data.get("source", {})
    src_type = src_cfg.get("type")

    if src_type == "spo_rest":
        spo_cfg = src_cfg["spo_rest"]

        include_exts = cfg_data.get("include_extensions", [])

        src = SharePointRestSource(
            site=spo_cfg["site"],
            folder=spo_cfg["folder"],
            include_exts=include_exts,
            host=spo_cfg.get("host"),
            recursive=spo_cfg.get("recursive", False),
            path_is_template=spo_cfg.get("path_is_template", False),
            auth_mode=spo_cfg.get("auth_mode"),
            tenant_id_env=spo_cfg.get("tenant_id_env"),
            client_id_env=spo_cfg.get("client_id_env"),
            pfx_bytes_env=spo_cfg.get("pfx_bytes_env"),
        )
        
        _validate_sharepoint_source(src, "SharePoint Rest")
        


    elif src_type == "nas":
        
        nas_cfg = src_cfg["nas"]

        include_exts = cfg_data.get("include_extensions", [])

        src = NasSource(
            folder_path=nas_cfg["folder_path"],
            include_exts=include_exts,
            recursive=nas_cfg.get("recursive", False),
            file_patterns=cfg_data.get("file_patterns"),
            tz_name=cfg_data.get("tz_name"),
            username_env=nas_cfg.get("username_env"),
            password_env=nas_cfg.get("password_env"),
            username=nas_cfg.get("username"),
            password=nas_cfg.get("password"),
            path_is_template=nas_cfg.get("path_is_template", False),
        )

        # READ‑ONLY enumeration (establishes SMB session internally)
        next(src.iter_files(), None)
        log(f"[{cfg_label}] vNAS read access validated")

    elif src_type == "local":
        path = Path(src_cfg["local"]["folder_path"])
        _validate_local_path(path, cfg_label, "Local")

    else:
        raise RuntimeError(f"Unsupported source type: {src_type}")

    # --------------------
    # Validate destination
    # --------------------
    dest_cfg = cfg_data.get("destination", {})
    dest_type = dest_cfg.get("type")

    if dest_type == "adls":
        
        adls_cfg = cfg_data["destination"]["adls"]

        account_name = adls_cfg["account_name"]
        filesystem = adls_cfg["filesystem"]

        # Build credential exactly as production does
        cred_mode = adls_cfg.get("credential", {}).get("mode", "managed_identity")

        if cred_mode == "managed_identity":
            credential = DefaultAzureCredential()
        else:
            raise RuntimeError(f"Unsupported ADLS credential mode: {cred_mode}")

        # BUILD READ-ONLY CLIENT (no writes possible)
        service_client = DataLakeServiceClient(
            account_url=f"https://{account_name}.dfs.core.windows.net",
            credential=credential,
        )

        fs_client = service_client.get_file_system_client(filesystem)

        # READ-ONLY LIST (connectivity + RBAC validation)
        next(fs_client.get_paths(), None)


        log(f"[{cfg_label}] ADLS destination read access validated")

    elif dest_type == "local":
        path = Path(dest_cfg["local"]["folder_path"])
        _validate_local_path(path, cfg_label, "Local Destination")

    else:
        raise RuntimeError(f"Unsupported destination type: {dest_type}")

    log(f"[{cfg_label}] CONNECTIVITY VALIDATION PASSED")


def _validate_sharepoint_source(source_obj, label):
    log(f"[{label}] SharePoint: validating auth and read access")
    next(source_obj.iter_files(), None)
    log(f"[{label}] SharePoint read access validated")


def _validate_local_path(path: Path, label: str, kind: str):
    log(f"[{label}] {kind}: validating read access on {path}")
    if not path.exists():
        raise RuntimeError(f"{kind} path does not exist: {path}")
    _ = next(path.iterdir(), None)
    log(f"[{label}] {kind} read access validated")


# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Functional connectivity dry-run validation (read-only, zero-risk)"
    )
    parser.add_argument("--env", required=True, choices=["local", "dev", "qa", "uat", "prod"])
    parser.add_argument("--kv", required=True, help="Provide the Azure Key Vault Name")
    parser.add_argument("--config-dir", default="config", help="Path to config directory (local path or ADLS URL)")

    args = parser.parse_args()

    try:

        # Load secrets
        log(f"[SECRETS] Loading secrets for env={args.env} from kv={args.kv}")
        load_secrets(args.env, args.kv)
        log("[SECRETS] Secrets loaded successfully")

        # Phase 0 – Config accessibility
        config_refs = validate_config_access(args.config_dir, args.env)

        all_ok = True

        # Phase 1 & 2 – Connectivity checks (only after configs are proven accessible)
        for ref in config_refs:
            try:
                if isinstance(ref, Path):
                    with open(ref, "r", encoding="utf-8") as f:
                        cfg = yaml.safe_load(f)
                    label = str(ref.parent)

                else:
                    # ADLS case – ref is a path string
                    account, filesystem, _ = _parse(args.config_dir)
                    credential = DefaultAzureCredential()
                    service = DataLakeServiceClient(
                        account_url=f"https://{account}.dfs.core.windows.net",
                        credential=credential,
                    )
                    fs_client = service.get_file_system_client(filesystem)
                    file_client = fs_client.get_file_client(ref)
                    cfg = yaml.safe_load(file_client.download_file().readall())
                    label = ref

                validate_single_config(cfg, label, args.env)

            except Exception as e:
                all_ok = False
                log(f"[{label}] VALIDATION FAILED: {e}")
                traceback.print_exc()

        if all_ok:
            log("ALL CONFIGS VALIDATED SUCCESSFULLY")
            sys.exit(0)
        else:
            log("ONE OR MORE CONFIGS FAILED VALIDATION")
            sys.exit(1)

    except Exception as e:
        log(f"[CONFIG] CONFIG ACCESS VALIDATION FAILED: {e}")
        traceback.print_exc()
        sys.exit(2)


if __name__ == "__main__":
    main()