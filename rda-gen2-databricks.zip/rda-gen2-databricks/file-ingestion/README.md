# SharePoint / Local / NAS → Transfer Pipeline

A modular, YAML‑configurable Python pipeline for transferring files from **SharePoint**, **local folders**, or **NAS** into **ADLS Gen2 / SFTP / Local** destinations.

Supports:

- ✅ Multi-source ingestion  
- ✅ Tokenized dynamic paths (date, quarter, etc.)  
- ✅ Lookback period scanning  
- ✅ Business-day (BD) driven quarter logic  
- ✅ Deduplication & state tracking  
- ✅ Recent mode with filename fallback  
- ✅ Operational CSV logging  

---

# 📌 Key Features

## ✔ Modular Source Types
- **SharePoint Online** (REST / Graph compatible)
- **Local folder**
- **NAS / UNC path** (with optional credentials)

Supports:
- `include_extensions`
- glob-style `file_patterns`
- `recursive`
- dynamic folder templates:
  ```
  {year}, {yy}, {quarter}, {yyqq}, {year_q}, {date}, etc.
  ```

---

## ✔ Modular Destinations
- **Local folder**
- **SFTP**
- **ADLS Gen2** (Managed Identity supported)

---

# 🧠 Dedupe & Resend Behavior

The pipeline uses a persistent JSON state file (`state.file`) to prevent duplicate transfers.

---

## ✅ Name-Level Dedupe (default)
- Each filename is processed **once**
- Overrides via `--force`

---

## ✅ Mode: `recent`

- Filters files modified within:
  ```yaml
  recent_minutes
  ```
- Optional fallback:
  - Extract date from filename via regex
- Applies name-level dedupe

---

## ✅ Mode: `unprocessed`

- No time filtering
- Uses:
  - name-based dedupe
  - key-based dedupe (`name:timestamp`)
- Ideal for:
  - backfill
  - recovery runs

---

# 📂 Dynamic Paths (Tokens)

Example:

```yaml
folder: "Shared Documents/IFRS17/{year}/{year_q}/Sensitivities"
```

Available tokens:

```
{year}        → 2026
{yy}          → 26
{quarter}     → Q1
{yyqq}        → 26Q1
{yearq}       → 2026Q1
{year_q}      → 2026 Q1
{month2}      → 01
{date}        → 20260120
```

---

# 🔁 Lookback & Period Search

The pipeline supports scanning previous periods when files are not available in the current one.

---

## ✅ Basic Lookback

```yaml
period_search:
  lookback: 1
```

Behavior:

```
Primary → current period
Fallback → previous period (only if no files found in primary)
```

---

## ✅ Quarter Mode with Business Day Logic

```yaml
period_search:
  lookback: 1
  type: quarter
  q_override_bd: 16
```

---

### 📊 Behavior

#### ✅ If Business Day < 16

```
Primary → previous quarter - 1
Fallback → previous quarter
```

Example:

```
Today: 2026-04-22 (BD < 16)

Primary → 2025 Q4
Fallback → 2026 Q1
```

---

#### ✅ If Business Day ≥ 16

```
Primary → previous quarter
Fallback → current quarter
```

Example:

```
Today: 2026-04-23 (BD ≥ 16)

Primary → 2026 Q1
Fallback → 2026 Q2
```

---

### ✅ Key Behavior

- Only **one period is processed at a time**
- Lookback is used **only if primary has no valid files**
- Prevents unnecessary scanning and duplicate processing

---

# 🎯 File Matching

Filtering is applied in **three stages**:

1. Source filtering (extensions, patterns)
2. Recency check
3. Filename date fallback

---

## ✅ Example pattern

```yaml
file_patterns:
  - "IFRS17 * Consolidated Sensitivities Results * - *.xlsb"
```

---

# ⚙️ CLI Options

| Flag | Description |
|------|-------------|
| `--env` | Environment (`local`, `uat`, `prod`) |
| `--config-dir` | Custom config folder |
| `--file <name>` | Process a single file (exact match) |
| `--pattern "<glob>"` | Filter by pattern |
| `--force` | Ignore dedupe |
| `--secrets` | Load secrets from Key Vault |
| `--kv` | Key Vault name |

---

# 🚀 Usage Examples

## ✅ Basic run

```bash
python transfer.py --env local
```

---

## ✅ Process specific file

```bash
python transfer.py --env local --file "File.xlsx"
```

---

## ✅ Pattern-based run

```bash
python transfer.py --env local --pattern "*.xlsx"
```

---

## ✅ Force resend

```bash
python transfer.py --env local --force
```

---

## ✅ Custom config directory

```bash
python transfer.py --env local --config-dir "config/GAM"
```

---

# 🧪 Behavior Summary

## ✅ Normal Mode

```
Find recent files in primary period
→ fallback to previous period only if needed
```

---

## ✅ --file Mode

```
Find exact file across periods
→ primary → fallback
```

---

# 📌 Notes

- SharePoint sources retrieve metadata before filtering  
- Filtering is applied **after listing**, not pre-query  
- Filename fallback helps when:
  - modified dates are unreliable  
  - files are uploaded late  

---

# ✅ Summary

This pipeline provides a **flexible, production-ready ingestion framework** supporting:

- multi-source ingestion  
- dynamic folder resolution  
- period-aware retrieval  
- financial reporting scenarios  
- controlled deduplication  
