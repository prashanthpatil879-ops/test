import argparse
import copy
import fnmatch
import re
from datetime import datetime, timedelta, timezone
import os
import yaml
import traceback
from pathlib import Path

# Sources
from sources.sharepoint_rest_source import SharePointRestSource
from sources.local_folder_source import LocalFolderSource
from sources.nas_source import NasSource
from sources.utils.path_tokens import compute_tokens, expand_patterns, name_matches_any

# Destinations
from destinations.sftp_destination import SFTPDestination
from destinations.local_folder_destination import LocalFolderDestination
from destinations.adls_destination import ADLSGen2Destination

# Helpers (new)
from helpers.logging_utils import OperationLogger
from helpers.path_utils import (
    get_source_info,
    get_destination_info,
    describe_dest_path_for_file,
)

from helpers.state_utils import (
    load_state,
    save_state,
    make_state_record,
)

from helpers.time_utils import (
    log,
    shift_months,
    make_now_provider,
    shift_quarters,
    get_business_day_of_quarter,
)


from helpers.adls_config_loader import (
    is_adls_path,
    load_adls_config_with_fallback,
)

from helpers.secret_loader import load_secrets

DEFAULT_CONFIG_BASE_DIR = Path("config").resolve()
# for regex pattern safety guards
SAFE_REGEX_PATTERN = re.compile(r"^[0-9\[\]\(\)\{\}\\d\+\?\|\.\-\^$]+$")

# --------------------------
# Config loaders
# --------------------------
def load_config(path: str) -> dict:
    # Path already resolved; double-check containment
    if DEFAULT_CONFIG_BASE_DIR not in path.parents:
        raise ValueError(f"Invalid config path: {path}")

    if path.suffix.lower() not in {".yml", ".yaml"}:
        raise ValueError("Config file must be a YAML file")

    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)



def resolve_config_path(base_path: str, env: str) -> str:
    env_cfg = (base_path / f"settings.{env}.yaml").resolve()
    default_cfg = (base_path / "settings.yaml").resolve()

    for candidate in (env_cfg, default_cfg):
        # Ensure candidate is inside base_path
        if base_path in candidate.parents and candidate.is_file():
            return candidate

    raise FileNotFoundError(
        f"No config found for env '{env}'. Checked: {env_cfg} and {default_cfg}"
    )



# --------------------------
# Builders 
# --------------------------
def build_source(cfg: dict):
    st = cfg["source"]["type"]
    include_exts = cfg.get("include_extensions", [])
    tz_name = cfg.get("tz_name")

    
    if st == "spo_rest":
        sp = cfg["source"]["spo_rest"]
        return SharePointRestSource(
            tenant_id=sp.get("tenant_id"),
            client_id=sp.get("client_id"),
            tenant_id_env=sp.get("tenant_id_env"),
            client_id_env=sp.get("client_id_env"),
            pfx_path_env=sp.get("pfx_path_env"),
            pfx_password_env=sp.get("pfx_password_env"),
            pfx_bytes_env=sp.get('pfx_bytes_env'),
            host=sp["host"],
            site=sp["site"],
            folder=sp["folder"],
            include_exts=include_exts,
            recursive=bool(sp.get("recursive", False)),
            auth_mode=sp.get("auth_mode", "certificate_pfx"),
            file_patterns=cfg.get("file_patterns", []),
            path_is_template=bool(sp.get("path_is_template", False)),
            tz_name=tz_name,
            now_provider=cfg.get("__now_provider")
        )

    if st == "local":
        lc = cfg["source"]["local"]
        return LocalFolderSource(
            folder_path=lc["folder_path"],
            include_exts=include_exts,
            recursive=bool(lc.get("recursive", False)),
            file_patterns=cfg.get("file_patterns", []),
            path_is_template=bool(lc.get("path_is_template", False)),
            tz_name=tz_name,
            now_provider=cfg.get("__now_provider")
        )

    if st == "nas":
        ns = cfg["source"]["nas"]
        return NasSource(
            folder_path=ns["folder_path"],
            include_exts=include_exts,
            recursive=bool(ns.get("recursive", False)),
            file_patterns=cfg.get("file_patterns", []),
            tz_name=cfg.get("tz_name"),
            username_env=ns.get("username_env"),
            password_env=ns.get("password_env"),
            username=ns.get("username"),
            password=ns.get("password"),
            path_is_template=bool(ns.get("path_is_template", False)),
            now_provider=cfg.get("__now_provider")
        )

    raise ValueError(f"Unsupported source type: {st}")


def build_destination(cfg: dict):
    dt = cfg["destination"]["type"]

    if dt == "local":
        ld = cfg["destination"]["local"]
        return LocalFolderDestination(folder_path=ld["folder_path"])

    if dt == "sftp":
        sftp = cfg["destination"]["sftp"]
        return SFTPDestination(
            host=sftp["host"],
            port=int(sftp.get("port", 22)),
            username_env=sftp.get("username_env"),
            target_dir=sftp["target_dir"],
            key_path_env=sftp.get("key_path_env"),
            key_passphrase_env=sftp.get("key_passphrase_env"),
            password_env=sftp.get("password_env"),
            auth_mode=sftp.get("auth_mode", "auto"),
        )

    if dt == "adls":
        adls = cfg["destination"]["adls"]
        return ADLSGen2Destination(
            config={
                "account_name": adls["account_name"],
                "filesystem": adls["filesystem"],
                "path_template": adls.get("path_template", "{filename}"),
                "overwrite": bool(adls.get("overwrite", False)),
                "create_dirs": bool(adls.get("create_dirs", True)),
                "content_type_from_extension": bool(adls.get("content_type_from_extension", True)),
                "credential": adls.get("credential", {})
            }
        )


    raise ValueError(f"Unsupported destination type: {dt}")


# --------------------------
# Recency helpers 
# --------------------------
def is_recent(modified_dt: datetime, minutes: int) -> bool:
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=minutes)
    return modified_dt > cutoff


# --------------------------
# Fallback date-from-filename
# --------------------------
def extract_filename_date(name: str, regex: str, fmt: str):
    try:
        # Reject unsafe regex patterns (ReDoS prevention)
        if not SAFE_REGEX_PATTERN.fullmatch(regex):
            raise ValueError("Unsafe regex pattern rejected")

        m = re.search(regex, name)
        if not m:
            return None

        token = m.group(1)
        dt = datetime.strptime(token, fmt)
        return dt.replace(tzinfo=timezone.utc)

    except Exception:
        return None

def filename_date_within_window(name: str, window_days: int, regex: str, fmt: str) -> bool:
    file_dt = extract_filename_date(name, regex, fmt)
    if not file_dt:
        return False
    today_utc = datetime.now(timezone.utc).date()
    return file_dt.date() >= (today_utc - timedelta(days=window_days))


# --------------------------
# Main
# --------------------------
def main():
    parser = argparse.ArgumentParser(description="Modular SharePoint/Local to MFT transfer")
    parser.add_argument("--env", choices=["local", "dev", "qa", "uat", "prod"], default="local", help="Environment profile")
    parser.add_argument("--config-dir", default="config", help="Directory where config files live")
    parser.add_argument("--file", default=None, help="Transfer only this exact relative filename")
    parser.add_argument("--pattern", default=None, help="Transfer files matching this glob (e.g., '*.xlsx')")
    parser.add_argument("--force", action="store_true", help="Ignore state in 'unprocessed' mode for selected files")
    parser.add_argument("--secrets", action="store_true", help="Enable load secrets from DEV AKV")
    parser.add_argument("--kv", help="Provide the Azure Key Vault Name")

    args = parser.parse_args()

    # trim inputs

    args.config_dir = args.config_dir.strip()

    if args.file:
        args.file = args.file.strip()

    if args.kv:
        args.kv = args.kv.strip()

    if args.secrets and not args.kv:
        parser.error("--kv is required when --secrets is enabled")


    log(f"Script started with env={args.env}, config_dir={args.config_dir}, file={args.file}, pattern={args.pattern}, force={args.force}, secrets={args.secrets}")

    config_dir = args.config_dir

    if is_adls_path(config_dir):
        cfg = load_adls_config_with_fallback(config_dir, args.env)
        DEFAULT_CONFIG_BASE_DIR = config_dir
    else:
        config_base_dir = Path(config_dir).expanduser().resolve()

        if not config_base_dir.is_dir():
            raise ValueError(f"Invalid config directory: {config_base_dir}")

        DEFAULT_CONFIG_BASE_DIR = config_base_dir

        cfg_path = resolve_config_path(DEFAULT_CONFIG_BASE_DIR, args.env)
        cfg = load_config(cfg_path)


    if args.secrets:
        print("Loading DEV Key Vault Secrets")
        load_secrets(args.env, args.kv)

    # ignore file_patterns when --patterns is provided
    if args.pattern:
        cfg["file_patterns"] = []

    # for logging
    ops_path = (cfg.get("logging") or {}).get("operations_csv")
    tz_name = cfg.get("tz_name")
    precision = (cfg.get("logging") or {}).get("precision", "seconds")
    ops = OperationLogger(ops_path, tz_name, precision)

    success = False
    
    ops.log_script("Script.Start", "Started")

    try:
        # For adhoc | add --force to force transfer files that have been transferred before
        if args.file:
            cfg = copy.deepcopy(cfg)
            cfg["file_patterns"] = [args.file]
            if cfg.get("mode", "recent") == "recent":
                cfg["mode"] = "unprocessed"

        # Build IO endpoints
        # source = build_source(cfg)
        destination = build_destination(cfg)

        # Extract source/dest descriptors for the "Execute File Transfer" line
        src_t, src_p = get_source_info(cfg)
        dst_t, dst_p = get_destination_info(cfg)

        ops.log_transfer("Execute File Transfer", src_t, src_p, dst_t, dst_p, "Started")
        log(f"Source: {src_t} ({src_p}) -> Destination: {dst_t} ({dst_p})")

        mode = cfg.get("mode", "recent")
        recent_minutes = int(cfg.get("recent_minutes", 30))
        state_file = cfg["state"]["file"]

        fb = cfg.get("recent_filename_date_fallback", {})
        fb_enabled = bool(fb.get("enabled", False))
        fb_window_days = int(fb.get("window_days", 1))
        fb_regex = fb.get("regex", r"(\d{8})(?=\D*$)")
        fb_fmt = fb.get("strptime", "%Y%m%d")

        processed_keys, processed_records = load_state(state_file)
        processed_names = {
            rec.get("name")
            for rec in processed_records
            if isinstance(rec, dict) and rec.get("name")
        }


        found_any = False


        src_type = cfg["source"]["type"]

        if src_type == "spo_rest":
            path_template = cfg["source"]["spo_rest"]["folder"]
        elif src_type == "nas":
            path_template = cfg["source"]["nas"]["folder_path"]
        elif src_type == "local":
            path_template = cfg["source"]["local"]["folder_path"]
        else:
            path_template = ""

        lookback = cfg.get("period_search", {}).get("lookback", 0)
        is_dynamic = "{" in path_template and "}" in path_template

        now_utc = datetime.now(timezone.utc)


        ptype = cfg.get("period_search", {}).get("type")
        q_override_bd = int(cfg.get("period_search", {}).get("q_override_bd", 16))


        # --------------------------
        # Quarter offset logic FIX
        # --------------------------

        offsets = []

        if ptype == "quarter":
            bd = get_business_day_of_quarter(now_utc)

            if bd < q_override_bd:
                # BEFORE BD16 → backward
                offsets = [2, 1]   # Q-2, Q-1
                log(f"[BD RULE] BD={bd} < {q_override_bd} -> using Q-2 then Q-1")

            else:
                # AFTER BD16 → forward fallback
                offsets = [1, 0]   # Q-1, Q
                log(f"[BD RULE] BD={bd} >= {q_override_bd} -> using Q-1 then Q")

        else:
            offsets = list(range(lookback + 1))


        # --------------------------
        # LOOP using offsets
        # --------------------------

        for i in range(len(offsets) if is_dynamic else 1):

            effective_i = offsets[i]


            if any(token in path_template for token in ["{quarter}", "{yyqq}", "{year_q}", "{yearq}"]):
                shifted_dt = shift_quarters(now_utc, effective_i)
            else:
                shifted_dt = shift_months(now_utc, effective_i)



            log(f"Scanning period offset {i} (quarter shift={effective_i}, time={shifted_dt})")

            if i > 0:
                log(f"[LOOKBACK] Using fallback period offset={i}")

            cfg_variant = copy.deepcopy(cfg)
            cfg_variant["__now_provider"] = make_now_provider(shifted_dt)

            source_variant = build_source(cfg_variant)

            found_in_this_iteration = False

            patterns = cfg.get("file_patterns", [])

            expanded_patterns = []

            if patterns:
                tokens = compute_tokens(
                    tz_name=cfg.get("tz_name"),
                    now_utc=shifted_dt
                )

                expanded_patterns = expand_patterns(patterns, tokens)

            # -------- FILE LOOP --------
            for name, data, modified_dt in source_variant.iter_files():

                if args.file and name != args.file:
                    continue

                if args.pattern and not fnmatch.fnmatch(name, args.pattern):
                    continue

                if patterns:
                    if not name_matches_any(name, expanded_patterns):
                        continue

                msg = f"[FILE] Checking: {name}"
                log(msg)

                key = f"{name}:{int(modified_dt.timestamp())}"

                if (not args.force) and (name in processed_names):
                    msg = f"Skipping {name} due to name-based deduplication (already processed)"
                    log(msg)
                    continue

                if mode == "recent":
                    passes = is_recent(modified_dt, recent_minutes)

                    if not passes and fb_enabled:
                        passes = filename_date_within_window(name, fb_window_days, fb_regex, fb_fmt)
                        msg = f"[FALLBACK] {name} -> filename date validation = {passes}"
                        log(msg)

                    if not passes:
                        msg = f"[SKIP recency] {name} modified={modified_dt.isoformat()}"
                        log(msg)
                        continue

                elif mode == "unprocessed":
                    if (not args.force) and (key in processed_keys):
                        continue

                file_dest_path = describe_dest_path_for_file(cfg, dst_t, dst_p, name)

                ops.log_transfer(f"Transfer: {name}", src_t, src_p, dst_t, file_dest_path, "Started")

                try:
                    destination.upload(relative_name=name, data=data)

                    msg = f"Transferred: {name} (modified {modified_dt.isoformat()})"
                    log(msg)
                    ops.log_transfer(f"Transfer: {name}", src_t, src_p, dst_t, file_dest_path, "Success")
                    found_any = True
                    found_in_this_iteration = True

                except Exception as ex:
                    msg = f"Error transferring {name}: {type(ex).__name__}: {ex}"
                    log(msg)
                    traceback.print_exc()
                    ops.log_transfer(f"Transfer: {name}", src_t, src_p, dst_t, file_dest_path, "Failed")
                    raise

                if key not in processed_keys:
                    processed_records.append(make_state_record(name, modified_dt, mode))
                    processed_keys.add(key)

            # -------- AFTER FILE LOOP --------

            # STOP if primary period has valid files
            if i == 0 and found_in_this_iteration:
                msg = "[LOOKBACK] Primary period has files -> skipping fallback"
                log(msg)
                ops.log_transfer(
                    msg,
                    src_t, src_p,
                    dst_t,
                    "-",   # no dest path
                    "FallbackSkipped"
                )
                break

        if not found_any:
            msg = "No files found matching filters/patterns."
            log(msg)
            ops.log_transfer(
                msg,
                src_t, src_p,
                dst_t,
                "-",   # no dest path
                "NoFiles"
            )


        save_state(state_file, processed_records, None)
        success = True

    except Exception as ex:
        ops.log_script("Script.Error", "Failed", f"{type(ex).__name__}: {ex}")
        raise
    finally:
        ops.log_script("Script.End", "Success" if success else "Failed")
    
    log(f"Script ended with status={'Success' if success else 'Failed'}")


if __name__ == "__main__":
    main()