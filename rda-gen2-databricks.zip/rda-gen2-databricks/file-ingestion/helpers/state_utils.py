import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Set, List, Dict, Tuple


STATE_BASE_DIR = Path("log").resolve()


def resolve_state_path(path) -> Path:
    user_path = Path(path).expanduser()

    # Disallow absolute paths entirely (state must be relative)
    if user_path.is_absolute():
        raise ValueError("Absolute state paths are not allowed")

    resolved = (STATE_BASE_DIR / user_path).resolve()

    # Structural containment check
    if STATE_BASE_DIR not in resolved.parents:
        raise ValueError(f"Invalid state path: {resolved}")

    # Extension allow-list (this is REQUIRED)
    if resolved.suffix.lower() != ".json":
        raise ValueError("State file must be a .json file")

    return resolved


def load_state(path) -> Tuple[Set[str], List[Dict]]:
    resolved_path = resolve_state_path(path)

    if not resolved_path.exists():
        return set(), []

    with resolved_path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    # Backward-compatible parsing
    if isinstance(data, dict):
        processed_keys = set(data.get("processed_keys", []))
        processed_records = data.get("processed_records", [])
    else:
        processed_records = data
        processed_keys = {r.get("name") for r in processed_records if "name" in r}

    return processed_keys, processed_records


def save_state(path, records: List[Dict], log_path_template=None) -> None:
    resolved_path = resolve_state_path(path)

    # Re-assert safety *at the write sink* (Snyk requirement)
    if not resolved_path.is_file() and resolved_path.suffix.lower() != ".json":
        raise ValueError("State file must be a .json file")

    if STATE_BASE_DIR not in resolved_path.parents:
        raise ValueError(f"Invalid state path: {resolved_path}")

    resolved_path.parent.mkdir(parents=True, exist_ok=True)

    payload = {
        "processed_keys": [r.get("name") for r in records if "name" in r],
        "processed_records": records,
    }

    with resolved_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    if log_path_template:
        log_filename = Path(
            log_path_template.format(
                ts=datetime.now().strftime("%Y%m%d%H%M%S")
            )
        ).name

        log_path = (STATE_BASE_DIR / log_filename).resolve()

        # Same re-assertion here
        if STATE_BASE_DIR not in log_path.parents:
            raise ValueError(f"Invalid log path: {log_path}")

        if log_path.suffix.lower() != ".json":
            raise ValueError("Log file must be a .json file")

        log_path.write_text(json.dumps(records, indent=2), encoding="utf-8")

def make_state_record(name: str, modified_dt, mode: str) -> Dict:
    """
    Create a detailed state record with both source modified time and processed time.
    """
    return {
        "name": name,
        "modified_epoch": int(modified_dt.timestamp()),
        "modified_dt_iso": modified_dt.astimezone(timezone.utc).isoformat(),
        "processed_at_iso": datetime.now(timezone.utc).isoformat(),
        "mode": mode,
    }