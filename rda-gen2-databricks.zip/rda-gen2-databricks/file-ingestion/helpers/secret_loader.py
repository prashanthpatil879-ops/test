import os
import argparse
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient


# =========================
# SECRET MAP (NON-CERT)
# =========================
SECRET_MAP = {
    "RDAMFTSPNId": "CLIENT_ID_ENV",
    "RDAMFTSPNTenantId": "TENANT_ID_ENV",
    "RDAMFTSPNSecret": "SPN_SECRET_ENV",
    "RDAServiceAccount": "NAS_USER",
    "RDAServiceAccountPassword": "NAS_PASS",
}


# =========================
# HELPERS
# =========================
def build_kv_url(kv_name: str) -> str:
    return f"https://{kv_name}.vault.azure.net"


def get_cert_secret_name(env: str) -> str:
    env = env.upper()
    return "SPN-RDA-Cert" if env == "DEV" else f"SPN-RDA-Cert-{env}"


# =========================
# LOAD SECRETS
# =========================
def load_secrets(environment: str, keyvault_name: str):

    kv_url = build_kv_url(keyvault_name)
    print(f"Connecting to Key Vault: {kv_url}")

    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=kv_url, credential=credential)

    # Load normal secrets
    for akv_name, env_name in SECRET_MAP.items():
        print(f"Fetching secret: {akv_name}")
        val = client.get_secret(akv_name).value
        os.environ[env_name] = val

    # Load certificate separately
    cert_name = get_cert_secret_name(environment)
    print(f"Fetching certificate: {cert_name}")

    cert_val = client.get_secret(cert_name).value
    os.environ["SPN_CERT_BYTES"] = cert_val

    print("All secrets loaded into environment variables")


# =========================
# MAIN ENTRY
# =========================
def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--env", required=True, help="Environment (dev/qa/uat/prod)")
    parser.add_argument("--kv", required=True, help="Key Vault name")

    args = parser.parse_args()

    print(f"Environment: {args.env}")
    print(f"Key Vault: {args.kv}")

    load_secrets(args.env, args.kv)

    # Now call your existing script logic OR just prepare env for next script
    print("Secrets ready for downstream script")


if __name__ == "__main__":
    main()