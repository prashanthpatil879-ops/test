import os
from datetime import datetime, timezone


def resolve_log_path(template: str) -> str:
    """
    Token expansion for log file paths.
      {date}     -> YYYYMMDD (UTC)
      {datetime} -> YYYYMMDD_HHMMSS (UTC)

    We keep UTC for filenames so rotation is deterministic regardless of host tz.
    """
    now = datetime.now(timezone.utc)
    result = template.replace("{date}", now.strftime("%Y%m%d"))
    result = result.replace("{datetime}", now.strftime("%Y%m%d_%H%M%S"))
    return result


def get_source_info(cfg: dict) -> tuple[str, str]:
    """
    Return (source_type, source_path_display) normalized across types.
    """
    st = cfg["source"]["type"]
    if st == "spo_rest":
        return st, cfg["source"]["spo_rest"].get("folder", "")
    if st == "local":
        return st, cfg["source"]["local"].get("folder_path", "")
    if st == "nas":
        return st, cfg["source"]["nas"].get("folder_path", "")
    return st, ""


def get_destination_info(cfg: dict) -> tuple[str, str]:
    """
    Return (destination_type, dest_path_display) normalized across types.
    """
    dt = cfg["destination"]["type"]
    if dt == "sftp":
        return dt, cfg["destination"]["sftp"].get("target_dir", "")
    if dt == "ftps":
        return dt, cfg["destination"]["ftps"].get("target_dir", "")
    if dt == "local":
        return dt, cfg["destination"]["local"].get("folder_path", "")
    if dt == "adls":
        return dt, cfg["destination"]["adls"].get("path_template", "")
    return dt, ""


def describe_dest_path_for_file(cfg: dict, dest_type: str, base_dest_path: str, relative_name: str) -> str:
    """
    Best-effort display path of where a file will land—used for logging only.
    - For sftp/ftps/local: join target_dir/folder_path with file name.
    - For adls: replace {filename} token if present; leave other tokens as-is.
    """
    try:
        if dest_type in ("sftp", "ftps", "local"):
            sep = "/" if "/" in base_dest_path or "\\" not in base_dest_path else "\\"
            base = base_dest_path.rstrip("/\\")
            return f"{base}{sep}{relative_name}" if base else relative_name
        if dest_type == "adls":
            if "{filename}" in base_dest_path:
                return base_dest_path.replace("{filename}", relative_name)
            return f"{base_dest_path.rstrip('/')}/{relative_name}"

    except Exception:
        pass
    return base_dest_path