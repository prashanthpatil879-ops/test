# helpers/adls_config_loader.py
import yaml
from azure.identity import DefaultAzureCredential
from azure.storage.filedatalake import DataLakeServiceClient

def is_adls_path(path: str) -> bool:
    return path.lower().startswith("adls://")

def _parse(url: str):
    # adls://account/container/folder...
    clean = url.replace("adls://", "")
    parts = clean.split("/", 2)
    if len(parts) < 2:
        raise ValueError("Invalid ADLS URL. Format: adls://account/container/folder")
    account = parts[0]
    filesystem = parts[1]
    folder = parts[2] if len(parts) == 3 else ""
    return account, filesystem, folder

def load_adls_config_with_fallback(adls_url: str, env: str) -> dict:
    account, filesystem, folder = _parse(adls_url)

    # Normalize folder (VERY IMPORTANT)
    folder = (folder or "").strip("/")

    # Setup ADLS client
    account_url = f"https://{account}.dfs.core.windows.net"
    credential = DefaultAzureCredential()
    service_client = DataLakeServiceClient(account_url=account_url, credential=credential)
    fs_client = service_client.get_file_system_client(filesystem)

    # Helper to read file
    def read_yaml(path: str) -> dict:
        file_client = fs_client.get_file_client(path)
        data = file_client.download_file().readall()
        return yaml.safe_load(data)

    # Try environment-specific config first
    try:
        path = f"{folder}/settings.{env}.yaml" if folder else f"settings.{env}.yaml"
        log_msg = f"[DEBUG] Trying ADLS config: {path}"
        try:
            from helpers.time_utils import log
            log(log_msg)
        except:
            print(log_msg)

        return read_yaml(path)

    except Exception as ex:
        # optional debug
        debug_msg = f"[DEBUG] Failed loading settings.{env}.yaml: {type(ex).__name__}: {ex}"
        try:
            from helpers.time_utils import log
            log(debug_msg)
        except:
            print(debug_msg)

    # Fallback to default config
    try:
        path = f"{folder}/settings.yaml" if folder else "settings.yaml"
        log_msg = f"[DEBUG] Trying fallback config: {path}"
        try:
            from helpers.time_utils import log
            log(log_msg)
        except:
            print(log_msg)

        return read_yaml(path)

    except Exception as ex:
        debug_msg = f"[DEBUG] Failed loading fallback settings.yaml: {type(ex).__name__}: {ex}"
        try:
            from helpers.time_utils import log
            log(debug_msg)
        except:
            print(debug_msg)

        # FINAL FAIL
        raise FileNotFoundError(
            f"No config found in ADLS folder {adls_url} "
            f"(tried settings.{env}.yaml and settings.yaml)"
        )