from datetime import datetime, timedelta, timezone
from contextlib import suppress

try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except ImportError:
    ZoneInfo = None


def now_in_tz(tz_name: str | None):
    """
    Return 'now' localized to tz_name if available, else UTC.
    """
    if tz_name and ZoneInfo:
        with suppress(Exception):
            return datetime.now(ZoneInfo(tz_name))
    return datetime.now(timezone.utc)


def format_dt(dt: datetime, precision: str = "seconds") -> str:
    """
    Format a timezone-aware datetime in 'YYYY-MM-DD HH:MM:SS[.mmm] ±HH:MM'.
    If naive, treat as UTC.
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    base = dt.strftime("%Y-%m-%d %H:%M:%S")
    if precision == "milliseconds":
        ms = f"{int(dt.microsecond/1000):03d}"
        base = f"{base}.{ms}"

    offset = dt.strftime('%z')
    offset = (offset[:3] + ':' + offset[3:]) if offset else '+00:00'
    return f"{base} {offset}"


def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}")


def shift_to_previous_month(dt: datetime) -> datetime:
    first_day = dt.replace(day=1)
    return first_day - timedelta(days=1)

def shift_months(dt, months_back):
    for _ in range(months_back):
        dt = shift_to_previous_month(dt)
    return dt


def shift_quarters(dt, quarters_back):
    # Move to start of current quarter
    q_month = ((dt.month - 1) // 3) * 3 + 1
    dt = dt.replace(month=q_month, day=1)

    for _ in range(quarters_back):
        dt = dt - timedelta(days=1)  # go to previous quarter
        q_month = ((dt.month - 1) // 3) * 3 + 1
        dt = dt.replace(month=q_month, day=1)

    return dt


def make_now_provider(fixed_dt):
    return lambda: fixed_dt


def get_business_day_of_quarter(dt: datetime) -> int:
    # start of quarter
    q_month = ((dt.month - 1) // 3) * 3 + 1
    start = dt.replace(month=q_month, day=1)

    bd = 0
    cur = start

    while cur <= dt:
        if cur.weekday() < 5:  # Mon-Fri
            bd += 1
        cur += timedelta(days=1)

    return bd