import csv
import os
from typing import List
from helpers.time_utils import now_in_tz, format_dt
from helpers.path_utils import resolve_log_path


class OperationLogger:
    """
    Operational CSV logger with columns:
      Date | Event | Source | Source Path | Destination | Destination Path | Status

    - File path is resolved with {date}/{datetime} tokens (UTC).
    - Row timestamps honor tz_name and precision ('seconds'|'milliseconds').
    """

    HEADERS: List[str] = [
        "Date", "Event", "Source", "Source Path", "Destination", "Destination Path", "Status"
    ]

    def __init__(self, path_template: str | None, tz_name: str | None, precision: str = "seconds"):
        self.tz_name = tz_name
        self.precision = precision
        self.log_path = None

        if path_template:
            self.log_path = resolve_log_path(path_template)
            os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
            exists = os.path.exists(self.log_path)
            with open(self.log_path, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if not exists:
                    w.writerow(self.HEADERS)

    def _write(self, row: list[str]) -> None:
        if not self.log_path:
            return
        with open(self.log_path, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(row)

    def log(self, event: str, source: str = "", source_path: str = "",
            dest: str = "", dest_path: str = "", status: str = ""):
        dt = format_dt(now_in_tz(self.tz_name), precision=self.precision)
        self._write([dt, event, source, source_path, dest, dest_path, status])

    # Convenience API
    def log_script(self, event: str, status: str, details: str | None = None):
        ev = event if not details else f"{event}: {details}"
        self.log(ev, "", "", "", "", status)

    def log_transfer(self, event: str, source_t: str, source_p: str,
                     dest_t: str, dest_p: str, status: str):
        self.log(event, source_t, source_p, dest_t, dest_p, status)