import os
import mimetypes
from typing import Callable, Dict, Optional

from azure.identity import (
    DefaultAzureCredential,
    ManagedIdentityCredential,
    ClientSecretCredential,
)
from azure.storage.filedatalake import (
    DataLakeServiceClient,
    FileSystemClient,
)
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError, HttpResponseError
from azure.storage.blob import ContentSettings  # for setting Content-Type


# ----------------------------
# Helpers
# ----------------------------
def _from_env_or_literal(value: Optional[str]) -> Optional[str]:
    """
    Supports 'env:VAR_NAME' convention. If value starts with 'env:',
    reads from environment variable VAR_NAME; otherwise returns the literal.
    """
    if not value:
        return value
    value = value.strip()
    if value.lower().startswith("env:"):
        env_name = value.split(":", 1)[1].strip()
        return os.getenv(env_name)
    return value


def resolve_tokens_default(template: str, ctx: Dict[str, str], src_filename: str) -> str:
    """
    Simple token resolver. Supports {filename} + arbitrary tokens present in ctx.
    """
    resolved = template.replace("{filename}", src_filename)
    for k, v in (ctx or {}).items():
        resolved = resolved.replace("{" + k + "}", str(v))
    return resolved


def _normalize_path(path: str) -> str:
    # Ensure no leading slashes and collapse backslashes to forward slashes
    p = path.replace("\\", "/").lstrip("/")
    # Remove duplicate slashes
    while "//" in p:
        p = p.replace("//", "/")
    return p


def _build_account_url(account_name: str, sas: Optional[str] = None) -> str:
    base = f"https://{account_name}.dfs.core.windows.net"
    if sas:
        sas = sas.lstrip("?")
        return f"{base}?{sas}"
    return base


def _guess_content_type(filename: str) -> Optional[str]:
    ct, _ = mimetypes.guess_type(filename)
    return ct


# ----------------------------
# Destination
# ----------------------------
class ADLSGen2Destination:
    """
    ADLS Gen2 destination with Managed Identity by default.
    - Ensures parent directories
    - Idempotency via exists + overwrite
    - Optional content-type setting based on file extension
    
    """

    def __init__(
        self,
        config: Dict,
        logger=None,
        token_resolver: Optional[Callable[[str, Dict[str, str], str], str]] = None
    ):
        self._cfg = config or {}
        self._logger = logger
        self._resolve = token_resolver or resolve_tokens_default

        self.account_name = self._cfg.get("account_name") or ""
        self.filesystem_name = self._cfg.get("filesystem") or ""
        self.path_template = self._cfg.get("path_template") or "{filename}"
        self.overwrite = bool(self._cfg.get("overwrite", False))
        self.create_dirs = bool(self._cfg.get("create_dirs", True))
        self.content_type_from_extension = bool(self._cfg.get("content_type_from_extension", True))

        if not self.account_name or not self.filesystem_name:
            raise ValueError("ADLSGen2Destination requires 'account_name' and 'filesystem' in config.")

        cred_cfg = (self._cfg.get("credential") or {})
        self.cred_mode = (cred_cfg.get("mode") or "default").lower()

        # Resolve env indirections
        self.client_id = _from_env_or_literal(cred_cfg.get("client_id"))
        self.tenant_id = _from_env_or_literal(cred_cfg.get("tenant_id"))
        self.client_secret = _from_env_or_literal(cred_cfg.get("client_secret"))
        self.connection_string = _from_env_or_literal(cred_cfg.get("connection_string"))
        self.sas_token = _from_env_or_literal(cred_cfg.get("sas_token"))

        # Lazily created clients
        self._service_client: Optional[DataLakeServiceClient] = None
        self._fs_client: Optional[FileSystemClient] = None

    # ---------- Public API ----------
    def connect(self):
        """
        Creates the service + filesystem clients.
        Managed Identity (or DefaultAzureCredential) by default.
        """
        if self._service_client is not None and self._fs_client is not None:
            return

        if self.cred_mode == "connection_string":
            if not self.connection_string:
                raise ValueError("credential.connection_string is required for mode=connection_string")
            self._service_client = DataLakeServiceClient.from_connection_string(self.connection_string)
        else:
            # Build credential
            credential = self._build_credential()
            account_url = _build_account_url(self.account_name, self.sas_token if self.cred_mode == "sas" else None)
            self._service_client = DataLakeServiceClient(account_url=account_url, credential=credential)

        self._fs_client = self._service_client.get_file_system_client(self.filesystem_name)

    def upload(
        self,
        local_path: str = None,
        src_filename: str = None,
        relative_name: str = None,
        data=None,
        token_context: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        """
        Uploads to ADLS Gen2.

        Supported call patterns:
        1) upload(local_path="/path/to/file.ext", src_filename="file.ext")
        2) upload(relative_name="sub/dir/file.ext", data=<bytes-or-filelike>)

        Returns {status, path, etag, last_modified}.
        """
        self.connect()

        # Decide which mode we are in
        in_memory_mode = data is not None
        if not in_memory_mode and not (local_path and src_filename):
            raise ValueError(
                "Provide either (relative_name + data) for in-memory upload "
                "or (local_path + src_filename) for file-path upload."
            )

        # Determine the filename used for tokens like {filename}
        if in_memory_mode:
            if not relative_name:
                if not src_filename:
                    raise ValueError("relative_name is required when data is provided")
                relative_name = src_filename
            filename_for_tokens = os.path.basename(relative_name)
        else:
            filename_for_tokens = os.path.basename(src_filename)

        # Resolve destination path from template
        dest_path = self._resolve(self.path_template, token_context or {}, filename_for_tokens)
        dest_path = _normalize_path(dest_path)

        # If template is a pure folder (no tokens), append the incoming name so we don't lose it
        if "{" not in self.path_template and self.path_template.strip():
            dest_path = _normalize_path(f"{self.path_template}/{relative_name or src_filename}")

        if self._logger:
            self._logger.info("Resolved ADLS destination path: %s", dest_path)

        # Ensure parent directories
        if self.create_dirs:
            self._ensure_parent_dirs(dest_path)

        file_client = self._fs_client.get_file_client(dest_path)

        # Idempotency: if overwrite=False and file exists, skip
        if not self.overwrite:
            try:
                props = file_client.get_file_properties()
                return {
                    "status": "skipped",
                    "path": dest_path,
                    "etag": props.get("etag"),
                    "last_modified": str(props.get("last_modified"))
                }
            except ResourceNotFoundError:
                pass  # not found => proceed

        # --- Explicit create -> upload -> set headers -> props (avoids BlobNotFound) ---
        created_now = False
        try:
            file_client.create_file()
            created_now = True
        except ResourceExistsError:
            # already exists; we will overwrite with upload_data(overwrite=True)
            pass

        # Upload content
        if in_memory_mode:
            file_client.upload_data(data, overwrite=True)
        else:
            with open(local_path, "rb") as f:
                file_client.upload_data(f, overwrite=True)

        # Optional Content-Type
        if self.content_type_from_extension:
            ct = _guess_content_type(filename_for_tokens) or "application/octet-stream"
            try:
                file_client.set_http_headers(content_settings=ContentSettings(content_type=ct))
            except HttpResponseError:
                if self._logger:
                    self._logger.warning("Failed to set content-type header for %s", dest_path)

        # Get properties
        props = file_client.get_file_properties()
        if self._logger:
            self._logger.info("Uploaded to ADLS: %s (created_now=%s, etag=%s)", dest_path, created_now, props.get("etag"))

        return {
            "status": "uploaded",
            "path": dest_path,
            "etag": props.get("etag"),
            "last_modified": str(props.get("last_modified"))
        }

    # ---------- Internals ----------
    def _build_credential(self):
        mode = self.cred_mode

        if mode == "default":
            # Works with Managed Identity on VM; local dev picks up Azure CLI/VSCode/env as available.
            return DefaultAzureCredential(exclude_interactive_browser_credential=True)

        if mode == "managed_identity":
            # System-assigned: omit client_id; User-assigned: pass client_id
            if self.client_id:
                return ManagedIdentityCredential(client_id=self.client_id)
            return ManagedIdentityCredential()

        if mode == "user_assigned":
            if not self.client_id:
                raise ValueError("credential.client_id is required for mode=user_assigned")
            return ManagedIdentityCredential(client_id=self.client_id)

        if mode == "client_secret":
            if not (self.tenant_id and self.client_id and self.client_secret):
                raise ValueError("tenant_id, client_id, and client_secret are required for mode=client_secret")
            return ClientSecretCredential(self.tenant_id, self.client_id, self.client_secret)

        if mode == "sas":
            # Using SAS in account_url; still return a DefaultAzureCredential for any auxiliary ops if needed.
            return DefaultAzureCredential(exclude_interactive_browser_credential=True)

        if mode == "connection_string":
            # Handled in connect()
            return None

        raise ValueError(f"Unsupported credential.mode: {mode}")

    def _ensure_parent_dirs(self, dest_path: str):
        """
        Ensures all parent directories exist. Silently ignores if they already exist.
        """
        parts = _normalize_path(dest_path).split("/")
        if len(parts) <= 1:
            return
        dir_path = ""
        for seg in parts[:-1]:
            dir_path = f"{dir_path}/{seg}" if dir_path else seg
            try:
                self._fs_client.create_directory(dir_path)
            except ResourceExistsError:
                pass