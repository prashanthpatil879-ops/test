
import os
from pathlib import Path

from .base_destination import BaseDestination

class LocalFolderDestination(BaseDestination):
    def __init__(self, folder_path: str):
        # Normalize and expand user variables
        self.folder_path = os.path.expandvars(os.path.expanduser(folder_path))
        Path(self.folder_path).mkdir(parents=True, exist_ok=True)

    def upload(self, relative_name: str, data: bytes) -> None:
        target = Path(self.folder_path) / relative_name
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, 'wb') as f:
            f.write(data)
