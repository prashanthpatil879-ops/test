
from abc import ABC, abstractmethod

class BaseDestination(ABC):
    '''Interface for destinations that accept uploaded files.'''

    @abstractmethod
    def upload(self, relative_name: str, data: bytes) -> None:
        '''Upload bytes to destination with target filename.'''
        raise NotImplementedError
