
import os
from ftplib import FTP_TLS
from io import BytesIO

from .base_destination import BaseDestination

class FTPSDestination(BaseDestination):
    def __init__(self, host: str, port: int, username_env: str, password_env: str, target_dir: str, passive: bool = True):
        self.host = host
        self.port = port
        self.username = os.getenv(username_env) if username_env else None
        self.password = os.getenv(password_env) if password_env else None
        self.target_dir = target_dir
        self.passive = passive

    def upload(self, relative_name: str, data: bytes) -> None:
        if not self.username or not self.password:
            raise RuntimeError("FTPS credentials missing: set username/password env variables")
        ftps = FTP_TLS()
        ftps.connect(self.host, self.port)
        ftps.auth()  # secure control connection
        ftps.prot_p()  # secure data connection
        ftps.login(self.username, self.password)
        ftps.set_pasv(self.passive)
        try:
            try:
                ftps.cwd(self.target_dir)
            except Exception:
                parts = [p for p in self.target_dir.split('/') if p]
                for p in parts:
                    try:
                        ftps.mkd(p)
                    except Exception:
                        pass
                    ftps.cwd(p)
            bio = BytesIO(data)
            ftps.storbinary(f"STOR {relative_name}", bio)
        finally:
            ftps.quit()
