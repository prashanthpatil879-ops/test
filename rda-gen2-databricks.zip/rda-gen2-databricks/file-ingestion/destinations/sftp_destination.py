
import os
import io
import paramiko
from .base_destination import BaseDestination

class SFTPDestination(BaseDestination):
    def __init__(self, host: str, port: int, username_env: str,
                 target_dir: str, key_path_env: str = None, key_passphrase_env: str = None,
                 password_env: str = None, auth_mode: str = "auto"):
        self.host = host
        self.port = port
        self.username_env = username_env
        self.password_env = password_env
        self.key_path_env = key_path_env
        self.key_passphrase_env = key_passphrase_env
        self.target_dir = target_dir
        self.auth_mode = auth_mode.lower() if auth_mode else "auto"

    def _resolve_env_or_literal_path(self, maybe_env_name: str) -> str:
        if not maybe_env_name:
            return None
        val = os.getenv(maybe_env_name)
        if val and os.path.exists(val):
            return val
        if os.path.exists(maybe_env_name):
            return maybe_env_name
        return None


    def _connect(self):
        username = os.getenv(self.username_env) if self.username_env else None
        password = os.getenv(self.password_env) if self.password_env else None
        print(username)
        exit()
        key_path = self._resolve_env_or_literal_path(self.key_path_env)
        key_passphrase = os.getenv(self.key_passphrase_env) if self.key_passphrase_env else None

        if not username:
            raise RuntimeError("SFTP username missing")

        # ssh = paramiko.SSHClient()
        # ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        ssh = paramiko.SSHClient()

        # Load known_hosts (system + user)
        ssh.load_system_host_keys()
        ssh.load_host_keys(os.path.expanduser("~/.ssh/known_hosts"))

        # Reject unknown host keys (prevents MITM)
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())

        if self.auth_mode == "key":
            if not key_path:
                raise RuntimeError("auth_mode=key requires key_path_env or literal path")
            try:
                try:
                    pkey = paramiko.Ed25519Key.from_private_key_file(key_path, password=key_passphrase)
                except Exception:
                    pkey = paramiko.RSAKey.from_private_key_file(key_path, password=key_passphrase)
                ssh.connect(self.host, port=self.port, username=username, pkey=pkey, timeout=30)
            except Exception as e:
                raise RuntimeError(f"Failed key-based auth: {e}")
        elif self.auth_mode == "password":
            if not password:
                raise RuntimeError("auth_mode=password requires password_env")
            ssh.connect(self.host, port=self.port, username=username, password=password, timeout=30)
        else:  # auto
            if key_path:
                try:
                    try:
                        pkey = paramiko.Ed25519Key.from_private_key_file(key_path, password=key_passphrase)
                    except Exception:
                        pkey = paramiko.RSAKey.from_private_key_file(key_path, password=key_passphrase)
                    ssh.connect(self.host, port=self.port, username=username, pkey=pkey, timeout=30)
                except Exception:
                    if password:
                        ssh.connect(self.host, port=self.port, username=username, password=password, timeout=30)
                    else:
                        raise RuntimeError("No valid SFTP credentials found")
            elif password:
                ssh.connect(self.host, port=self.port, username=username, password=password, timeout=30)
            else:
                raise RuntimeError("No valid SFTP credentials found")

        return ssh

    def upload(self, relative_name: str, data: bytes) -> None:
        ssh = self._connect()
        sftp = ssh.open_sftp()
        try:
            remote_folder = self.target_dir or "/"
            remote_path = remote_folder.rstrip("/") + "/" + relative_name

            # Ensure remote folder exists (recursive mkdir)
            try:
                sftp.chdir(remote_folder)
            except IOError:
                parts = [p for p in remote_folder.split("/") if p]
                path_accum = ""
                for p in parts:
                    path_accum += "/" + p
                    try:
                        sftp.chdir(path_accum)
                    except IOError:
                        try:
                            sftp.mkdir(path_accum)
                            sftp.chdir(path_accum)
                        except Exception:
                            pass  # Folder creation may be disallowed

            # Upload from memory
            bio = io.BytesIO(data)
            sftp.putfo(bio, remote_path)
        finally:
            try:
                sftp.close()
            except Exception:
                pass
            ssh.close()

    def close(self):
        pass

    def validate(self):
        return True
