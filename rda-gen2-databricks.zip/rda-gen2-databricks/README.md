
# RDA — Resilience, Decision and Action

## Overview
**RDA** is a PySpark-based risk analytics engine built on **Azure Databricks**. It computes:
- **Interest Rate Sensitivities**
- **Economic Capital (EC)**
- **Earnings at Risk (EaR)**

The solution leverages **Modern Data Architecture** principles:
- **Delta Lake** for ACID transactions and time travel
- **Medallion Architecture** (Bronze → Silver → Gold) for structured data refinement
- **Databricks Workflows** for orchestration

---

## Architecture
- **Bronze Layer**: Raw ingestion from source systems
- **Silver Layer**: Cleansing, normalization, and enrichment
- **Gold Layer**: Curated analytics outputs for risk metrics

